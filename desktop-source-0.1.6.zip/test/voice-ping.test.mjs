import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import {webcrypto} from 'node:crypto';
import {createRequire} from 'node:module';
import {homedir} from 'node:os';
import path from 'node:path';

function pending(){let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no});return{promise,resolve,reject};}
function setup({abortable=false}={}){
 let clock=100,wall=100000;const requests=[],timeouts=new Map(),intervals=[];
 const events={addEventListener(){},removeEventListener(){}};
 const sandbox={window:{...events},document:{...events},navigator:{},localStorage:{getItem:()=>null},setInterval:(callback,ms)=>{const timer={callback,ms};intervals.push(timer);return timer;},clearInterval(){},setTimeout:(callback,ms)=>{const timer={callback,ms};timeouts.set(timer,timer);return timer;},clearTimeout:timer=>timeouts.delete(timer),performance:{now:()=>clock},Date:class extends Date{static now(){return wall;}},structuredClone,crypto:webcrypto,console};
 if(abortable)sandbox.AbortController=AbortController;
 const code=readFileSync(new URL('../public/voice.js',import.meta.url),'utf8').replace('export class VibraVoice','class VibraVoice').replace('export default VibraVoice;','globalThis.Voice=VibraVoice;');vm.runInNewContext(code,sandbox);
 const voice=new sandbox.Voice({userId:'self',request:async(url,method,body,options)=>{if(url==='/api/voice/ping'){const request=pending(),record={body,...request,signal:options?.signal,aborted:false,settled:false};requests.push(record);if(abortable){const abort=()=>{record.aborted=true;request.reject(Object.assign(new Error('Fetch aborted'),{name:'AbortError'}));};if(record.signal?.aborted)abort();else record.signal?.addEventListener('abort',abort,{once:true});}try{return await request.promise;}finally{record.settled=true;}}if(url==='/api/voice/join')return{channelId:body.channelId,participants:[]};return{ok:true};}});
 voice.openCapture=async()=>true;voice.ensurePlayback=async()=>{};
 return{voice,requests,timeouts,intervals,advance:ms=>{clock+=ms;wall+=ms;}};
}
test('existing heartbeat measures actual elapsed RTT, avoids overlap and expires stale samples',async()=>{
 const{voice,requests,timeouts,intervals,advance}=setup();await voice.join('room');assert.equal(intervals.filter(t=>t.ms===5000).length,1);
 assert.equal(voice.state.serverPingMs,null);const first=voice.measureServerPing();await voice.measureServerPing();assert.equal(requests.length,1);
 advance(137.4);requests[0].resolve({ok:true});await first;assert.equal(voice.state.serverPingMs,137);assert.equal(voice.state.serverPingAt,100137.4);
 const expiry=[...timeouts.values()].find(t=>t.ms===15000);assert(expiry);advance(15000);expiry.callback();assert.equal(voice.state.serverPingMs,null);assert.equal(voice.state.serverPingAt,null);assert.equal(requests.length,1);
 await voice.leave();assert.equal(timeouts.size,0);
});

test('hung heartbeat fetch is aborted at eight seconds and leaves no request or RTT timer behind',async()=>{
 const{voice,requests,timeouts,advance}=setup({abortable:true});await voice.join('room');const ping=voice.measureServerPing();
 assert(requests[0].signal instanceof AbortSignal);const deadline=[...timeouts.values()].find(timer=>timer.ms===8000);assert(deadline);
 advance(7999);assert.equal(requests[0].signal.aborted,false);await voice.measureServerPing();assert.equal(requests.length,1);
 advance(1);deadline.callback();await ping;assert.equal(requests[0].aborted,true);assert.equal(requests[0].settled,true);
 assert.equal(voice.state.connected,false);assert.equal(voice.state.serverPingMs,null);assert.equal(voice.pingInFlight,null);assert.equal(timeouts.size,0);
});

test('leaving aborts an old fetch before the next room heartbeat without disconnecting the new room',async()=>{
 const{voice,requests,timeouts,advance}=setup({abortable:true});await voice.join('old');const old=voice.measureServerPing();await voice.join('new');await old;
 assert.equal(requests[0].aborted,true);assert.equal(requests[0].settled,true);assert.equal(voice.state.connected,true);assert.equal(voice.state.channelId,'new');assert.equal(voice.state.serverPingMs,null);
 const fresh=voice.measureServerPing();assert.equal(requests.length,2);assert.equal(requests[1].aborted,false);advance(44);requests[1].resolve({ok:true});await fresh;
 assert.equal(voice.state.connected,true);assert.equal(voice.state.serverPingMs,44);assert.equal([...timeouts.values()].some(timer=>timer.ms===8000),false);
 await voice.leave();assert.equal(timeouts.size,0);
});
test('late old-room heartbeat cannot overwrite RTT or disconnect a newly joined room',async()=>{
 const{voice,requests,advance,timeouts}=setup();await voice.join('old');const old=voice.measureServerPing();await voice.join('new');
 assert.equal(voice.state.serverPingMs,null);await voice.measureServerPing();assert.equal(requests.length,1,'an outstanding old request must not overlap a new one');
 requests[0].reject(new Error('old session was replaced'));await old;assert.equal(voice.state.connected,true);assert.equal(voice.state.channelId,'new');assert.equal(voice.state.serverPingMs,null);
 const fresh=voice.measureServerPing();advance(42);requests[1].resolve({ok:true});await fresh;assert.equal(voice.state.serverPingMs,42);
 const late=voice.measureServerPing();await voice.leave();assert.equal(voice.state.serverPingMs,null);assert.equal(timeouts.size,0);advance(80);requests[2].resolve({ok:true});await late;assert.equal(voice.state.serverPingMs,null);assert.equal(voice.state.channelId,null);
});

test('voice status tooltip is green, accessible on hover/focus and updates without replacing focused control',{timeout:15000},async t=>{
 const modules=process.env.VIBRA_NODE_MODULES||path.join(homedir(),'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules');const{chromium}=createRequire(import.meta.url)(path.join(modules,'playwright'));
 const browser=await chromium.launch({executablePath:process.env.VIBRA_EDGE||'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});t.after(()=>browser.close());const page=await browser.newPage();let requests=0;page.on('request',()=>requests++);
 const app=readFileSync(new URL('../public/app.js',import.meta.url),'utf8'),start=app.indexOf('function updateVoiceBar()'),end=app.indexOf('\nfunction renderVoiceRoom()',start),fn=app.slice(start,end),css=readFileSync(new URL('../public/style.css',import.meta.url),'utf8');
 await page.setContent('<!doctype html><style>'+css+'</style><div id="voice-bar" style="margin:200px 100px;width:242px"></div>');
 await page.evaluate(source=>{window.$=(selector,root=document)=>root.querySelector(selector);window.updateHTML=(el,html)=>{if(el&&el.__html!==html){el.innerHTML=html;el.__html=html;}};window.icon=()=>'<svg class="icon" aria-hidden="true"></svg>';window.ib=()=>'';window.esc=value=>String(value);window.s={channels:[{id:'room',name:'Test room'}],me:{id:'self'}};window.app=document.body;window.screenShare=null;window.updateVoiceRoster=()=>{};window.v={connected:true,channelId:'room',serverPingMs:87,serverPingAt:Date.now()};window.voice={get state(){return v;}};window.fetch=()=>{throw Error('Hover must not trigger a ping request');};(0,eval)(source+';window.renderPing=updateVoiceBar;');renderPing();},fn);
 const control=page.locator('.voice-connection'),tooltip=page.getByRole('tooltip');assert.equal(await control.evaluate(el=>getComputedStyle(el).color),'rgb(109, 224, 167)');await control.hover();await tooltip.waitFor({state:'visible'});assert.match(await tooltip.textContent(),/87 мс до сервера/);assert.match(await tooltip.textContent(),/не задержка звука/);
 await control.focus();await page.mouse.move(0,0);assert.equal(await tooltip.isVisible(),true);await page.evaluate(()=>{window.previousControl=document.activeElement;v.serverPingMs=126;v.serverPingAt=Date.now();renderPing();});assert.equal(await page.evaluate(()=>document.activeElement===previousControl),true);assert.match(await tooltip.textContent(),/126 мс до сервера/);
 await page.evaluate(()=>{v.serverPingAt=Date.now()-16000;renderPing();});assert.match(await tooltip.textContent(),/Нет свежего измерения/);assert.equal(requests,0);
 await page.evaluate(()=>{v.channelId=null;v.connected=false;renderPing();});assert.equal(await control.count(),0);
});
