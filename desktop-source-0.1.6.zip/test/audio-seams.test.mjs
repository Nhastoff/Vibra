import test from 'node:test';import assert from 'node:assert/strict';import vm from 'node:vm';import {readFileSync,mkdtempSync,rmSync,mkdirSync,writeFileSync} from 'node:fs';import {createRequire} from 'node:module';import {homedir,tmpdir} from 'node:os';import path from 'node:path';
test('capture sequence preserves suppressed silence and mute gaps instead of joining unrelated speech samples',async()=>{
 let now=0;const calls=[],events={addEventListener(){},removeEventListener(){}};
 const context=vm.createContext({window:{...events},document:{...events,hidden:false},navigator:{},localStorage:{getItem:()=>null},structuredClone,setInterval:()=>0,clearInterval(){},Date:{now:()=>now},btoa,atob,console});
 vm.runInContext(readFileSync('public/voice.js','utf8').replace('export class VibraVoice','class VibraVoice').replace('export default VibraVoice;','globalThis.VibraVoice=VibraVoice;'),context);
 const voice=new context.VibraVoice({userId:'self',request:async(p,m,b)=>{calls.push(b);return{}}});voice._state.connected=true;voice.clientId='synthetic';voice.sequence=0;
 const frame=rms=>voice.captureFrame({pcm:new ArrayBuffer(3200),rms});frame(.1);await new Promise(r=>setImmediate(r));now=500;frame(0);now=600;frame(0);now=700;frame(.1);await new Promise(r=>setImmediate(r));
 assert.deepEqual(calls.map(c=>c.sequence),[0,3]);voice._state.connected=false;voice.destroy();
});
test('real audio rendering fades nonadjacent speech without clicks or overlap while keeping packet boundaries continuous',{timeout:20000},async t=>{
 const directory=mkdtempSync(path.join(tmpdir(),'vibra-seams-')),previous=process.env.DATA_DIR;process.env.DATA_DIR=directory;const {server,db}=await import('../server.mjs?seams='+Date.now());await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;let browser;
 t.after(async()=>{await browser?.close();server.closeAllConnections();await new Promise(r=>server.close(r));db.close();rmSync(directory,{recursive:true,force:true});if(previous===undefined)delete process.env.DATA_DIR;else process.env.DATA_DIR=previous});
 const {chromium}=createRequire(import.meta.url)(path.join(homedir(),'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'));
 browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});const page=await browser.newPage();await page.goto(base);
 const result=await page.evaluate(async()=>{
  const{VibraVoice}=await import('/voice.js');
  async function render(gap){const voice=new VibraVoice({userId:'self',request:async()=>({})}),ctx=voice.playbackContext=new OfflineAudioContext(1,48000,48000);Object.defineProperty(ctx,'state',{value:'running'});for(let f=0;f<3;f++){const pcm=new Int16Array(1600);for(let i=0;i<1600;i++)pcm[i]=gap?Math.round((f%2?-.4:.4)*32767):Math.round(Math.sin(2*Math.PI*997*(f*1600+i)/16000)*.3*32767);voice.playFrame({userId:'peer',sequence:gap?f*5:f,pcm:btoa(String.fromCharCode(...new Uint8Array(pcm.buffer)))});}const buffer=await ctx.startRendering(),samples=buffer.getChannelData(0);let maximumStep=0,seamStep=0,maximumIndex=0;for(let i=28800;i<43200;i++){if(Math.abs(samples[i]-samples[i-1])>maximumStep){maximumStep=Math.abs(samples[i]-samples[i-1]);maximumIndex=i;}if(Math.abs(i-33600)<250||Math.abs(i-38400)<250)seamStep=Math.max(seamStep,Math.abs(samples[i]-samples[i-1]));}voice.playbackContext=null;voice.destroy();return{maximumStep,seamStep,maximumIndex,edge:Array.from(samples.slice(33596,33606)),peak:Math.max(...samples.map(Math.abs))}}
  return{gap:await render(true),continuous:await render(false),input:'Synthetic opposite-polarity speech segments and coherent sine; real OfflineAudioContext; no physical microphone'};
 });
 mkdirSync('test-output',{recursive:true});writeFileSync('test-output/audio-seams'+(process.env.VIBRA_AUDIO_BASELINE==='1'?'-baseline':'')+'.json',JSON.stringify(result,null,2));t.diagnostic(JSON.stringify(result));
 if(process.env.VIBRA_AUDIO_BASELINE!=='1'){assert(result.gap.seamStep<.04,'Speech pauses must not create a full-scale sample discontinuity');assert(result.continuous.seamStep<.06,'Continuous PCM packet boundaries must stay smooth');assert(result.gap.peak<.45,'Speech segments must not overlap');}
});
