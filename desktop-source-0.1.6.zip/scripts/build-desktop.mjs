import {mkdirSync,writeFileSync,existsSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const platform=process.argv[2];
const targets={win:['--win','nsis'],linux:['--linux','AppImage','deb'],mac:['--mac','dmg','zip']};
if(!targets[platform])throw new Error('Укажите платформу сборки: win, linux или mac.');
const cli=path.join(root,'node_modules/electron-builder/cli.js');
if(!existsSync(cli))throw new Error('Сначала загрузите локальные зависимости: pnpm install.');
mkdirSync(path.join(root,'.build-cache'),{recursive:true});
// Downloaded builder helpers are CommonJS even when the application is ESM.
writeFileSync(path.join(root,'.build-cache/package.json'),JSON.stringify({private:true,type:'commonjs'}));
const extra=process.argv.slice(3);
const child=spawn(process.execPath,[cli,...targets[platform],...(extra.length?extra:['--'+process.arch]),'--publish','never'],{
 cwd:root,stdio:'inherit',windowsHide:true,env:{...process.env,
 ELECTRON_CACHE:process.env.ELECTRON_CACHE||path.join(root,'.build-cache/electron'),
 ELECTRON_BUILDER_CACHE:process.env.ELECTRON_BUILDER_CACHE||path.join(root,'.build-cache/electron-builder')}
});
child.on('error',error=>{console.error(error.message);process.exitCode=1;});
child.on('exit',code=>{process.exitCode=code??1;});
