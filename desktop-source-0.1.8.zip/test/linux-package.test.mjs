import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { tarHeader, arHeader, buildDeb, inspectDeb } from '../scripts/package-linux.mjs';

test('USTAR paths, checksum and ar headers obey standard fixed-width formats', () => {
  const header = tarHeader('opt/Vibra/resources/' + 'nested/'.repeat(15) + 'app.asar', { size: 1234, mode: 0o755 });
  assert.equal(header.length, 512); assert.equal(header.toString('ascii', 257, 263), 'ustar\0');
  const checksum = parseInt(header.toString('ascii', 148, 154), 8), copy = Buffer.from(header); copy.fill(32, 148, 156);
  assert.equal(copy.reduce((sum, byte) => sum + byte, 0), checksum);
  assert.equal(arHeader('data.tar.gz', 123).length, 60);
  for (const name of ['../escape', '/absolute', 'a/../b', 'a\\b']) assert.throws(() => tarHeader(name));
});

test('a Debian package contains root-owned ELF runtime, setuid sandbox, launcher and exact application payload', async () => {
  const root = await mkdtemp(path.join(tmpdir(), 'vibra-deb-test-'));
  try {
    const source = path.join(root, 'runtime'); await mkdir(path.join(source, 'resources'), { recursive: true });
    const elf = Buffer.alloc(70001); elf.set([0x7f, 69, 76, 70, 2, 1]); elf.writeUInt16LE(62, 18);
    await writeFile(path.join(source, 'vibra'), elf); await writeFile(path.join(source, 'chrome-sandbox'), 'sandbox');
    await writeFile(path.join(source, 'chrome_crashpad_handler'), 'crashpad'); await writeFile(path.join(source, 'resources', 'app.asar'), 'packaged Vibra fixture');
    const icon = path.join(root, 'icon.png'); await writeFile(icon, Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
    const output = path.join(root, 'Vibra.deb'), result = await buildDeb({ sourceDir: source, output, icon });
    assert.match(result.sha256, /^[a-f0-9]{64}$/); assert(result.size > 0);
    const bytes = await readFile(output); assert.equal(bytes.subarray(0, 8).toString(), '!<arch>\n');
    const actual = await inspectDeb(output); assert.deepEqual(actual.members.map(m => m.name), ['debian-binary', 'control.tar.gz', 'data.tar.gz']);
    assert.match(actual.control, /^Version: 0\.1\.0$/m); assert.match(actual.control, /^Architecture: amd64$/m); assert.match(actual.control, /maintainers@vibra\.invalid/);
    for (const member of actual.members) assert.equal((member.offset - 60) % 2, 0);
    const entries = new Map(actual.entries.map(e => [e.name, e]));
    assert.equal(entries.get('opt/Vibra/vibra').magic, '7f454c46'); assert.equal(entries.get('opt/Vibra/vibra').mode, 0o755);
    assert.equal(entries.get('opt/Vibra/chrome-sandbox').mode, 0o4755); assert.equal(entries.get('opt/Vibra/chrome_crashpad_handler').mode, 0o755);
    assert.equal(entries.get('usr/bin/vibra').mode, 0o755); assert(entries.has('usr/share/applications/vibra.desktop')); assert(entries.has('opt/Vibra/resources/app.asar'));
    assert(actual.entries.every(e => e.uid === 0 && e.gid === 0));
    await writeFile(path.join(source, 'secrets.txt'), 'must never be packaged');
    await assert.rejects(buildDeb({ sourceDir: source, output: path.join(root, 'bad.deb'), icon }), /Unexpected runtime content/);
    const damaged = Buffer.from(bytes); damaged[0] = 0; const bad = path.join(root, 'damaged.deb'); await writeFile(bad, damaged); await assert.rejects(inspectDeb(bad), /ar magic/);
  } finally { await rm(root, { recursive: true, force: true }); }
});
