import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {mkdtempSync,rmSync,mkdirSync} from 'node:fs';
import {homedir,tmpdir} from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url),{captureAudioCapabilities,captureStreams}=require('../desktop/capture-audio.cjs');
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');

test('native screen audio is pinned to audited runtime and Windows process exclusion support',()=>{
 const yes=captureAudioCapabilities({platform:'win32',electron:'44.9.0',release:'10.0.22631'});
 assert.equal(yes.systemAudio,true);assert.equal(yes.excludesOwnAudio,true);assert.equal(yes.reason,null);
 for(const input of [{platform:'linux',release:'6.1.0'},{platform:'darwin',release:'25.0.0'},{platform:'win32',release:'10.0.19045'},{platform:'win32',release:'unknown'},{platform:'win32',release:'10.0.22631',electron:'44.8.0'},{platform:'win32',release:'10.0.22631',electron:'45.0.0'}]){
  const result=captureAudioCapabilities({electron:'44.9.0',...input});assert.equal(result.systemAudio,false);assert.equal(result.excludesOwnAudio,false);assert(result.reason);
 }
 const source={id:'screen:test',name:'Owned test source'};
 assert.deepEqual(captureStreams(source,{requested:true,enabled:true,capabilities:yes}),{video:source,audio:'loopbackWithoutChrome'});
 for(const options of [{requested:false,enabled:true,capabilities:yes},{requested:true,enabled:false,capabilities:yes},{requested:true,enabled:'loopback',capabilities:captureAudioCapabilities({platform:'linux'})},{requested:true,enabled:true,capabilities:{systemAudio:true,excludesOwnAudio:false}}])assert.deepEqual(captureStreams(source,options),{video:source});
});

test('desktop capability bridge and picker preserve video on unsupported audio; foreign IPC cannot grant capture',{timeout:45000},async t=>{
 const {_electron:electron}=require(path.join(process.env.VIBRA_NODE_MODULES||path.join(homedir(),'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules'),'playwright'));
 const userData=mkdtempSync(path.join(tmpdir(),'vibra-capture-audio-'));let app;
 t.after(async()=>{await app?.close().catch(()=>{});rmSync(userData,{recursive:true,force:true})});
 const env={...process.env,VIBRA_DESKTOP_TEST:'1',VIBRA_DESKTOP_TEST_LOCAL:'0',VIBRA_USER_DATA:userData};delete env.ELECTRON_RUN_AS_NODE;
 app=await electron.launch({executablePath:path.join(root,'node_modules/electron/dist',process.platform==='win32'?'electron.exe':process.platform==='darwin'?'Electron.app/Contents/MacOS/Electron':'electron'),args:[root,'--use-fake-device-for-media-stream'],env});
 const chooser=await app.firstWindow();await chooser.locator('#local-connect').waitFor();
 await app.evaluate(({session,desktopCapturer,nativeImage})=>{
  // Only our explicit synthetic source exists. Intercept the final callback and
  // reject before Chromium can acquire any personal screen or system audio.
  const pixels=Buffer.alloc(160*90*4);for(let i=0;i<pixels.length;i+=4){pixels[i]=60;pixels[i+1]=38;pixels[i+2]=45;pixels[i+3]=255}const thumbnail=nativeImage.createFromBitmap(pixels,{width:160,height:90});
  desktopCapturer.getSources=async()=>[{id:'screen:owned-test:0',name:'Owned synthetic source',thumbnail}];
  const prototype=Object.getPrototypeOf(session.defaultSession),original=prototype.setDisplayMediaRequestHandler;
  prototype.setDisplayMediaRequestHandler=function(handler,options){return original.call(this,(request,callback)=>handler(request,streams=>{globalThis.__captureGrant=streams?{video:streams.video?.id,audio:streams.audio||null}:null;callback(null)}),options)};
 });
 await chooser.locator('#local-connect').click();
 let page;for(let i=0;i<100;i++){page=app.windows().find(w=>/^http:\/\/127\.0\.0\.1:/.test(w.url()));if(page)break;await new Promise(r=>setTimeout(r,30))}assert(page);await page.locator('#auth-form').waitFor();
 const capabilities=await page.evaluate(()=>window.vibraCapture.capabilities());assert.deepEqual(capabilities,captureAudioCapabilities({electron:'44.9.0'}));
 const forged=await app.evaluate(async({BrowserWindow})=>{const win=new BrowserWindow({show:false,webPreferences:{nodeIntegration:true,contextIsolation:false,sandbox:false}});await win.loadURL('about:blank');const result={};for(const channel of ['desktop:capture-capabilities','desktop:source-options','desktop:choose'])result[channel]=await win.webContents.executeJavaScript(`require('electron').ipcRenderer.invoke(${JSON.stringify(channel)},{id:'screen:owned-test:0',audio:true}).then(()=>null,e=>e.message)`);win.destroy();return result});
 for(const error of Object.values(forged))assert.match(error||'',/Нет доступа/);
 await page.evaluate(()=>{const button=document.createElement('button');button.id='capture-audio-test';button.textContent='Owned capture test';button.onclick=()=>{window.__captureResult='pending';navigator.mediaDevices.getDisplayMedia({video:true,audio:{restrictOwnAudio:true,suppressLocalAudioPlayback:false}}).then(s=>{s.getTracks().forEach(track=>track.stop());window.__captureResult='unexpected'},e=>window.__captureResult=e.name)};document.body.append(button)});
 await page.locator('#capture-audio-test').click();
 let picker;for(let i=0;i<100;i++){picker=app.windows().find(w=>/\/picker\.html$/.test(w.url()));if(picker)break;await new Promise(r=>setTimeout(r,30))}assert(picker,'Audio request should reach the explicit source picker');
 await picker.locator('.source-card').waitFor();await picker.waitForFunction(()=>!document.querySelector('#audio-note').textContent.includes('Проверяем'));
 assert.equal(await picker.locator('#share-audio').isDisabled(),!capabilities.systemAudio);assert.equal(await picker.locator('#share-audio').isChecked(),capabilities.systemAudio);
 if(capabilities.reason)assert.equal(await picker.locator('#audio-note').textContent(),capabilities.reason);
 mkdirSync(path.join(root,'test-output'),{recursive:true});await picker.screenshot({path:path.join(root,'test-output/capture-audio-picker.png')});
 await picker.locator('.source-card').click();await picker.locator('#share').click().catch(error=>assert.match(error.message,/closed/));await page.waitForFunction(()=>window.__captureResult!=='pending');
 assert.deepEqual(await app.evaluate(()=>globalThis.__captureGrant),{video:'screen:owned-test:0',audio:capabilities.systemAudio?'loopbackWithoutChrome':null});
 assert.match(await page.evaluate(()=>window.__captureResult),/AbortError|NotAllowedError/);
});
