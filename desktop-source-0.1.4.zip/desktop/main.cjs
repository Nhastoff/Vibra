'use strict';
const {app,BrowserWindow,Menu,Tray,nativeImage,ipcMain,session,desktopCapturer,dialog,systemPreferences,nativeTheme}=require('electron');
const fs=require('node:fs');const path=require('node:path');const {pathToFileURL}=require('node:url');const {randomInt}=require('node:crypto');
app.setName('Vibra');
if(process.env.VIBRA_DESKTOP_TEST==='1'&&process.env.VIBRA_USER_DATA)app.setPath('userData',path.resolve(process.env.VIBRA_USER_DATA));
const root=path.resolve(__dirname,'..'),connectURL=pathToFileURL(path.join(__dirname,'connect.html')).href,pickerURL=pathToFileURL(path.join(__dirname,'picker.html')).href;
let mainWindow=null,chooser=null,picker=null,pendingCapture=null,activeOrigin=null,localModule=null,localOrigin=null,config={},switching=false,quitting=false,shutdownStarted=false,nativeMenu=null;
const microphoneGrants=new Set(),microphoneRequests=new Map();
const updater=globalThis[Symbol.for('vibra.updateRuntime')];
const applicationVersion=()=>updater?.version||app.getVersion();
updater?.setOnChange(buildMenu);
updater?.setBeforeRestart(async()=>{if(localModule?.db){const directory=path.join(app.getPath('userData'),'backups');fs.mkdirSync(directory,{recursive:true,mode:0o700});await require('node:sqlite').backup(localModule.db,path.join(directory,'before-update-'+Date.now()+'.sqlite'))}});
const icon=path.join(root,'build','icons','icon.png');
const chromeCSS=fs.readFileSync(path.join(__dirname,'chrome.css'),'utf8');
function chromeOptions(){return process.platform==='darwin'?{titleBarStyle:'hiddenInset'}:{titleBarStyle:'hidden',titleBarOverlay:{color:'#11121a',symbolColor:'#b7bad0',height:32}}}
function decorateWindow(win){win.setMenu(null);win.setMenuBarVisibility(false);win.webContents.on('dom-ready',()=>{if(win.isDestroyed())return;const url=win.webContents.getURL();if(url===connectURL||url===pickerURL||trusted(win.webContents,url))win.webContents.insertCSS(chromeCSS).catch(()=>{})})}
const dialogs=require('./dialogs.cjs')({BrowserWindow,ipcMain,icon,chromeOptions,decorateWindow,prefs,protect});
const trayController=require('./tray.cjs').createTrayController({app,Tray,Menu,nativeImage,icon,getWindow:()=>mainWindow||chooser,onHide:()=>{dialogs.cancel();cancelCapture()}});
function readConfig(){try{config=JSON.parse(fs.readFileSync(path.join(app.getPath('userData'),'desktop-config.json'),'utf8'));if(!config||typeof config!=='object')config={}}catch{config={}}microphoneGrants.clear();for(const value of Array.isArray(config.microphoneOrigins)?config.microphoneOrigins:[]){try{microphoneGrants.add(validateOrigin(value))}catch{}}}
function saveConfig(){fs.mkdirSync(app.getPath('userData'),{recursive:true});fs.writeFileSync(path.join(app.getPath('userData'),'desktop-config.json'),JSON.stringify(config,null,2),{mode:0o600})}
function validateOrigin(input){if(typeof input!=='string'||input.length>2048)throw Error('Введите адрес сервера.');let url;try{url=new URL(input.trim())}catch{throw Error('Введите полный адрес: https://vibra.example.org')}
 const loopback=['localhost','127.0.0.1','[::1]'].includes(url.hostname);
 if(url.username||url.password||url.search||url.hash||url.pathname!=='/'||!['https:','http:'].includes(url.protocol)||url.protocol==='http:'&&!loopback)throw Error('Нужен HTTPS-адрес без пути, логина и параметров. HTTP разрешён только для localhost, 127.0.0.1 и [::1].');return url.origin;
}
function trusted(wc,url){if(!mainWindow||wc!==mainWindow.webContents||wc.isDestroyed()||!activeOrigin)return false;try{return new URL(url).origin===activeOrigin&&new URL(wc.getURL()).origin===activeOrigin}catch{return false}}
function localSender(event,win,url){return !!win&&!win.isDestroyed()&&event.sender===win.webContents&&event.senderFrame===win.webContents.mainFrame&&event.senderFrame.url===url&&event.sender.getURL()===url}
function prefs(preload,partition){return {nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,allowRunningInsecureContent:false,...(preload?{preload:path.join(__dirname,preload)}:{}),...(partition?{partition}:{})}}
function protect(win,allowed){win.webContents.setWindowOpenHandler(()=>({action:'deny'}));win.webContents.on('will-navigate',(e,url)=>{if(!allowed(url))e.preventDefault()});win.webContents.on('will-redirect',(e,url)=>{if(!allowed(url))e.preventDefault()});win.webContents.on('will-attach-webview',e=>e.preventDefault());win.webContents.session.on('will-download',e=>e.preventDefault())}
async function localServer(){if(localOrigin)return localOrigin;process.env.DATA_DIR=path.join(app.getPath('userData'),'data');localModule=await import(pathToFileURL(path.join(root,'server.mjs')).href);
 let desired=Number(config.localPort);if(!Number.isInteger(desired)||desired<49000||desired>59999)desired=randomInt(49000,60000);
 for(let attempt=0;attempt<12;attempt++){try{await new Promise((resolve,reject)=>{const srv=localModule.server;const error=e=>{srv.off('listening',listen);reject(e)},listen=()=>{srv.off('error',error);resolve()};srv.once('error',error);srv.once('listening',listen);srv.listen(desired,'127.0.0.1')});config.localPort=localModule.server.address().port;saveConfig();localOrigin='http://127.0.0.1:'+config.localPort;return localOrigin}catch(error){if(error.code!=='EADDRINUSE')throw error;desired=randomInt(49000,60000)}}throw Error('Не удалось запустить локальное пространство: нет свободного порта.');
}
function cancelCapture(){if(!pendingCapture)return;const pending=pendingCapture;pendingCapture=null;clearTimeout(pending.timer);try{pending.callback(null)}catch{}if(picker&&!picker.isDestroyed())picker.close();picker=null}
function configurePermissions(ses){
 ses.setPermissionCheckHandler((wc,permission,origin,details)=>{if(!trusted(wc,origin)||details?.isMainFrame===false)return false;if(permission==='media')return details?.mediaType==='audio'&&microphoneGrants.has(activeOrigin);return ['fullscreen','clipboard-sanitized-write','display-capture'].includes(permission)});
 ses.setPermissionRequestHandler(async(wc,permission,callback,details)=>{try{
  const origin=details?.requestingUrl||wc?.getURL();if(!trusted(wc,origin)||details?.isMainFrame===false){callback(false);return}
  if(permission==='fullscreen'||permission==='clipboard-sanitized-write'||permission==='display-capture'){callback(true);return}
  // Electron 44 routes display capture through an empty media-types request.
  // Actual display access still requires the separate top-frame, gesture,
  // video-only handler below and an explicit source selection. Camera requests
  // carry ['video'] and remain denied.
  if(permission==='media'&&Array.isArray(details.mediaTypes)&&details.mediaTypes.length===0){callback(true);return}
  if(permission!=='media'||!Array.isArray(details.mediaTypes)||details.mediaTypes.length!==1||details.mediaTypes[0]!=='audio'){callback(false);return}
  const approvedOrigin=activeOrigin;
  let operation=microphoneRequests.get(approvedOrigin);
  if(!operation){operation=(async()=>{
   let allowed=microphoneGrants.has(approvedOrigin);
   if(!allowed)allowed=await dialogs.show({kind:'microphone',title:'Микрофон для вашей компании',description:'Вас будет слышно в голосовом канале. Микрофон также нужен для проверки звука в настройках.',origin:approvedOrigin,detail:'Запомним разрешение для этого сервера. Изменить решение можно в меню «··· → Подключение → Отозвать разрешение микрофона».',confirm:'Разрешить микрофон',cancel:'Не сейчас',parent:mainWindow});
   if(!trusted(wc,origin)||activeOrigin!==approvedOrigin)return false;
   if(allowed&&process.platform==='darwin')allowed=await systemPreferences.askForMediaAccess('microphone');
   if(!trusted(wc,origin)||activeOrigin!==approvedOrigin)return false;
   if(allowed){microphoneGrants.add(approvedOrigin);config.microphoneOrigins=[...microphoneGrants];saveConfig();buildMenu()}
   return allowed;
  })().finally(()=>microphoneRequests.delete(approvedOrigin));microphoneRequests.set(approvedOrigin,operation)}
  callback(await operation&&trusted(wc,origin)&&activeOrigin===approvedOrigin);
 }catch{try{callback(false)}catch{}}
 });
 ses.setDisplayMediaRequestHandler(async(request,originalCallback)=>{
  let completed=false;const callback=value=>{if(completed)return;completed=true;try{originalCallback(value)}catch{}};
  const frame=request.frame;
  if(!mainWindow||!frame||frame!==mainWindow.webContents.mainFrame||frame!==frame.top||!trusted(mainWindow.webContents,request.securityOrigin)||!request.userGesture||!request.videoRequested||request.audioRequested||pendingCapture){callback(null);return}
  const requester=mainWindow.webContents,origin=activeOrigin;
  const capture={callback,sources:[],requester,origin,frame,timer:setTimeout(cancelCapture,120000)};pendingCapture=capture;
  try{const sources=await desktopCapturer.getSources({types:['screen','window'],thumbnailSize:{width:360,height:220},fetchWindowIcons:true});if(pendingCapture!==capture)return;if(!trusted(requester,origin)||!sources.length){cancelCapture();return}capture.sources=sources;
   const captureWindow=picker=new BrowserWindow({...chromeOptions(),width:830,height:650,minWidth:640,minHeight:500,parent:mainWindow,modal:true,title:'Vibra — выбрать экран',backgroundColor:'#15161f',autoHideMenuBar:true,icon,webPreferences:prefs('picker-preload.cjs','vibra-picker')});
   decorateWindow(captureWindow);protect(captureWindow,url=>url===pickerURL);captureWindow.on('closed',()=>{if(picker===captureWindow)picker=null;if(pendingCapture===capture)cancelCapture()});await captureWindow.loadURL(pickerURL);
  }catch{if(pendingCapture===capture)cancelCapture();callback(null)}
 },{useSystemPicker:process.platform==='darwin'});
}
function connectionTarget(input){let parsed;try{parsed=new URL(String(input).trim())}catch{return{origin:validateOrigin(input)}}const call=parsed.pathname==='/call.html'&&/^#[a-f0-9]{64}$/.test(parsed.hash)&&!parsed.search;const invite=/^\/i\/[A-Za-z0-9_-]{8}$/.test(parsed.pathname)&&!parsed.hash&&!parsed.search;const legacyInvite=parsed.pathname==='/'&&!parsed.hash&&parsed.searchParams.size===1&&/^(?:[A-Za-z0-9_-]{8}|[a-f0-9]{64})$/.test(parsed.searchParams.get('invite')||'');if((call||invite||legacyInvite)&&!parsed.username&&!parsed.password){const origin=validateOrigin(parsed.origin);return{origin,url:parsed.href}}return{origin:validateOrigin(input)}}
async function openConnection(origin,initialURL){origin=validateOrigin(origin);dialogs.cancel();cancelCapture();activeOrigin=origin;
 const previous=mainWindow;if(previous&&!previous.isDestroyed()){mainWindow=null;previous.destroy()}
 const win=mainWindow=new BrowserWindow({...chromeOptions(),width:1400,height:900,minWidth:880,minHeight:600,title:'Vibra',backgroundColor:'#15161f',show:false,icon,autoHideMenuBar:true,webPreferences:{...prefs('chrome-preload.cjs','persist:vibra'),backgroundThrottling:false}});trayController.attach(win);
 decorateWindow(win);updater?.registerWindow(win,event=>event.senderFrame===win.webContents.mainFrame&&trusted(event.sender,event.senderFrame.url));protect(win,url=>{try{return new URL(url).origin===activeOrigin}catch{return false}});
 win.webContents.on('did-start-navigation',(_event,_url,isInPlace,isMainFrame)=>{if(isMainFrame&&!isInPlace)cancelCapture()});win.on('closed',()=>{if(mainWindow===win){cancelCapture();mainWindow=null;activeOrigin=null}});
 const ses=win.webContents.session;configurePermissions(ses);
 try{await win.loadURL(initialURL||origin);if(win.isDestroyed())return;win.show();updater?.markHealthy();if(chooser&&!chooser.isDestroyed()){chooser.destroy();chooser=null}switching=false;buildMenu()}catch(error){win.destroy();mainWindow=null;activeOrigin=null;throw Error('Не удалось подключиться к '+origin+'. Проверьте адрес, сеть и сертификат сервера.')}
}
async function showChooser(){switching=true;dialogs.cancel();cancelCapture();if(mainWindow&&!mainWindow.isDestroyed()){mainWindow.destroy();mainWindow=null}activeOrigin=null;if(chooser&&!chooser.isDestroyed()){chooser.show();chooser.focus();return}
 chooser=new BrowserWindow({...chromeOptions(),width:1000,height:740,minWidth:880,minHeight:600,title:'Vibra — подключение',backgroundColor:'#15161f',icon,webPreferences:prefs('connect-preload.cjs','vibra-connect')});trayController.attach(chooser);decorateWindow(chooser);updater?.registerWindow(chooser,event=>localSender(event,chooser,connectURL));protect(chooser,url=>url===connectURL);chooser.on('closed',()=>{chooser=null;if(!mainWindow&&!quitting)app.quit()});await chooser.loadURL(connectURL);updater?.markHealthy();switching=false;buildMenu();
}
function buildMenu(){const template=[...(process.platform==='darwin'?[{label:'Vibra',submenu:[{role:'about'},{type:'separator'},{role:'quit'}]}]:[]),{label:'Подключение',submenu:[{label:'Выбрать сервер…',click:()=>showChooser().catch(showFatal)},{label:'Текущий сервер',enabled:false,sublabel:activeOrigin||'Не подключено'},{label:'Отозвать разрешение микрофона',enabled:!!activeOrigin&&microphoneGrants.has(activeOrigin),click:()=>{microphoneGrants.delete(activeOrigin);config.microphoneOrigins=[...microphoneGrants];saveConfig();mainWindow?.reload();buildMenu()}},{type:'separator'},{role:'quit',label:'Выйти из Vibra'}]},{label:'Правка',submenu:[{role:'undo',label:'Отменить'},{role:'redo',label:'Повторить'},{type:'separator'},{role:'cut',label:'Вырезать'},{role:'copy',label:'Копировать'},{role:'paste',label:'Вставить'},{role:'selectAll',label:'Выделить всё'}]},{label:'Вид',submenu:[{role:'reload',label:'Перезагрузить интерфейс'},{role:'resetZoom',label:'Обычный размер'},{role:'zoomIn',label:'Увеличить'},{role:'zoomOut',label:'Уменьшить'},{role:'togglefullscreen',label:'Полноэкранный режим'}]},{label:'Справка',submenu:[{label:updater?.statusLabel()||'Проверить обновления',enabled:updater?.state.status!=='downloading',click:()=>{const status=updater?.state.status;if(status==='available')updater.download();else if(status==='ready')updater.restart();else updater?.check()}},{type:'separator'},{label:'О Vibra',click:()=>dialogs.show({title:'На одной волне',description:'Vibra '+applicationVersion(),detail:'Текст, голос и общий экран. Для Windows, Linux и macOS.',confirm:'Продолжить',parent:mainWindow||chooser})}]}];nativeMenu=Menu.buildFromTemplate(template);Menu.setApplicationMenu(process.platform==='darwin'?nativeMenu:null);for(const win of BrowserWindow.getAllWindows()){win.setMenu(null);win.setMenuBarVisibility(false)}}
async function showFatal(error){await dialogs.show({kind:'error',title:'Не удалось продолжить',description:error.message||'Не удалось запустить приложение.',detail:'Проверьте подключение и попробуйте снова.',parent:mainWindow||chooser})}
ipcMain.on('desktop:menu',event=>{const isMain=mainWindow&&!mainWindow.isDestroyed()&&event.sender===mainWindow.webContents&&event.senderFrame===mainWindow.webContents.mainFrame&&trusted(event.sender,event.senderFrame.url);const isChooser=localSender(event,chooser,connectURL);if(!isMain&&!isChooser)return;nativeMenu?.popup({window:isMain?mainWindow:chooser})});
ipcMain.handle('desktop:config',event=>{if(!localSender(event,chooser,connectURL))throw Error('Нет доступа');return {version:applicationVersion(),url:config.mode==='remote'?config.url||'':'',mode:config.mode||null}});
ipcMain.handle('desktop:connect',async(event,input)=>{if(!localSender(event,chooser,connectURL))throw Error('Нет доступа');if(!input||!['local','remote'].includes(input.mode))throw Error('Выберите способ подключения');const target=input.mode==='local'?{origin:await localServer()}:connectionTarget(input.url);await openConnection(target.origin,target.url);config={...config,mode:input.mode,...(input.mode==='remote'?{url:target.origin}:{})};saveConfig();return{ok:true}});
ipcMain.handle('desktop:sources',event=>{if(!pendingCapture||!localSender(event,picker,pickerURL))throw Error('Нет доступа');return pendingCapture.sources.map(source=>({id:source.id,name:source.name,type:source.id.startsWith('screen:')?'screen':'window',thumbnail:source.thumbnail.toDataURL(),icon:source.appIcon?.toDataURL()||null}))});
ipcMain.handle('desktop:choose',(event,id)=>{if(!pendingCapture||!localSender(event,picker,pickerURL))throw Error('Нет доступа');if(id===null){cancelCapture();return{ok:true}}const p=pendingCapture,source=p.sources.find(s=>s.id===id);if(!source||!trusted(p.requester,p.origin)||p.frame!==p.requester.mainFrame)throw Error('Источник недоступен');pendingCapture=null;clearTimeout(p.timer);p.callback({video:source});if(picker&&!picker.isDestroyed())picker.close();picker=null;return{ok:true}});
if(!app.requestSingleInstanceLock())app.quit();else{
 app.on('second-instance',()=>trayController.restore());
 app.whenReady().then(async()=>{nativeTheme.themeSource='dark';readConfig();trayController.start();buildMenu();updater?.start();if(process.env.VIBRA_DESKTOP_TEST==='1'&&process.env.VIBRA_DESKTOP_TEST_LOCAL==='1'){await openConnection(await localServer());if(process.env.VIBRA_DESKTOP_SMOKE==='1'){console.log('VIBRA_DESKTOP_READY '+applicationVersion());app.quit()}return}if(config.mode){try{await openConnection(config.mode==='local'?await localServer():validateOrigin(config.url));return}catch{}}await showChooser()}).catch(async error=>{await showFatal(error);app.quit()});
 app.on('activate',()=>{if(!trayController.restore()&&!BrowserWindow.getAllWindows().length)showChooser().catch(showFatal)});
 app.on('window-all-closed',()=>{if(!switching&&process.platform!=='darwin')app.quit()});
 app.on('before-quit',event=>{if(shutdownStarted)return;shutdownStarted=true;quitting=true;dialogs.cancel();cancelCapture();if(localModule?.server?.listening){event.preventDefault();localModule.server.closeAllConnections();localModule.server.close(()=>{try{localModule.db.close()}catch{}app.quit()});setTimeout(()=>app.exit(),1500).unref()}else{try{localModule?.db.close()}catch{}}});
}
