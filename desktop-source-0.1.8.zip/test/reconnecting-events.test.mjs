import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';

const settle=()=>new Promise(setImmediate);
function setup({hang=false}={}) {
 let now=1000,opened=0,lost=0;const sources=[],timers=new Map(),intervals=[],listeners=new Map(),requests=[];
 const events={addEventListener:(name,fn)=>listeners.set(name,fn),removeEventListener:(name,fn)=>{if(listeners.get(name)===fn)listeners.delete(name)}};
 class Source {
  constructor(url){this.url=url;this.listeners=new Map();sources.push(this)}
  addEventListener(name,fn){this.listeners.set(name,fn)}
  emit(name,data={}){this.listeners.get(name)?.({data:JSON.stringify(data)})}
  close(){this.closed=true}
 }
 const navigator={onLine:true};
 const sandbox={window:events,document:{...events,hidden:false},navigator,EventSource:Source,AbortController,console,
  Date:class extends Date{static now(){return now}},
  setTimeout:(fn,ms)=>{const id={fn,ms};timers.set(id,id);return id},clearTimeout:id=>timers.delete(id),
  setInterval:fn=>{intervals.push(fn);return fn},clearInterval:fn=>{const i=intervals.indexOf(fn);if(i>=0)intervals.splice(i,1)}
 };
 const code=readFileSync(new URL('../public/reconnecting-events.js',import.meta.url),'utf8').replace('export class ReconnectingEvents','class ReconnectingEvents')+'\nglobalThis.Events=ReconnectingEvents;';
 vm.runInNewContext(code,sandbox);
 const controller=new sandbox.Events({request:async(path,method,body,options)=>{
  requests.push({path,method,body,signal:options.signal});
  if(hang)await new Promise((resolve,reject)=>options.signal.addEventListener('abort',()=>reject(Object.assign(Error('aborted'),{name:'AbortError'})),{once:true}));
  return {ok:true};
 },onOpen:()=>opened++,onDisconnect:()=>lost++});
 return {controller,sources,timers,intervals,listeners,navigator,requests,advance:ms=>{now+=ms},get opened(){return opened},get lost(){return lost}};
}

test('closed SSE is explicitly replaced, stale callbacks cannot mark the new connection online',async()=>{
 const state=setup();const {controller,sources,timers}=state;
 sources[0].emit('ready',{connectionId:'first'});await settle();assert.equal(state.opened,1);
 assert.equal(state.requests[0].path,'/api/events/ping');
 sources[0].onerror();assert.equal(sources[0].closed,true);assert.equal(state.lost,1);
 const retry=[...timers.values()].find(t=>t.ms===500);assert(retry);retry.fn();
 assert.equal(sources.length,2);sources[0].emit('ready',{connectionId:'stale'});await settle();assert.equal(state.opened,1);
 sources[1].emit('ready',{connectionId:'second'});await settle();assert.equal(state.opened,2);
 controller.close();assert.equal(state.listeners.size,0);assert.equal(state.intervals.length,0);
});

test('offline pauses requests; online immediately reconnects; a silent VPN socket is detected',async()=>{
 const state=setup();state.navigator.onLine=false;state.listeners.get('offline')();
 const retry=[...state.timers.values()].find(t=>t.ms===500);retry.fn();assert.equal(state.sources.length,1);
 state.navigator.onLine=true;state.listeners.get('online')();assert.equal(state.sources.length,2);
 state.sources[1].emit('ready',{connectionId:'restored'});await settle();assert.equal(state.opened,1);
 state.advance(19000);state.intervals[0]();assert.equal(state.sources[1].closed,true);assert.equal(state.controller.connected,false);
 state.controller.close();
});

test('acknowledgements do not overlap and a hung fetch is aborted before retry',async()=>{
 const state=setup({hang:true});state.sources[0].emit('ready',{connectionId:'pending'});
 state.sources[0].emit('heartbeat');state.sources[0].emit('heartbeat');assert.equal(state.requests.length,1);
 const deadline=[...state.timers.values()].find(t=>t.ms===8000);deadline.fn();await settle();
 assert.equal(state.requests[0].signal.aborted,true);assert.equal(state.sources[0].closed,true);
 assert.equal(state.controller.connected,false);assert([...state.timers.values()].some(t=>t.ms===500));
 state.controller.close();
});
