import {createHmac} from 'node:crypto';

// Coturn REST authentication: clients receive a short-lived per-user credential,
// never the shared signing secret. Existing static ICE configurations still work.
export function createTurnCredentials(env={}) {
 const secret=env.VIBRA_TURN_SECRET,raw=env.VIBRA_TURN_URLS_JSON;
 if(secret===undefined&&raw===undefined)return null;
 const invalid=()=>{throw new Error('VIBRA_TURN: нужны секрет длиной 32–256 символов и массив TURN URL');};
 if(typeof secret!=='string'||secret.length<32||secret.length>256||typeof raw!=='string')invalid();
 let urls;try{urls=JSON.parse(raw);}catch{invalid();}
 if(!Array.isArray(urls)||!urls.length||urls.length>4||!urls.every(u=>typeof u==='string'&&u.length<=500&&/^turns?:[^\s]+$/.test(u)))invalid();
 return (userId,now=Date.now())=>{
  if(typeof userId!=='string'||!/^[a-f0-9]{32}$/.test(userId)||!Number.isSafeInteger(now)||now<0)throw new Error('VIBRA_TURN: некорректный пользователь или время');
  const username=`${Math.floor(now/1000)+43200}:${userId}`;
  return {urls:[...urls],username,credential:createHmac('sha1',secret).update(username).digest('base64')};
 };
}
