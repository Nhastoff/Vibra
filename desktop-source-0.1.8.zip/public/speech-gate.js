// RNNoise supplies a speech probability for each 10 ms frame. Keep 20 ms
// of lookahead so confirmation does not remove the start of a word.
export class SpeechGate {
  constructor(frameSize = 480, rate = 48000) {
    this.delay = Array.from({length: 3}, () => new Float32Array(frameSize));
    this.position = 0;
    this.confirmed = 0;
    this.hold = 0;
    this.gain = 0.01;
    this.attack = Math.exp(-1 / (rate * 0.003));
    this.release = Math.exp(-1 / (rate * 0.06));
  }
  process(frame, probability) {
    this.delay[this.position].set(frame);
    this.position = (this.position + 1) % this.delay.length;
    this.confirmed = probability >= 0.65 ? this.confirmed + 1 : 0;
    if (this.confirmed >= 2 || (this.hold > 0 && probability >= 0.35)) this.hold = 18;
    const target = this.hold > 0 ? 1 : 0.01;
    if (this.hold > 0) this.hold--;
    const delayed = this.delay[this.position];
    for (let i = 0; i < frame.length; i++) {
      const coefficient = target > this.gain ? this.attack : this.release;
      this.gain = target + (this.gain - target) * coefficient;
      frame[i] = delayed[i] * this.gain;
    }
    return frame;
  }
}
