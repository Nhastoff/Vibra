'use strict';
const path=require('node:path');
const {pathToFileURL}=require('node:url');

// Only the bundled, sandboxed document can read or answer its own dialog.
module.exports=function createDialogs({BrowserWindow,ipcMain,icon,chromeOptions,decorateWindow,prefs,protect}){
 const url=pathToFileURL(path.join(__dirname,'dialog.html')).href,pending=new Map();
 function own(event){const item=pending.get(event.sender.id);return item&&!item.win.isDestroyed()&&event.sender===item.win.webContents&&event.senderFrame===item.win.webContents.mainFrame&&event.senderFrame.url===url&&event.sender.getURL()===url?item:null}
 ipcMain.handle('desktop:dialog-state',event=>{const item=own(event);if(!item)throw Error('Нет доступа');return item.state});
 ipcMain.handle('desktop:dialog-answer',(event,answer)=>{const item=own(event);if(!item||typeof answer!=='boolean')throw Error('Нет доступа');item.finish(answer);return {ok:true}});
 function show({kind='info',title,description,origin='',detail='',confirm='Понятно',cancel='',parent}){
  return new Promise(resolve=>{
   const win=new BrowserWindow({...chromeOptions(),width:580,height:kind==='microphone'?540:430,minWidth:480,minHeight:kind==='microphone'?500:400,resizable:true,maximizable:false,minimizable:false,show:false,...(parent&&!parent.isDestroyed()?{parent,modal:true}:{}),title:'Vibra',backgroundColor:'#171821',icon,webPreferences:prefs('dialog-preload.cjs','vibra-dialog')});
   const senderId=win.webContents.id;let done=false;
   const cleanup=()=>{clearTimeout(timer);parent?.webContents?.removeListener('did-start-navigation',navigating);pending.delete(senderId)};
   const finish=answer=>{if(done)return;done=true;cleanup();resolve(answer===true);if(!win.isDestroyed())win.close()};
   const navigating=(_event,_url,inPlace,isMain)=>{if(isMain&&!inPlace)finish(false)};
   const timer=setTimeout(()=>finish(false),kind==='microphone'?120000:600000);timer.unref();
   pending.set(win.webContents.id,{win,state:{kind,title,description,origin,detail,confirm,cancel},finish});
   parent?.webContents?.on('did-start-navigation',navigating);
   decorateWindow(win);protect(win,target=>target===url);
   win.on('closed',()=>finish(false));win.webContents.on('render-process-gone',()=>finish(false));
   win.loadURL(url).then(()=>{if(!done&&!win.isDestroyed()){win.show();win.focus()}}).catch(()=>finish(false));
  });
 }
 function cancel(){for(const item of [...pending.values()])item.finish(false)}
 return {show,cancel};
};
