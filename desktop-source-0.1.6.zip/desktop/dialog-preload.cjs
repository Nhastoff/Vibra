'use strict';
const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('vibraDialog',Object.freeze({read:()=>ipcRenderer.invoke('desktop:dialog-state'),answer:value=>ipcRenderer.invoke('desktop:dialog-answer',value)}));
window.addEventListener('DOMContentLoaded',()=>{document.documentElement.classList.add('vibra-desktop');if(process.platform==='darwin')document.documentElement.classList.add('vibra-platform-mac')});
