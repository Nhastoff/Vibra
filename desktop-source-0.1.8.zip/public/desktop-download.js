const releases='https://github.com/Nhastoff/Vibra/releases';
export const desktopPackages=Object.freeze({
 windows:{label:'Windows x64',url:releases+'/download/v0.1.8/Vibra-0.1.8-Setup-x64.exe'},
 macArm:{label:'macOS · Apple Silicon',url:releases+'/download/v0.1.8/Vibra-0.1.8-mac-arm64.dmg'},
 macIntel:{label:'macOS · Intel',url:releases+'/download/v0.1.8/Vibra-0.1.8-mac-x64.dmg'},
 linux:{label:'Linux · Ubuntu / Debian x64',url:releases+'/download/v0.1.8/Vibra-0.1.8-linux-amd64.deb'}
});

export function detectDesktopSystem(info,hints={}) {
 const ua=info.userAgent||'',platform=info.userAgentData?.platform||info.platform||'';
 const mobile=!!info.userAgentData?.mobile||/Android|iPhone|iPad|iPod|Windows Phone/i.test(ua)||/Mac/i.test(platform)&&info.maxTouchPoints>1;
 if(mobile)return{os:'mobile',architecture:'unknown'};
 const system=platform||ua;
 const os=/Win/i.test(system)?'windows':/Mac/i.test(system)?'mac':/Linux|X11/i.test(system)?'linux':'unknown';
 let architecture='unknown';
 if(/arm|aarch64/i.test(hints.architecture||''))architecture='arm64';
 else if(/x86|x64|amd64/i.test(hints.architecture||'')&&hints.bitness!=='32')architecture='x64';
 else if(os!=='mac'){
  if(/aarch64|arm64/i.test(platform+' '+ua))architecture='arm64';
  else if(/x86_64|x64|amd64|Win64|WOW64/i.test(platform+' '+ua))architecture='x64';
 }
 // Safari can report MacIntel on Apple Silicon; do not guess the chip from it.
 return {os,architecture};
}

export function desktopDownloadChoice(system) {
 if(system.os==='windows')return{...desktopPackages.windows,text:'Скачать для Windows',note:'Установщик .exe · Windows x64'};
 if(system.os==='mac'){
  const pack=system.architecture==='arm64'?desktopPackages.macArm:system.architecture==='x64'?desktopPackages.macIntel:null;
  return{url:pack?.url||releases+'/tag/v0.1.8',text:'Скачать для macOS',choose:!pack,note:pack?'Образ .dmg · '+pack.label:'Выберите Apple Silicon или Intel. Тип процессора указан в меню Apple → «Об этом Mac».'};
 }
 if(system.os==='linux'){
  if(system.architecture==='arm64')return{url:releases,text:'Сборки для Linux',choose:true,note:'Сейчас готов пакет для Ubuntu / Debian x64. Установщика для Linux ARM пока нет.'};
  return{...desktopPackages.linux,text:'Скачать для Linux',note:'Пакет .deb · Ubuntu / Debian x64'};
 }
 return{url:releases,text:'Скачать Vibra на компьютер',choose:true,note:system.os==='mobile'?'Приложение доступно для Windows, macOS и Linux. Выберите систему компьютера.':'Выберите систему компьютера.'};
}

let detected;
async function currentSystem() {
 if(!detected)detected=(async()=>{
  let timer;
  try{
   const hints=await Promise.race([navigator.userAgentData?.getHighEntropyValues?.(['architecture','bitness']),new Promise(resolve=>{timer=setTimeout(()=>resolve({}),800)})]);
   return detectDesktopSystem(navigator,hints||{});
  }catch{return detectDesktopSystem(navigator)}finally{clearTimeout(timer)}
 })();
 return detected;
}

export function mountDesktopDownload(container,{compact=false,before}={}) {
 if(!container||container.querySelector('[data-desktop-download]'))return;
 if(window.vibraCapture||/Electron\//.test(navigator.userAgent)||document.documentElement.classList.contains('vibra-desktop'))return;
 const section=document.createElement('section');section.className='desktop-download'+(compact?' desktop-download-compact':'');section.dataset.desktopDownload='';section.setAttribute('aria-label','Скачать приложение Vibra');
 section.innerHTML=`<a class="desktop-download-main" href="${releases}" target="_blank" rel="noopener noreferrer" referrerpolicy="no-referrer"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/></svg><span>Скачать Vibra на компьютер</span></a><p class="desktop-download-note"></p><details class="desktop-download-options"><summary>Другая система</summary><nav aria-label="Установщики Vibra">${Object.entries(desktopPackages).map(([key,pack])=>`<a data-package="${key}" href="${pack.url}" target="_blank" rel="noopener noreferrer" referrerpolicy="no-referrer">${pack.label}</a>`).join('')}</nav><p>Vibra 0.1.8 · Полные установщики приложения.</p></details>`;
 container.insertBefore(section,before?container.querySelector(before):null);
 currentSystem().then(system=>{
  if(!section.isConnected)return;
  const choice=desktopDownloadChoice(system),link=section.querySelector('.desktop-download-main'),details=section.querySelector('details');
  link.href=choice.url;link.querySelector('span').textContent=choice.text;
  section.querySelector('.desktop-download-note').textContent=choice.note;
  if(choice.choose)link.addEventListener('click',event=>{event.preventDefault();details.open=true;const target=system.os==='mac'?'[data-package="macArm"]':system.os==='linux'?'[data-package="linux"]':'a';details.querySelector(target)?.focus()});
 });
}
