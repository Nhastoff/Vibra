"""Compose installer chrome from the existing bird logo and design colors."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parents[1]
logo = Image.open(root/'public/logo.png').convert('RGBA')
font_dir = Path('C:/Windows/Fonts')
def font(size, bold=False):
    return ImageFont.truetype(str(font_dir/('segoeuib.ttf' if bold else 'segoeui.ttf')),size)
def bird(image, box):
    asset=logo.copy();asset.thumbnail((box[2],box[3]),Image.Resampling.LANCZOS)
    image.paste(asset,(box[0]+(box[2]-asset.width)//2,box[1]+(box[3]-asset.height)//2),asset)

scale=3
sidebar=Image.new('RGB',(164*scale,314*scale),'#11121b');draw=ImageDraw.Draw(sidebar)
for radius in [62,103,143]:
    cx,cy=59*scale,252*scale;r=radius*scale
    draw.ellipse((cx-r,cy-r,cx+r,cy+r),outline='#272236',width=scale)
draw.line((0,0,0,314*scale),fill='#ab8aff',width=3*scale)
bird(sidebar,(40*scale,44*scale,84*scale,84*scale))
draw.text((30*scale,141*scale),'vibra',font=font(34*scale,True),fill='#efeff9')
draw.text((20*scale,283*scale),'НА ОДНОЙ ВОЛНЕ',font=font(8*scale,True),fill='#bba0f0')
sidebar.resize((164,314),Image.Resampling.LANCZOS).save(root/'build/installer-sidebar.bmp')
header=Image.new('RGB',(150*scale,57*scale),'#171821');draw=ImageDraw.Draw(header)
bird(header,(28*scale,12*scale,35*scale,35*scale))
draw.text((69*scale,14*scale),'vibra',font=font(21*scale,True),fill='#efeff9')
header.resize((150,57),Image.Resampling.LANCZOS).save(root/'build/installer-header.bmp')

# Finder's DMG canvas belongs to the app; macOS permission alerts do not.
dmg=Image.new('RGB',(660*scale,430*scale),'#171821');draw=ImageDraw.Draw(dmg)
bird(dmg,(34*scale,28*scale,44*scale,44*scale))
draw.text((91*scale,29*scale),'vibra',font=font(28*scale,True),fill='#efeff9')
draw.text((35*scale,104*scale),'На одной волне.',font=font(30*scale,True),fill='#efeff9')
draw.text((35*scale,151*scale),'Перетащите Vibra в «Программы»',font=font(15*scale),fill='#989cb4')
draw.rounded_rectangle((106*scale,200*scale,552*scale,356*scale),radius=23*scale,fill='#20212d',outline='#343044',width=scale)
draw.line((299*scale,269*scale,361*scale,269*scale),fill='#b08bff',width=3*scale)
draw.line((349*scale,257*scale,361*scale,269*scale,349*scale,281*scale),fill='#b08bff',width=3*scale)
draw.text((35*scale,389*scale),'ТЕКСТ  ·  ГОЛОС  ·  ОБЩИЙ ЭКРАН',font=font(10*scale,True),fill='#717995')
dmg.resize((660,430),Image.Resampling.LANCZOS).save(root/'build/dmg-background.png')
print('Installer sidebar, header and DMG background created from existing Vibra artwork.')
