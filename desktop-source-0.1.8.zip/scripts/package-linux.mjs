// Standard Debian binary package writer. No installer, native executable, or
// platform utility is invoked; tar, gzip, and ar are written with Node builtins.
import { createReadStream, createWriteStream } from 'node:fs';
import { lstat, readdir, readFile, stat, mkdir, mkdtemp, rm, rename, open } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { tmpdir } from 'node:os';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { createGzip, createGunzip, gunzipSync } from 'node:zlib';
import { createHash, randomUUID } from 'node:crypto';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const zero = Buffer.alloc(512);
export const dependencies = [
  // app-builder-lib 26.15.3 FpmTarget defaults, plus shared libraries observed
  // in the official Electron executable's ELF DT_NEEDED table. No version guess.
  'libc6', 'libgcc-s1', 'libglib2.0-0 | libglib2.0-0t64', 'libnspr4', 'libnss3',
  'libatk1.0-0 | libatk1.0-0t64', 'libatk-bridge2.0-0 | libatk-bridge2.0-0t64',
  'libcups2 | libcups2t64', 'libdbus-1-3', 'libcairo2', 'libgtk-3-0 | libgtk-3-0t64',
  'libpango-1.0-0', 'libx11-6', 'libxcomposite1', 'libxdamage1', 'libxext6',
  'libxfixes3', 'libxrandr2', 'libgbm1', 'libexpat1', 'libxcb1', 'libxkbcommon0',
  'libudev1', 'libasound2 | libasound2t64', 'libatspi2.0-0 | libatspi2.0-0t64',
  'libnotify4', 'libxss1', 'libxtst6', 'xdg-utils', 'libuuid1', 'libsecret-1-0',
];

function safeName(name) {
  if (typeof name !== 'string' || name.includes('\\') || name.includes('\0') || name.startsWith('/') || name.split('/').some(p => p === '..' || p === '.')) throw Error(`Unsafe archive path: ${name}`);
  return name;
}
function octal(buffer, offset, length, value) {
  const text = value.toString(8);
  if (text.length > length - 1) throw Error('USTAR numeric field overflow');
  buffer.write(text.padStart(length - 1, '0') + '\0', offset, length, 'ascii');
}
export function tarHeader(name, { size = 0, mode = 0o644, directory = false } = {}) {
  safeName(name); if (directory && !name.endsWith('/')) name += '/';
  let leaf = name, prefix = '';
  if (Buffer.byteLength(name) > 100) {
    const parts = name.split('/');
    for (let i = parts.length - 1; i > 0; i--) {
      const candidate = parts.slice(i).join('/'), parent = parts.slice(0, i).join('/');
      if (Buffer.byteLength(candidate) <= 100 && Buffer.byteLength(parent) <= 155) { leaf = candidate; prefix = parent; break; }
    }
  }
  if (Buffer.byteLength(leaf) > 100) throw Error(`Path too long for USTAR: ${name}`);
  const header = Buffer.alloc(512);
  header.write(leaf, 0, 100, 'utf8');
  octal(header, 100, 8, mode); octal(header, 108, 8, 0); octal(header, 116, 8, 0);
  octal(header, 124, 12, directory ? 0 : size); octal(header, 136, 12, 0);
  header.fill(32, 148, 156); header[156] = directory ? 53 : 48;
  header.write('ustar\0', 257, 6, 'ascii'); header.write('00', 263, 2, 'ascii');
  header.write('root', 265, 32, 'ascii'); header.write('root', 297, 32, 'ascii');
  header.write(prefix, 345, 155, 'utf8');
  const checksum = header.reduce((sum, byte) => sum + byte, 0);
  header.write(checksum.toString(8).padStart(6, '0') + '\0 ', 148, 8, 'ascii');
  return header;
}
export function arHeader(name, size) {
  if (!/^[a-z0-9.-]{1,15}$/.test(name) || !Number.isSafeInteger(size) || size < 0) throw Error('Invalid ar member');
  const header = `${(name + '/').padEnd(16)}${'0'.padEnd(12)}${'0'.padEnd(6)}${'0'.padEnd(6)}${'100644'.padEnd(8)}${String(size).padEnd(10)}\x60\n`;
  if (Buffer.byteLength(header) !== 60) throw Error('ar header overflow');
  return Buffer.from(header, 'ascii');
}
async function* tarBytes(entries) {
  for (const entry of entries) {
    const size = entry.directory ? 0 : entry.data ? entry.data.length : (await stat(entry.source)).size;
    yield tarHeader(entry.name, { size, mode: entry.mode, directory: entry.directory });
    if (!entry.directory) {
      if (entry.data) yield entry.data;
      else for await (const chunk of createReadStream(entry.source)) yield chunk;
      const padding = (512 - size % 512) % 512; if (padding) yield zero.subarray(0, padding);
    }
  }
  yield zero; yield zero;
}
export async function writeTarGz(entries, destination) {
  await pipeline(Readable.from(tarBytes(entries)), createGzip({ level: 6 }), createWriteStream(destination, { flags: 'wx' }));
}
const allowedTop = new Set(['locales', 'resources', 'vibra', 'chrome_crashpad_handler', 'chrome-sandbox', 'chrome_100_percent.pak', 'chrome_200_percent.pak', 'icudtl.dat', 'libffmpeg.so', 'libvk_swiftshader.so', 'libvulkan.so.1', 'LICENSE.electron.txt', 'LICENSES.chromium.html', 'resources.pak', 'snapshot_blob.bin', 'v8_context_snapshot.bin', 'vk_swiftshader_icd.json']);
async function runtimeEntries(sourceDir) {
  const entries = [];
  async function walk(relative = '') {
    for (const name of (await readdir(path.join(sourceDir, relative))).sort()) {
      if (!relative && !allowedTop.has(name)) throw Error(`Unexpected runtime content: ${name}`);
      const next = relative ? relative + '/' + name : name, source = path.join(sourceDir, ...next.split('/'));
      safeName(next); const info = await lstat(source);
      if (info.isSymbolicLink() || (!info.isFile() && !info.isDirectory())) throw Error(`Unsupported runtime entry: ${next}`);
      if (next.startsWith('resources/') && !['resources/app.asar', 'resources/app.asar.unpacked', 'resources/apparmor-profile'].includes(next) && !next.startsWith('resources/app.asar.unpacked/')) throw Error(`Unexpected application resource: ${next}`);
      if (info.isDirectory()) { entries.push({ name: 'opt/Vibra/' + next, directory: true, mode: 0o755 }); await walk(next); }
      else entries.push({ name: 'opt/Vibra/' + next, source, mode: next === 'chrome-sandbox' ? 0o4755 : ['vibra', 'chrome_crashpad_handler'].includes(next) ? 0o755 : 0o644 });
    }
  }
  await walk(); return entries;
}
export async function buildDeb({ sourceDir, output, icon, version = '0.1.0' }) {
  if (!/^[0-9]+(?:\.[0-9]+)*(?:[-+~][a-zA-Z0-9.+~-]+)?$/.test(version)) throw Error('Invalid package version');
  const handle = await open(path.join(sourceDir, 'vibra'), 'r');
  try { const magic = Buffer.alloc(20); await handle.read(magic, 0, 20, 0); if (!magic.subarray(0, 4).equals(Buffer.from([0x7f, 69, 76, 70])) || magic[4] !== 2 || magic[5] !== 1 || magic.readUInt16LE(18) !== 62) throw Error('Source must contain the Linux x64 ELF Electron runtime'); } finally { await handle.close(); }
  const runtime = await runtimeEntries(sourceDir);
  if (!runtime.some(e => e.name === 'opt/Vibra/resources/app.asar')) throw Error('Packaged Vibra app.asar missing');
  const iconData = await readFile(icon); if (!iconData.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) throw Error('PNG application icon missing');
  const directories = ['opt', 'opt/Vibra', 'usr', 'usr/bin', 'usr/share', 'usr/share/applications', 'usr/share/icons', 'usr/share/icons/hicolor', 'usr/share/icons/hicolor/512x512', 'usr/share/icons/hicolor/512x512/apps'];
  const entries = [...directories.map(name => ({ name, directory: true, mode: 0o755 })), ...runtime,
    { name: 'usr/bin/vibra', mode: 0o755, data: Buffer.from('#!/bin/sh\nexec /opt/Vibra/vibra "$@"\n') },
    { name: 'usr/share/applications/vibra.desktop', mode: 0o644, data: Buffer.from('[Desktop Entry]\nType=Application\nName=Vibra\nComment=Text, voice and screen sharing\nExec=vibra\nIcon=vibra\nTerminal=false\nCategories=Network;InstantMessaging;\nStartupWMClass=Vibra\n') },
    { name: 'usr/share/icons/hicolor/512x512/apps/vibra.png', mode: 0o644, data: iconData },
  ];
  let bytes = 0; for (const entry of entries) if (!entry.directory) bytes += entry.data?.length ?? (await stat(entry.source)).size;
  const control = `Package: vibra\nVersion: ${version}\nArchitecture: amd64\nSection: net\nPriority: optional\nMaintainer: Vibra preview <maintainers@vibra.invalid>\nInstalled-Size: ${Math.ceil(bytes / 1024)}\nDepends: ${dependencies.join(', ')}\nDescription: Vibra desktop text and voice communities\n Text chat, voice rooms and video-only screen sharing.\n Preview package; maintainer address is an intentional non-routable placeholder.\n`;
  const work = await mkdtemp(path.join(tmpdir(), 'vibra-deb-')), partial = output + '.tmp-' + randomUUID();
  try {
    const controlPath = path.join(work, 'control.tar.gz'), dataPath = path.join(work, 'data.tar.gz');
    await writeTarGz([{ name: 'control', mode: 0o644, data: Buffer.from(control) }], controlPath);
    await writeTarGz(entries, dataPath);
    async function* arBytes() {
      yield Buffer.from('!<arch>\n');
      for (const member of [{ name: 'debian-binary', data: Buffer.from('2.0\n') }, { name: 'control.tar.gz', source: controlPath }, { name: 'data.tar.gz', source: dataPath }]) {
        const size = member.data?.length ?? (await stat(member.source)).size;
        yield arHeader(member.name, size); if (member.data) yield member.data; else for await (const chunk of createReadStream(member.source)) yield chunk;
        if (size % 2) yield Buffer.from('\n');
      }
    }
    await mkdir(path.dirname(output), { recursive: true });
    await pipeline(Readable.from(arBytes()), createWriteStream(partial, { flags: 'wx' }));
    await inspectDeb(partial); await rename(partial, output);
    const hash = createHash('sha256'); for await (const chunk of createReadStream(output)) hash.update(chunk);
    return { output, size: (await stat(output)).size, sha256: hash.digest('hex'), files: entries.length };
  } finally { await rm(work, { recursive: true, force: true }); await rm(partial, { force: true }); }
}

function text(buffer, start, end) { return buffer.toString('utf8', start, end).replace(/\0.*$/s, ''); }
export async function inspectDeb(filename) {
  const file = await open(filename, 'r'), total = (await file.stat()).size, members = [];
  async function read(position, length) { const buffer = Buffer.alloc(length); const result = await file.read(buffer, 0, length, position); if (result.bytesRead !== length) throw Error('Truncated Debian archive'); return buffer; }
  try {
    if ((await read(0, 8)).toString() !== '!<arch>\n') throw Error('Invalid Debian ar magic');
    let position = 8;
    while (position < total) {
      const header = await read(position, 60); if (header.toString('ascii', 58, 60) !== '\x60\n') throw Error('Invalid ar header');
      const name = header.toString('ascii', 0, 16).trim().replace(/\/$/, ''), size = Number(header.toString('ascii', 48, 58).trim());
      if (!Number.isSafeInteger(size) || size < 0 || position + 60 + size > total) throw Error('Invalid ar member size');
      members.push({ name, size, offset: position + 60 }); position += 60 + size;
      if (size % 2) { if ((await read(position, 1))[0] !== 10) throw Error('Invalid ar alignment'); position++; }
    }
    if (position !== total || members.map(m => m.name).join(',') !== 'debian-binary,control.tar.gz,data.tar.gz') throw Error('Invalid Debian members');
    if ((await read(members[0].offset, members[0].size)).toString() !== '2.0\n') throw Error('Invalid Debian binary version');
    if (members[1].size > 262144) throw Error('Oversized control archive');
    const controlTar = gunzipSync(await read(members[1].offset, members[1].size));
    if (text(controlTar, 0, 100) !== 'control') throw Error('Debian control entry missing');
    const controlSize = parseInt(text(controlTar, 124, 136), 8), control = controlTar.toString('utf8', 512, 512 + controlSize);
    const data = members[2], entries = []; let pending = Buffer.alloc(0), remaining = 0, padding = 0, current = null, ended = false;
    const stream = createReadStream(filename, { start: data.offset, end: data.offset + data.size - 1 }).pipe(createGunzip());
    for await (const chunk of stream) {
      pending = pending.length ? Buffer.concat([pending, chunk]) : chunk;
      while (pending.length) {
        if (remaining) { const take = Math.min(remaining, pending.length); if (current.magic.length < 8) current.magic += pending.subarray(0, Math.min(take, 4 - current.magic.length / 2)).toString('hex'); remaining -= take; pending = pending.subarray(take); continue; }
        if (padding) { const take = Math.min(padding, pending.length); padding -= take; pending = pending.subarray(take); continue; }
        if (pending.length < 512) break;
        const header = pending.subarray(0, 512); pending = pending.subarray(512);
        if (header.equals(zero)) { ended = true; continue; }
        if (ended) throw Error('Data after TAR end marker');
        const checksum = parseInt(text(header, 148, 156), 8), copy = Buffer.from(header); copy.fill(32, 148, 156);
        if (copy.reduce((sum, byte) => sum + byte, 0) !== checksum || text(header, 257, 263) !== 'ustar') throw Error('Invalid USTAR header');
        const name = [text(header, 345, 500), text(header, 0, 100)].filter(Boolean).join('/'); safeName(name);
        const size = parseInt(text(header, 124, 136), 8), mode = parseInt(text(header, 100, 108), 8), uid = parseInt(text(header, 108, 116), 8), gid = parseInt(text(header, 116, 124), 8);
        if (!Number.isSafeInteger(size) || size < 0 || uid !== 0 || gid !== 0 || ![48, 53].includes(header[156])) throw Error('Invalid packaged file metadata');
        current = { name, size, mode, uid, gid, magic: '' }; entries.push(current); remaining = size; padding = (512 - size % 512) % 512;
      }
    }
    if (!ended || pending.length || remaining || padding) throw Error('Truncated USTAR data');
    const executable = entries.find(e => e.name === 'opt/Vibra/vibra'), sandbox = entries.find(e => e.name === 'opt/Vibra/chrome-sandbox');
    if (!executable || executable.magic !== '7f454c46' || executable.mode !== 0o755 || sandbox?.mode !== 0o4755) throw Error('Invalid ELF executable or sandbox permissions');
    if (!/^Package: vibra$/m.test(control) || !/^Architecture: amd64$/m.test(control)) throw Error('Invalid package control');
    return { members, control, entries };
  } finally { await file.close(); }
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const metadata = JSON.parse(await readFile(path.join(projectRoot, 'package.json'), 'utf8'));
    const result = await buildDeb({ sourceDir: path.join(projectRoot, 'dist', 'linux-unpacked'), output: path.join(projectRoot, 'dist', `Vibra-${metadata.version}-linux-amd64.deb`), icon: path.join(projectRoot, 'build', 'icons', 'icon.png'), version: metadata.version });
    console.log(JSON.stringify(result, null, 2));
  } catch (error) { console.error(error.message); process.exitCode = 1; }
}
