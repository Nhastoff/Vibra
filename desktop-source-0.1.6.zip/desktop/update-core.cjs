'use strict';
const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');const zlib=require('node:zlib');
const MAX_BUNDLE=8*1024*1024,MAX_FILES=256,MAX_EXPANDED=32*1024*1024;
const digest=data=>crypto.createHash('sha256').update(data).digest('hex');
const version=v=>typeof v==='string'&&/^(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})$/.test(v);
function newer(a,b){if(!version(a)||!version(b))return false;const x=a.split('.').map(Number),y=b.split('.').map(Number);for(let i=0;i<3;i++){if(x[i]!==y[i])return x[i]>y[i]}return false}
function validFile(p){return typeof p==='string'&&p.length<180&&!p.includes('\\')&&!p.split('/').some(x=>!x||x==='.'||x==='..')&&(/^(?:desktop|public|build\/icons)\/[a-zA-Z0-9_./-]+$/.test(p)||['server.mjs','turn-auth.mjs','package.json'].includes(p))}
function verifyEnvelope(envelope,key){
 if(!envelope||typeof envelope.signed!=='string'||envelope.signed.length>6000||typeof envelope.signature!=='string'||envelope.signature.length!==88)throw Error('Некорректное описание обновления');
 const bytes=Buffer.from(envelope.signed,'base64');if(!crypto.verify(null,bytes,key,Buffer.from(envelope.signature,'base64')))throw Error('Подпись обновления не прошла проверку');
 const m=JSON.parse(bytes.toString('utf8'));if(!version(m.version)||m.format!==1||!Number.isSafeInteger(m.bootstrap)||m.bootstrap<1||m.bootstrap>100||typeof m.electron!=='string'||!/^\d+\.\d+\.\d+$/.test(m.electron)||!Number.isSafeInteger(m.bytes)||m.bytes<1||m.bytes>MAX_BUNDLE||!Number.isSafeInteger(m.expandedBytes)||m.expandedBytes<1||m.expandedBytes>MAX_EXPANDED||!Number.isSafeInteger(m.files)||m.files<1||m.files>MAX_FILES||typeof m.sha256!=='string'||! /^[a-f0-9]{64}$/.test(m.sha256)||!/^https:\/\/github\.com\/Nhastoff\/Vibra\/releases\/download\/v\d+\.\d+\.\d+\/Vibra-[\d.]+-app\.vbr$/.test(m.url))throw Error('Неподдерживаемое обновление');
 if(new URL(m.url).pathname!==`/Nhastoff/Vibra/releases/download/v${m.version}/Vibra-${m.version}-app.vbr`)throw Error('Адрес обновления не соответствует версии');return m;
}
function decodeBundle(bytes,m){
 if(bytes.length!==m.bytes||digest(bytes)!==m.sha256)throw Error('Файл обновления повреждён');
 const decoded=zlib.gunzipSync(bytes,{maxOutputLength:MAX_EXPANDED});if(decoded.length!==m.expandedBytes)throw Error('Размер обновления не совпадает');
 const bundle=JSON.parse(decoded.toString('utf8'));if(bundle.version!==m.version||!Array.isArray(bundle.files)||bundle.files.length!==m.files)throw Error('Неполный пакет обновления');
 const seen=new Set();let total=0;const files=bundle.files.map(f=>{if(!validFile(f.path)||seen.has(f.path)||typeof f.data!=='string'||f.data.length>14*1024*1024)throw Error('Недопустимый файл обновления');seen.add(f.path);const data=Buffer.from(f.data,'base64');total+=data.length;if(total>MAX_EXPANDED)throw Error('Слишком большой пакет');return{path:f.path,data}});
 for(const required of['desktop/main.cjs','public/index.html','package.json','server.mjs','turn-auth.mjs'])if(!seen.has(required))throw Error('В обновлении отсутствуют файлы приложения');
 const pkg=JSON.parse(files.find(f=>f.path==='package.json').data.toString('utf8'));if(pkg.version!==m.version||pkg.name!=='vibra'||pkg.type!=='module')throw Error('Версия приложения не совпадает');return files;
}
function safeDirectory(root,target){const rel=path.relative(root,target);if(!rel||rel.startsWith('..')||path.isAbsolute(rel))throw Error('Недопустимая папка обновления');}
function ordinary(p){return fs.existsSync(p)&&!fs.lstatSync(p).isSymbolicLink()}
class UpdateStore{
 constructor({userData,baseRoot,baseVersion,electron,publicKey}){Object.assign(this,{baseRoot,baseVersion,electron,publicKey});this.root=path.join(userData,'vibra-updates');this.pointer=path.join(this.root,'active.json');this.current={version:baseVersion,root:baseRoot};}
 load(){try{if(!ordinary(this.root)||!ordinary(this.pointer))return this.current;const p=JSON.parse(fs.readFileSync(this.pointer,'utf8'));if(!version(p.version)||!newer(p.version,this.baseVersion))return this.current;if(p.confirmed!==true&&p.attempts>=1){this.recovery=true;fs.renameSync(this.pointer,this.pointer+'.failed-'+Date.now());if(version(p.previous)&&newer(p.previous,this.baseVersion)){const previous=this.verifyInstalled(p.previous);if(previous.manifest.electron===this.electron){this.current={version:p.previous,root:previous.directory};this.writePointer({version:p.previous,confirmed:true})}}return this.current}const loaded=this.verifyInstalled(p.version);if(loaded.manifest.electron!==this.electron)return this.current;if(p.confirmed!==true)this.writePointer({...p,attempts:1});this.current={version:p.version,root:loaded.directory};}catch{this.recovery=true}return this.current}
 verifyInstalled(v){
  if(!version(v))throw Error('Некорректная версия');const directory=path.join(this.root,'releases',v);safeDirectory(this.root,directory);if(!ordinary(this.root)||!ordinary(path.join(this.root,'releases'))||!ordinary(directory))throw Error('Пакет обновления недоступен');
  const envelope=JSON.parse(fs.readFileSync(path.join(directory,'manifest.json'),'utf8')),manifest=verifyEnvelope(envelope,this.publicKey);if(manifest.version!==v)throw Error('Версия обновления не совпадает');
  const bundlePath=path.join(directory,'bundle.vbr');if(!ordinary(bundlePath)||fs.statSync(bundlePath).size>MAX_BUNDLE)throw Error('Пакет повреждён');const files=decodeBundle(fs.readFileSync(bundlePath),manifest);
  for(const f of files){let cursor=directory;for(const segment of f.path.split('/')){cursor=path.join(cursor,segment);if(!ordinary(cursor))throw Error('Файлы обновления изменены')}if(digest(fs.readFileSync(cursor))!==digest(f.data))throw Error('Файлы обновления изменены')}
  return{directory,manifest};
 }
 stage(envelope,bytes){
  const m=verifyEnvelope(envelope,this.publicKey);if(!newer(m.version,this.current.version)||m.electron!==this.electron||m.bootstrap!==1)throw Error('Обновление несовместимо с установленной версией');const files=decodeBundle(bytes,m);
  fs.mkdirSync(this.root,{recursive:true,mode:0o700});if(!ordinary(this.root))throw Error('Папка обновлений недоступна');const releases=path.join(this.root,'releases');fs.mkdirSync(releases,{recursive:true,mode:0o700});if(!ordinary(releases))throw Error('Папка обновлений недоступна');
  const destination=path.join(releases,m.version);safeDirectory(this.root,destination);
  if(fs.existsSync(destination)){try{const installed=this.verifyInstalled(m.version);if(installed.manifest.sha256!==m.sha256)throw Error();return installed}catch{const quarantine=path.join(releases,'.failed-'+m.version+'-'+Date.now());safeDirectory(this.root,quarantine);fs.renameSync(destination,quarantine)}}
  const stage=fs.mkdtempSync(path.join(releases,'.pending-'));
  try{for(const f of files){const target=path.join(stage,...f.path.split('/'));safeDirectory(stage,target);fs.mkdirSync(path.dirname(target),{recursive:true,mode:0o700});fs.writeFileSync(target,f.data,{flag:'wx',mode:0o600})}fs.writeFileSync(path.join(stage,'manifest.json'),JSON.stringify(envelope),{flag:'wx',mode:0o600});fs.writeFileSync(path.join(stage,'bundle.vbr'),bytes,{flag:'wx',mode:0o600});fs.renameSync(stage,destination);return this.verifyInstalled(m.version)}catch(e){safeDirectory(releases,stage);fs.rmSync(stage,{recursive:true,force:true});throw e}
 }
 writePointer(value){const temporary=path.join(this.root,'active-'+crypto.randomUUID()+'.json');fs.writeFileSync(temporary,JSON.stringify(value),{flag:'wx',mode:0o600});fs.renameSync(temporary,this.pointer)}
 activate(v){const installed=this.verifyInstalled(v);if(installed.manifest.electron!==this.electron||!newer(v,this.current.version))throw Error('Обновление несовместимо');this.writePointer({version:v,previous:this.current.version,confirmed:false,attempts:0})}
 markHealthy(){if(this.current.root===this.baseRoot)return;try{const p=JSON.parse(fs.readFileSync(this.pointer,'utf8'));if(p.version===this.current.version&&p.confirmed!==true)this.writePointer({...p,confirmed:true})}catch{}}
}
module.exports={UpdateStore,verifyEnvelope,decodeBundle,newer,version,validFile,digest,MAX_BUNDLE};
