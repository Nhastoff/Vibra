import test from 'node:test';
import assert from 'node:assert/strict';
import { SpeechGate } from '../public/speech-gate.js';

const frame = (value = 0.01) => new Float32Array(480).fill(value);
const rms = values => Math.sqrt(values.reduce((sum, x) => sum + x*x, 0)/values.length);

test('quiet speech opens by probability, retaining the onset through lookahead', () => {
  const gate = new SpeechGate();
  for (let i = 0; i < 20; i++) gate.process(frame(0), 0.01);
  gate.process(frame(0.001), 0.9);
  gate.process(frame(0.001), 0.9);
  const onset = gate.process(frame(0.001), 0.9);
  assert(rms(onset) > 0.00095, 'quiet onset is retained despite being below the room volume threshold');
});

test('a single speech-like click never opens a closed microphone', () => {
  const gate = new SpeechGate();
  gate.process(frame(0.5), 0.99);
  gate.process(frame(0), 0.01);
  const click = gate.process(frame(0), 0.01);
  assert(rms(click) < 0.0051);
});

test('low-probability breathing is attenuated, speech tails fade smoothly', () => {
  const gate = new SpeechGate();
  for (let i = 0; i < 30; i++) gate.process(frame(0.02), 0.05);
  assert(rms(gate.process(frame(0.02), 0.05)) < 0.00021);
  for (let i = 0; i < 10; i++) gate.process(frame(0.02), 0.9);
  assert(rms(gate.process(frame(0.02), 0.4)) > 0.019);
  const samples = [];
  for (let i = 0; i < 100; i++) samples.push(...gate.process(frame(0.02), 0.01));
  assert(samples[0] > 0.019);
  assert(samples.at(-1) < 0.00021);
  let jump = 0;
  for (let i = 1; i < samples.length; i++) jump = Math.max(jump, Math.abs(samples[i]-samples[i-1]));
  assert(jump < 0.00001, 'release must not introduce a hard discontinuity');
});
