import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import {webcrypto} from 'node:crypto';
const source=readFileSync(new URL('../public/voice.js',import.meta.url),'utf8').replace('export class VibraVoice','class VibraVoice').replace('export default VibraVoice;','globalThis.VibraVoice=VibraVoice;');
test('call cues follow successful membership transitions, deduplicate state, and respect guest preferences',async()=>{
 const events={addEventListener(){},removeEventListener(){}},played=[],context=vm.createContext({window:{...events},document:{...events},navigator:{},localStorage:{getItem:()=>null,setItem(){}},structuredClone,crypto:webcrypto,setInterval:()=>0,clearInterval(){},console});vm.runInContext(source,context);
 const voice=new context.VibraVoice({userId:'guest',request:async p=>p.endsWith('join')?{channelId:'room',participants:[{id:'guest'},{id:'owner'}]}:{}});
 voice.openCapture=async()=>true;voice.ensurePlayback=async()=>{};voice.playCue=kind=>played.push(kind);
 await voice.join('room');assert.deepEqual(played,['join']);
 const state=ids=>voice.handleEvent({type:'voice.state',channelId:'room',participants:ids.map(id=>({id}))});
 state(['guest','owner']);state(['guest','owner']);assert.deepEqual(played,['join']);
 state(['guest','owner','friend']);state(['guest','owner','friend']);state(['guest','owner']);assert.deepEqual(played,['join','join','leave']);
 state(['guest','owner']);voice.handleEvent({type:'voice.state',channelId:'another',participants:[]});assert.equal(played.length,3);
 await voice.leave();await voice.leave();assert.deepEqual(played,['join','join','leave','leave']);
 voice.openCapture=async()=>{throw new Error('Denied')};await voice.join('room');assert.equal(played.length,4,'Failed/cancelled connections must remain silent');
 voice.destroy();assert.equal(played.length,4,'Teardown does not play stale cues');
});
test('cue output has short envelopes and never enters capture or network',async()=>{
 const events={addEventListener(){},removeEventListener(){}},tones=[],sinks=[];
 class AudioContext{constructor(){this.state='running';this.currentTime=1;this.destination={output:true}}resume(){return Promise.resolve()}close(){this.state='closed';return Promise.resolve()}setSinkId(id){sinks.push(id);return Promise.resolve()}createOscillator(){const tone={frequency:{},connect(node){tone.target=node},disconnect(){},start(at){tone.startAt=at},stop(at){tone.stopAt=at;tones.push(tone)}};return tone}createGain(){return{gain:{setValueAtTime(){},linearRampToValueAtTime(){},exponentialRampToValueAtTime(){}},connect(destination){assert.equal(destination.output,true)},disconnect(){}}}}
 const ctx=vm.createContext({window:{...events,AudioContext},document:{...events},navigator:{},localStorage:{getItem:()=>null,setItem(){}},structuredClone,setInterval:()=>0,clearInterval(){},setTimeout,clearTimeout,console});vm.runInContext(source,ctx);let posts=0;
 const voice=new ctx.VibraVoice({userId:'guest',request:async()=>{posts++;return{}}});voice._state.connected=true;voice._state.settings.outputDeviceId='headphones';
 voice.playCue('join');voice.playCue('leave');assert.deepEqual(tones.map(t=>t.frequency.value),[587.33,783.99,783.99,523.25]);assert(tones.every(t=>t.stopAt-t.startAt<.2));assert(sinks.every(id=>id==='headphones'));assert.equal(posts,0);
 voice._state.settings.channelSounds=false;voice.playCue('join');voice._state.settings.channelSounds=true;voice._state.deafened=true;voice.playCue('leave');assert.equal(tones.length,4);
 voice._state.connected=false;voice.destroy();
});
