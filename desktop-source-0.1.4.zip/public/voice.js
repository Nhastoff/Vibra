/* Audio is relayed as transient mono PCM16/16 kHz via authenticated HTTP/SSE.
 * This intentionally uses no WebRTC dependency. Ten-person rooms and 100 ms
 * frames use a bounded capture queue and ordered batches over a slow POST.
 * Browser capture requires HTTPS or localhost. Output choice is browser-specific.
 */
const defaults = { mode: 'vad', threshold: 0.025, pttKey: 'Space', inputDeviceId: '', outputDeviceId: '', outputVolume: 1, noiseMode: 'standard', channelSounds: true };
const AudioContextClass = window.AudioContext || window.webkitAudioContext;
const isTyping = target => !!target?.closest?.('input,textarea,select,[contenteditable="true"]');
const PLAYOUT_DELAY = 0.6, MAX_QUEUED_FRAMES = 8;

export class VibraVoice {
  constructor({ request, api, userId, onChange = () => {}, onError = () => {} }) {
    this.request = request || api;
    this.userId = userId;
    this.onChange = onChange;
    this.onError = onError;
    let saved = {};
    try { saved = JSON.parse(localStorage.getItem('vibra.voice') || '{}'); } catch {}
    this._state = { status: 'disconnected', connected: false, channelId: null, participants: [], muted: false, deafened: false, micTesting: false, micLevel: 0, speakingIds: [], settings: { ...defaults, ...saved }, devices: { inputs: [], outputs: [], outputSupported: !!AudioContextClass?.prototype?.setSinkId }, peerSettings: {}, stats: { sentFrames: 0, droppedFrames: 0, receivedFrames: 0, playedFrames: 0, receivedSamples: 0, nonzeroSamples: 0, lastReceivedRms: 0, monitorFrames: 0, monitorNonzeroFrames: 0 } };
    this._state.settings.noiseMode=['off','standard','rnnoise'].includes(this._state.settings.noiseMode)?this._state.settings.noiseMode:'standard';
    Object.assign(this._state,{noiseStatus:'idle',noiseError:null,activeNoiseMode:null});
    this.noiseIntent=0;this.noiseQueue=Promise.resolve();
    this.peers = new Map();
    this.speaking = new Map();
    this.sources = new Set();
    this.frameQueue = [];
    this.maxBatchFrames = 1;
    this.vadUntil = 0;
    Object.assign(this._state.stats, { queuedFrames: 0, batchedFrames: 0, rebufferEvents: 0, queueOverflows:0, playbackOverflows:0, playoutDelayMs: PLAYOUT_DELAY * 1000 });
    this.generation = 0;
    this.joinIntent = 0;
    this.micTestIntent = 0;
    this.pttDown = false;
    this.keydown = event => {
      if (this._state.settings.mode !== 'ptt' || event.code !== this._state.settings.pttKey || isTyping(event.target) || event.repeat || !document.hasFocus()) return;
      event.preventDefault(); this.pttDown = true;
    };
    this.keyup = event => { if (event.code === this._state.settings.pttKey) { this.pttDown = false; if(this._state.settings.mode === 'ptt')this.clearPendingFrames(); } };
    this.blur = () => { this.pttDown = false; if(this._state.settings.mode === 'ptt')this.clearPendingFrames(); };
    this.visibility = () => { if (document.hidden) { this.pttDown = false; if(this._state.settings.mode === 'ptt')this.clearPendingFrames(); } };
    this.pagehide = () => this.connectionLost();
    this.deviceChange = () => { this.stopMicTest(); this.refreshDevices(); };
    window.addEventListener('keydown', this.keydown);
    window.addEventListener('keyup', this.keyup);
    window.addEventListener('blur', this.blur);
    window.addEventListener('pagehide', this.pagehide);
    document.addEventListener('visibilitychange', this.visibility);
    navigator.mediaDevices?.addEventListener('devicechange', this.deviceChange);
    this.meterTimer = setInterval(() => {
      const now = Date.now();
      for (const [id, time] of this.speaking) if (now - time > 300) this.speaking.delete(id);
      this._state.speakingIds = [...this.speaking.keys()];
      if (this._state.connected || this._state.micTesting) this.emit();
    }, 150);
  }
  get state() { return structuredClone(this._state); }
  emit() { this.onChange(this.state); }
  post(path, body) { return this.request(path, 'POST', body); }
  async refreshDevices() {
    if (!navigator.mediaDevices?.enumerateDevices) return;
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      this._state.devices.inputs = devices.filter(x => x.kind === 'audioinput').map((x, i) => ({ deviceId: x.deviceId, label: x.label || `Микрофон ${i + 1}` }));
      this._state.devices.outputs = devices.filter(x => x.kind === 'audiooutput').map((x, i) => ({ deviceId: x.deviceId, label: x.label || `Динамики ${i + 1}` }));
      this.emit();
    } catch (error) { this.onError(`Не удалось получить список аудиоустройств: ${error.message}`); }
  }
  micError(error) {
    const errors = { NotAllowedError: 'Доступ к микрофону запрещён. Разрешите его в настройках браузера.', NotFoundError: 'Микрофон не найден. Подключите устройство.', NotReadableError: 'Микрофон занят или отключён. Проверьте устройство.', OverconstrainedError: 'Выбранный микрофон недоступен. Выберите другое устройство.', SecurityError: 'Микрофон доступен только через HTTPS или localhost.' };
    return errors[error.name] || `Ошибка микрофона: ${error.message}`;
  }
  async openCapture(token) {
    if (!navigator.mediaDevices?.getUserMedia || !AudioContextClass) throw new Error('Для голосового общения нужен современный браузер и HTTPS или localhost.');
    const id = this._state.settings.inputDeviceId,noiseSuppression=this._state.settings.noiseMode==='standard';
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { deviceId: id ? { exact: id } : undefined, channelCount: 1, echoCancellation: true, noiseSuppression, autoGainControl: true } });
    if (token !== this.generation) { stream.getTracks().forEach(x => x.stop()); return false; }
    this.stream = stream;this.captureConstraintsMode=noiseSuppression?'standard':'off';
    for (const track of stream.getTracks()) track.onended = () => { if (this.stream === stream) { this.leave(); this.onError('Микрофон отключён. Проверьте подключение и войдите в канал снова.'); } };
    const context = this.captureContext = new AudioContextClass({sampleRate:48000,latencyHint:'interactive'});
    await context.audioWorklet.addModule('/audio-capture.js');
    if (token !== this.generation) return false;
    const source = this.captureSource = context.createMediaStreamSource(stream);
    const processor = this.processor = new AudioWorkletNode(context, 'vibra-capture');
    const silent = this.captureSilence = context.createGain(); silent.gain.value = 0;
    this.processedInput=context.createGain();this.noiseBypass=context.createGain();source.connect(this.noiseBypass);this.noiseBypass.connect(this.processedInput);this.processedInput.connect(processor);processor.connect(silent);silent.connect(context.destination);
    this.captureOutput=context.createMediaStreamDestination();this.processedInput.connect(this.captureOutput);
    processor.port.onmessage = event => this.captureFrame(event.data);
    await context.resume();
    await this.configureNoise();
    if(token!==this.generation)return false;
    await this.refreshDevices();
    return token === this.generation;
  }
  async join(channelId) {
    this.prepareCues();
    const intent = ++this.joinIntent;
    await this.leave(false, false);
    if (intent !== this.joinIntent) return;
    const token = ++this.generation;
    this._state.status = 'connecting'; this.emit();
    const clientId = this.clientId = crypto.randomUUID();
    try {
      if (!await this.openCapture(token)) return;
      await this.ensurePlayback();
      if (token !== this.generation) return;
      const result = await this.post('/api/voice/join', { channelId, clientId });
      if (token !== this.generation) { await this.post('/api/voice/leave', { clientId }).catch(() => {}); return; }
      this._state.channelId = result.channelId || channelId;
      this._state.participants = result.participants || [];
      this._state.connected = true; this._state.status = 'connected';
      this.playCue('join');
      this.maxBatchFrames = Number.isInteger(result.maxBatchFrames) ? Math.max(1,Math.min(4,result.maxBatchFrames)) : 1;
      this.sequence = 0; this.vadUntil = 0; this.emit();
      this.pingTimer = setInterval(() => {
        if (!this._state.connected) return;
        this.post('/api/voice/ping', { clientId: this.clientId }).catch(error => this.transportError(error));
      }, 5000);
    } catch (error) { if (token === this.generation) { await this.leave();this.closeCues(); this.onError(this.micError(error)); } }
  }
  async ensurePlayback() {
    if (!this.playbackContext || this.playbackContext.state === 'closed') {
      this.playbackContext = new AudioContextClass({ sampleRate: 48000, latencyHint: 'interactive' });
      this.playbackBus=null;
      if(this.playbackContext.createDynamicsCompressor){
        const bus=this.playbackBus=this.playbackContext.createDynamicsCompressor();
        bus.threshold.value=-10;bus.knee.value=8;bus.ratio.value=16;bus.attack.value=.002;bus.release.value=.12;bus.connect(this.playbackContext.destination);
      }
    }
    await this.playbackContext.resume();
    await this.applyOutput();
  }
  async applyOutput() {
    if (!this.playbackContext?.setSinkId) return;
    await this.playbackContext.setSinkId(this._state.settings.outputDeviceId || '');
  }
  prepareCues() {
    if (!AudioContextClass || this._state.settings.channelSounds === false || this.destroyed) return;
    try {
      clearTimeout(this.cueCloseTimer);
      if (!this.cueContext || this.cueContext.state === 'closed') this.cueContext = new AudioContextClass({sampleRate:48000,latencyHint:'interactive'});
      this.cueContext.resume().catch(()=>{});
      this.cueContext.setSinkId?.(this._state.settings.outputDeviceId || '').catch(()=>{});
    } catch { /* Notification audio must never prevent joining a call. */ }
  }
  playCue(kind) {
    if (this._state.settings.channelSounds === false || this._state.deafened || this.destroyed) return;
    this.prepareCues();
    const ctx=this.cueContext;
    if (!ctx || ctx.state!=='running') return;
    // Original Vibra chimes: ascending on arrival, descending on departure.
    // This separate output graph is never connected to the microphone or relay.
    const frequencies=kind==='join'?[587.33,783.99]:[783.99,523.25],start=ctx.currentTime+.01;
    const volume=Math.max(0,Math.min(2,Number(this._state.settings.outputVolume)||0));
    for(let i=0;i<frequencies.length;i++){
      const tone=ctx.createOscillator(),gain=ctx.createGain(),at=start+i*.105,end=at+.17;
      tone.type='sine';tone.frequency.value=frequencies[i];
      gain.gain.setValueAtTime(0,at);gain.gain.linearRampToValueAtTime(.12*volume,at+.012);gain.gain.exponentialRampToValueAtTime(.0001,end);
      tone.connect(gain);gain.connect(ctx.destination);tone.onended=()=>{tone.disconnect();gain.disconnect()};tone.start(at);tone.stop(end+.01);
    }
    if(!this._state.connected){clearTimeout(this.cueCloseTimer);this.cueCloseTimer=setTimeout(()=>{if(!this._state.connected&&this.cueContext===ctx){ctx.close().catch(()=>{});this.cueContext=null}},450)}
  }
  closeCues() { if(this.cueCloseTimer)clearTimeout(this.cueCloseTimer);this.cueContext?.close().catch(()=>{});this.cueContext=null; }
  captureFrame({ pcm, rms }) {
    this._state.micLevel = rms;
    if (this._state.micTesting && this.monitorGain) {
      this._state.stats.monitorFrames++;
      if (rms > 0.0001) this._state.stats.monitorNonzeroFrames++;
    }
    if (!this._state.connected) return;
    // Preserve the capture timeline even when VAD/mute suppresses a packet.
    // Otherwise a receiver cannot distinguish a word boundary from adjacent PCM.
    const sequence=this.sequence++;
    if (this._state.micTesting || this._state.muted || this._state.deafened) return;
    const me = this._state.participants.find(x => x.id === this.userId || x.userId === this.userId);
    if (me?.serverMuted) return;
    const settings = this._state.settings;
    if (settings.mode === 'ptt') { if (!this.pttDown || document.hidden) { this.clearPendingFrames(); return; } }
    else {
      if (rms >= settings.threshold) this.vadUntil = Date.now() + 250;
      if (Date.now() > this.vadUntil) return;
    }
    const data = new Uint8Array(pcm);
    let binary = ''; for (let i = 0; i < data.length; i++) binary += String.fromCharCode(data[i]);
    this.speaking.set(this.userId, Date.now());
    // Keep up to 800 ms of unsent capture, rather than discarding each callback
    // while awaiting a round trip. One request at a time preserves server order.
    if (this.frameQueue.length >= MAX_QUEUED_FRAMES) { this.frameQueue.shift(); this._state.stats.droppedFrames++;this._state.stats.queueOverflows++; }
    this.frameQueue.push({ pcm: btoa(binary), sequence });
    this._state.stats.queuedFrames = this.frameQueue.length;
    this.flushFrames();
  }
  clearPendingFrames() { this.frameQueue.length = 0; this._state.stats.queuedFrames = 0; this.vadUntil = 0; }
  flushFrames() {
    if (this.frameBusy || !this.frameQueue.length) return;
    const me = this._state.participants.find(x=>x.id===this.userId||x.userId===this.userId);
    if (!this._state.connected || this._state.muted || this._state.deafened || this._state.micTesting || me?.serverMuted || this._state.settings.mode==='ptt'&&(!this.pttDown||document.hidden)) { this.clearPendingFrames(); return; }
    const frames=this.frameQueue.splice(0,this.maxBatchFrames),token=this.generation,clientId=this.clientId;
    this._state.stats.queuedFrames=this.frameQueue.length;this.frameBusy=true;
    const body=frames.length===1?{clientId,...frames[0]}:{clientId,frames};
    this.post('/api/voice/frame',body)
      .then(() => { if (token === this.generation) { this._state.stats.sentFrames+=frames.length; if(frames.length>1)this._state.stats.batchedFrames+=frames.length; } })
      .catch(error => { if (token === this.generation) this.transportError(error); })
      .finally(() => { if (token === this.generation) { this.frameBusy=false;this.flushFrames(); } });
  }
  transportError(error) {
    if (!this._state.connected) return;
    this.connectionLost();
    this.onError(error.message || 'Голосовое соединение потеряно. Войдите в канал снова.');
  }
  handleEvent(event) {
    if (!event || !this._state.connected || event.channelId !== this._state.channelId) return;
    if (event.type === 'voice.state') {
      const previousIds=new Set(this._state.participants.map(x=>x.id||x.userId));
      this._state.participants = event.participants || [];
      if (this.userId && !this._state.participants.some(x => x.id === this.userId || x.userId === this.userId)) { this.leave(); this.onError('Вы отключены от голосового канала.'); return; }
      const ids = new Set(this._state.participants.map(x => x.id || x.userId));
      const arrived=[...ids].some(id=>id!==this.userId&&!previousIds.has(id));
      const departed=[...previousIds].some(id=>id!==this.userId&&!ids.has(id));
      if(arrived)this.playCue('join');else if(departed)this.playCue('leave');
      if(this._state.participants.find(x=>(x.id||x.userId)===this.userId)?.serverMuted)this.clearPendingFrames();
      for (const [id, peer] of this.peers) if (!ids.has(id)) { for(const source of peer.sources){try{source.stop();}catch{}source.disconnect();this.sources.delete(source);}peer.envelope.disconnect();peer.gain.disconnect();this.peers.delete(id);this.speaking.delete(id); }
      this.emit();
    }
    if (event.type === 'voice.frame' && event.userId !== this.userId) this.playFrame(event);
  }
  playFrame(event) {
    if (this._state.deafened || !this.playbackContext || this.playbackContext.state !== 'running') return;
    try {
      const binary = atob(event.pcm);
      if (binary.length !== 3200) return;
      const peer = this.getPeer(event.userId);
      const discontinuity=peer.lastSequence>=0&&event.sequence!==peer.lastSequence+1;
      // SSE preserves order. Missing capture indices mark silence or discarded audio.
      peer.lastSequence = event.sequence;
      // Use one continuous interpolation state and buffers at the output rate.
      // Independently resampling each 100 ms AudioBuffer creates edge transients.
      const buffer = this.playbackContext.createBuffer(1, 4800, 48000);
      const samples = buffer.getChannelData(0);
      let energy = 0, nonzero = 0,previous=discontinuity?0:(peer.lastSample||0);
      for (let i = 0; i < 1600; i++) {
        let value = binary.charCodeAt(i * 2) | binary.charCodeAt(i * 2 + 1) << 8;
        if (value >= 32768) value -= 65536;
        const sample=value/32768,delta=sample-previous;
        samples[i*3]=previous+delta/3;samples[i*3+1]=previous+delta*2/3;samples[i*3+2]=sample;
        previous=sample;energy+=sample*sample;if(value)nonzero++;
      }
      peer.lastSample=previous;
      const stats = this._state.stats;
      stats.receivedFrames++; stats.receivedSamples += 1600; stats.nonzeroSamples += nonzero; stats.lastReceivedRms = Math.sqrt(energy / 1600);
      const now = this.playbackContext.currentTime;
      // A batch may contain 400 ms of contiguous capture. Reserve enough lead
      // for 400 ms arrival jitter plus capture and scheduling time; cap runaway delayed playback.
      if (peer.next > now + 1.5) { stats.droppedFrames++;stats.playbackOverflows++; return; }
      const source = this.playbackContext.createBufferSource();
      source.buffer = buffer; source.connect(peer.envelope);
      const contiguous=peer.next>now+0.008&&!discontinuity;
      const start=contiguous?peer.next:Math.max(peer.next,now+PLAYOUT_DELAY);
      const envelope=peer.envelope.gain,fade=0.004;
      if(contiguous){
        // Cancel the previous tail's fade before it starts, preserving a
        // continuous waveform across adjacent packets.
        envelope.cancelScheduledValues(start-fade);envelope.setValueAtTime(1,start-fade);
      }else{
        if(peer.next&&peer.next<=now+.008)stats.rebufferEvents++;
        // Retain already queued speech and its tail; a new utterance must not
        // cancel the old tail or overlap audio still waiting in the buffer.
        envelope.cancelScheduledValues(start);
        if(peer.next&&Math.abs(start-peer.next)<.000001)envelope.linearRampToValueAtTime(0,start);
        else envelope.setValueAtTime(0,start);
        envelope.linearRampToValueAtTime(1,start+fade);
      }
      peer.next = start + buffer.duration;
      envelope.setValueAtTime(1,peer.next-fade);envelope.linearRampToValueAtTime(0,peer.next);
      this.sources.add(source);
      peer.sources.add(source);
      source.onended = () => { this.sources.delete(source);peer.sources.delete(source);source.disconnect(); };
      source.start(start); stats.playedFrames++;
      if (stats.lastReceivedRms > 0.005) this.speaking.set(event.userId, Date.now());
    } catch (error) { console.warn('Invalid voice frame', error.message); }
  }
  getPeer(id) {
    if (!this.peers.has(id)) {
      const gain = this.playbackContext.createGain(); gain.connect(this.playbackBus||this.playbackContext.destination);
      const envelope=this.playbackContext.createGain();envelope.gain.value=0;envelope.connect(gain);
      this.peers.set(id, { gain, envelope, sources:new Set(), next: 0, lastSequence: -1 }); this.applyPeer(id);
    }
    return this.peers.get(id);
  }
  applyPeer(id) {
    const peer = this.peers.get(id), settings = this._state.peerSettings[id] || {};
    if (peer) peer.gain.gain.setValueAtTime(this._state.deafened || settings.muted ? 0 : (settings.volume ?? 1) * this._state.settings.outputVolume, this.playbackContext.currentTime);
  }
  setPeerMuted(id, muted) { this._state.peerSettings[id] = { ...this._state.peerSettings[id], muted: !!muted }; this.applyPeer(id); this.emit(); }
  setPeerVolume(id, volume) { this._state.peerSettings[id] = { ...this._state.peerSettings[id], volume: Math.max(0, Math.min(2, Number(volume) || 0)) }; this.applyPeer(id); this.emit(); }
  setLocalMute(id, muted) { this.setPeerMuted(id, muted); }
  setVolume(id, volume) { this.setPeerVolume(id, volume); }
  setMuted(muted) { if (!muted && this._state.deafened) this.setDeafened(false); this._state.muted = !!muted; this.pttDown = false; if(muted)this.clearPendingFrames();this.emit(); }
  toggleMute() { this.setMuted(!this._state.muted); }
  setDeafened(deafened) {
    if (this._state.deafened === !!deafened) return;
    this._state.deafened = !!deafened;
    if (deafened) { this.mutedBeforeDeafen = this._state.muted; this._state.muted = true; this.pttDown = false; this.clearPendingFrames();this.clearPlayback(); }
    else if (this.mutedBeforeDeafen !== undefined) { this._state.muted = this.mutedBeforeDeafen; this.mutedBeforeDeafen = undefined; }
    for (const id of this.peers.keys()) this.applyPeer(id);
    this.emit();
  }
  toggleDeafen() { this.setDeafened(!this._state.deafened); }
  serverMute(userId, muted) { return this.post('/api/voice/moderate', { userId, action: muted ? 'mute' : 'unmute' }); }
  disconnect(userId) { return this.post('/api/voice/moderate', { userId, action: 'disconnect' }); }
  async updateSettings(partial) {
    const oldInput = this._state.settings.inputDeviceId,oldNoise=this._state.settings.noiseMode;
    this._state.settings = { ...this._state.settings, ...partial };
    if(this._state.settings.channelSounds===false)this.closeCues();
    this._state.settings.noiseMode=['off','standard','rnnoise'].includes(this._state.settings.noiseMode)?this._state.settings.noiseMode:'standard';
    this._state.settings.mode = this._state.settings.mode === 'ptt' ? 'ptt' : 'vad';
    this._state.settings.threshold = Math.max(0.005, Math.min(0.2, Number(this._state.settings.threshold) || 0.025));
    this._state.settings.outputVolume = Math.max(0, Math.min(2, Number(this._state.settings.outputVolume) || 0));
    for (const id of this.peers.keys()) this.applyPeer(id);
    if (this.monitorGain) this.monitorGain.gain.setValueAtTime(this._state.settings.outputVolume, this.playbackContext.currentTime);
    this.pttDown = false;
    this.clearPendingFrames();
    try { localStorage.setItem('vibra.voice', JSON.stringify(this._state.settings)); } catch {}
    try { await this.applyOutput(); } catch { await this.stopMicTest(); this.onError('Не удалось выбрать устройство вывода. Проверьте разрешения браузера.'); }
    if (oldInput !== this._state.settings.inputDeviceId && (this._state.connected || this._state.micTesting)) {
      const channel = this._state.channelId;
      await this.stopMicTest();
      if (channel) await this.join(channel);
    }
    if(oldNoise!==this._state.settings.noiseMode&&oldInput===this._state.settings.inputDeviceId)await this.configureNoise();
    this.emit();
  }
  async createNoiseFilter(context,onFailure){const module=await import('./noise-filter.js');return module.createNoiseFilter(context,onFailure)}
  configureNoise(){
    const intent=++this.noiseIntent,mode=this._state.settings.noiseMode,context=this.captureContext,stream=this.stream;
    if(!context||!this.processedInput){this._state.noiseError=null;return Promise.resolve()}
    this.noiseQueue=this.noiseQueue.catch(()=>{}).then(async()=>{
      const current=()=>intent===this.noiseIntent&&context===this.captureContext&&stream===this.stream;
      if(!current())return;
      const previous=this._state.activeNoiseMode||'standard';let candidate;
      this._state.noiseStatus='loading';this._state.noiseError=null;this.clearPendingFrames();this.emit();
      try{
        if(mode==='rnnoise')candidate=await this.createNoiseFilter(context,()=>{if(this.noiseBranch===candidate&&context===this.captureContext)this.updateSettings({noiseMode:'standard'}).then(()=>{this._state.noiseError='RNNoise остановился. Включено стандартное шумоподавление.';this.emit();this.onError(this._state.noiseError)}).catch(()=>{})});
        if(!current()){candidate?.dispose();return}
        const constraintMode=mode==='standard'?'standard':'off';if(this.captureConstraintsMode!==constraintMode){await stream.getAudioTracks()[0].applyConstraints({noiseSuppression:mode==='standard',echoCancellation:true,autoGainControl:true});if(context===this.captureContext&&stream===this.stream)this.captureConstraintsMode=constraintMode;}
        if(!current()){candidate?.dispose();return}
        const old=this.noiseBranch,now=context.currentTime,fade=gain=>{gain.cancelScheduledValues(now);gain.setValueAtTime(gain.value,now);return gain};
        if(candidate){const gain=context.createGain();gain.gain.value=0;this.captureSource.connect(candidate.node);candidate.node.connect(gain);gain.connect(this.processedInput);const destroy=candidate.dispose,source=this.captureSource;candidate.dispose=()=>{try{source.disconnect(candidate.node)}catch{}gain.disconnect();destroy()};candidate.gain=gain;fade(gain.gain).linearRampToValueAtTime(1,now+.03)}
        fade(this.noiseBypass.gain).linearRampToValueAtTime(mode==='rnnoise'?0:1,now+.03);
        this.noiseBranch=candidate||null;
        if(old){fade(old.gain.gain).linearRampToValueAtTime(0,now+.03);setTimeout(()=>old.dispose(),50)}
        this._state.activeNoiseMode=mode;this._state.noiseStatus='ready';this.clearPendingFrames();this.emit();
      }catch(error){console.warn('Noise suppression initialization failed',error);candidate?.dispose();if(!current())return;this._state.settings.noiseMode=previous;try{if(this.captureConstraintsMode!==(previous==='standard'?'standard':'off')){await stream.getAudioTracks()[0].applyConstraints({noiseSuppression:previous==='standard',echoCancellation:true,autoGainControl:true});this.captureConstraintsMode=previous==='standard'?'standard':'off'}}catch{}this._state.activeNoiseMode=previous;this._state.noiseStatus='ready';this._state.noiseError='Не удалось включить '+(mode==='rnnoise'?'RNNoise':'режим')+'. Оставлен предыдущий режим.';try{localStorage.setItem('vibra.voice',JSON.stringify(this._state.settings))}catch{}this.emit();this.onError(this._state.noiseError)}
    });return this.noiseQueue;
  }
  async startMicTest() {
    if (this._state.status === 'connecting') { this.onError('Дождитесь подключения к голосовому каналу и повторите проверку.'); return; }
    if (this._state.micTesting) return;
    const intent = ++this.micTestIntent;
    const token = this._state.connected ? this.generation : ++this.generation;
    this.pttDown = false;
    this._state.micTesting = true; this.clearPendingFrames();this.emit();
    try {
      if (!this.stream && !await this.openCapture(token)) return;
      if (intent !== this.micTestIntent || token !== this.generation || !this._state.micTesting) return;
      await this.ensurePlayback();
      if (intent !== this.micTestIntent || token !== this.generation || !this._state.micTesting) return;
      // Direct local monitoring, without recording, a network round trip, or
      // changing room mute/deafen. The capture worklet continues the level meter
      // but captureFrame suppresses all room transmission while the test runs.
      this.monitorSource = this.playbackContext.createMediaStreamSource(this.captureOutput?.stream||this.stream);
      this.monitorGain = this.playbackContext.createGain();
      this.monitorGain.gain.setValueAtTime(this._state.settings.outputVolume, this.playbackContext.currentTime);
      this.monitorSource.connect(this.monitorGain); this.monitorGain.connect(this.playbackContext.destination);
      this.emit();
    } catch (error) {
      if (intent === this.micTestIntent) { await this.stopMicTest(); this.onError(this.micError(error)); }
    }
  }
  closeMonitor() {
    this.monitorSource?.disconnect(); this.monitorGain?.disconnect();
    this.monitorSource = this.monitorGain = null;
  }
  async stopMicTest() {
    if (!this._state.micTesting) return;
    ++this.micTestIntent; this._state.micTesting = false; this.pttDown = false;
    this.closeMonitor();
    if (!this._state.connected) {
      ++this.generation; this.closeCapture();
      this.playbackContext?.close().catch(() => {}); this.playbackContext = null;
    }
    this.emit();
  }
  closeCapture() {
    this.closeMonitor();
    ++this.noiseIntent;this.noiseQueue=Promise.resolve();this.noiseBranch?.dispose();this.noiseBranch=null;
    this.noiseBypass?.disconnect();this.processedInput?.disconnect();this.captureOutput?.disconnect();this.captureOutput?.stream.getTracks().forEach(track=>track.stop());
    this.noiseBypass=this.processedInput=this.captureOutput=null;this._state.noiseStatus='idle';this._state.activeNoiseMode=null;
    this.pttDown = false;
    if (this.processor) { this.processor.port.onmessage = null; this.processor.disconnect(); }
    this.captureSource?.disconnect(); this.captureSilence?.disconnect();
    const stream = this.stream; this.stream = null;
    stream?.getTracks().forEach(track => { track.onended = null; track.stop(); });
    this.captureContext?.close().catch(() => {});
    this.captureContext = this.processor = this.captureSource = this.captureSilence = null;
    this._state.micLevel = 0;
  }
  clearPlayback() { for (const source of this.sources) { try { source.stop(); } catch {} source.disconnect(); } this.sources.clear();for(const peer of this.peers.values()){peer.next=0;peer.sources.clear();peer.envelope.gain.cancelScheduledValues(this.playbackContext.currentTime);peer.envelope.gain.setValueAtTime(0,this.playbackContext.currentTime);} }
  async leave(cancelPendingJoin = true, notify = true) {
    if (cancelPendingJoin) ++this.joinIntent;
    ++this.micTestIntent;
    ++this.generation; clearInterval(this.pingTimer); this.pingTimer = null;
    const clientId = this.clientId; this.clientId = null;
    const actuallyConnected=this._state.connected;
    const wasConnected = this._state.connected || this._state.status === 'connecting';
    this._state.connected = false; this._state.status = 'disconnected'; this._state.channelId = null; this._state.participants = []; this._state.micTesting = false;
    if(actuallyConnected&&notify)this.playCue('leave');
    this.frameBusy = false;this.clearPendingFrames(); this.closeCapture(); this.clearPlayback();
    for (const peer of this.peers.values()) {peer.envelope.disconnect();peer.gain.disconnect();}this.peers.clear();
    this.playbackContext?.close().catch(() => {}); this.playbackContext = null;
    this.speaking.clear(); this._state.speakingIds = []; this.emit();
    if (clientId && wasConnected) await this.post('/api/voice/leave', { clientId }).catch(() => {});
  }
  connectionLost() { this.leave(); }
  destroy() {
    this.destroyed=true;this.leave(true,false); clearInterval(this.meterTimer);
    this.closeCues();
    window.removeEventListener('keydown', this.keydown); window.removeEventListener('keyup', this.keyup); window.removeEventListener('blur', this.blur);
    window.removeEventListener('pagehide', this.pagehide);
    document.removeEventListener('visibilitychange', this.visibility); navigator.mediaDevices?.removeEventListener('devicechange', this.deviceChange);
  }
}
export default VibraVoice;
