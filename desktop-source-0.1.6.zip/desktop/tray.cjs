'use strict';

// Keep the existing window and media graph alive. Linux panels do not expose a
// reliable tray-host presence check, so keep a taskbar restore path there.
function createTrayController({app,Tray,Menu,nativeImage,icon,platform=process.platform,getWindow,onHide=()=>{}}){
 let tray=null,quitting=false;
 function restore(){const win=getWindow();if(!win||win.isDestroyed())return false;if(win.isMinimized())win.restore();win.show();win.focus();return true}
 function destroy(){if(tray&&!tray.isDestroyed())tray.destroy();tray=null}
 function start(){
  if(tray&&!tray.isDestroyed())return;
  try{
   const image=nativeImage.createFromPath(icon).resize({width:platform==='darwin'?18:24,height:platform==='darwin'?18:24});
   if(image.isEmpty())return;
   tray=new Tray(image);tray.setToolTip('Vibra');
   tray.setContextMenu(Menu.buildFromTemplate([{label:'Открыть Vibra',click:restore},{type:'separator'},{label:'Выйти из Vibra',click:()=>app.quit()}]));
   tray.on('click',restore);tray.on('double-click',restore);
  }catch(error){destroy();console.warn('Vibra: tray unavailable; closing minimizes the window.',error.message)}
 }
 function attach(win){win.on('close',event=>{
  if(quitting)return;
  event.preventDefault();onHide();
  // A macOS Dock item can also restore a hidden window after a menu-bar change.
  const dock=platform==='darwin'&&app.dock?.isVisible();
  const safeTray=platform!=='linux'&&tray&&!tray.isDestroyed();
  if(safeTray||dock)win.hide();else win.minimize();
 })}
 app.on('before-quit',()=>{quitting=true;destroy()});
 app.on('will-quit',destroy);
 return{start,attach,restore,destroy};
}
module.exports={createTrayController};
