import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {mkdtempSync,rmSync,mkdirSync} from 'node:fs';
import {homedir,tmpdir} from 'node:os';
import path from 'node:path';

test('chat invitation links open acceptance without navigation, retain ACLs and safely escape message markup',{timeout:40000},async t=>{
 const directory=mkdtempSync(path.join(tmpdir(),'vibra-links-')),previous=process.env.DATA_DIR;process.env.DATA_DIR=directory;
 const {server,db}=await import('../server.mjs?links='+Date.now());await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;let browser;
 t.after(async()=>{await browser?.close();server.closeAllConnections();await new Promise(r=>server.close(r));db.close();assert(directory.startsWith(path.resolve(tmpdir())+path.sep));rmSync(directory,{recursive:true,force:true});if(previous===undefined)delete process.env.DATA_DIR;else process.env.DATA_DIR=previous});
 const {chromium}=createRequire(import.meta.url)(path.join(homedir(),'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'));
 browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
 const owner=await browser.newContext(),peer=await browser.newContext({viewport:{width:1250,height:850}});
 async function api(c,p,body,method=body===undefined?'GET':'POST'){const r=await c.request.fetch(base+p,{method,headers:{'x-csrf':c.csrf||''},data:body});assert.equal(r.status(),200,p+': '+await r.text());const d=await r.json();if(d.csrf)c.csrf=d.csrf;return d;}
 for(const [c,name]of[[owner,'linksowner'],[peer,'linkspeer']])await api(c,'/api/auth/register',{username:name,password:'test-only-links-password'});
 const shared=(await api(owner,'/api/servers',{name:'Общий чат'})).id,destination=(await api(owner,'/api/servers',{name:'Сервер друзей'})).id;
 const sharedInvite=await api(owner,'/api/servers/'+shared+'/invites',{});await api(peer,'/api/invites/'+sharedInvite.token+'/join',{});
 const cid=(await api(owner,'/api/servers/'+shared)).channels.find(c=>c.type==='text').id,invite=await api(owner,'/api/servers/'+destination+'/invites',{}),link=base+'/i/'+invite.token;
 await api(owner,'/api/messages',{channelId:cid,content:'Заходи: '+link+'\n('+link+').\n<img src=x onerror="window.injected=true"> javascript:alert(1)\nhttps://example.com/path?a=1&b=2 https://example.com/wiki/Thing_(test).',nonce:'links-safe'});
 const page=await peer.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(base);await page.locator('.shell').waitFor();await page.locator('.rail [data-action=server][data-id="'+shared+'"]').click();
 const links=page.locator('.message-text a[data-message-invite]');await links.first().waitFor();assert.equal(await links.count(),2);assert.equal(await links.nth(1).getAttribute('href'),link);assert.equal(await page.locator('.message-text img').count(),0);assert.equal(await page.evaluate(()=>window.injected),undefined);
 assert.equal(await page.locator('.message-text a[href^="javascript:"]').count(),0);assert.equal(await page.locator('.message-text a[href^="https://example.com/path"]').getAttribute('href'),'https://example.com/path?a=1&b=2');assert.equal(await page.locator('.message-text a[href*="wiki"]').getAttribute('href'),'https://example.com/wiki/Thing_(test)');
 assert(!(await api(peer,'/api/bootstrap')).servers.some(s=>s.id===destination));
 const before=page.url();await links.first().focus();await page.keyboard.press('Enter');await page.locator('#join-invite').waitFor();assert.equal(page.url(),before);assert.match(await page.locator('#dialog').innerText(),/Сервер друзей/);assert(!(await api(peer,'/api/bootstrap')).servers.some(s=>s.id===destination));
 mkdirSync('test-output',{recursive:true});await page.screenshot({path:'test-output/message-invite-open.png'});
 await page.locator('#join-invite').click();await page.waitForFunction(id=>document.querySelector('.sidebar-header')?.textContent.includes('Сервер друзей'),destination);assert((await api(peer,'/api/bootstrap')).servers.some(s=>s.id===destination));
 await page.locator('.rail [data-action=server][data-id="'+shared+'"]').click();await page.reload();await page.locator('.shell').waitFor();await page.locator('.rail [data-action=server][data-id="'+shared+'"]').click();await page.locator('.message-text a[data-message-invite]').first().waitFor();await api(owner,'/api/invites/'+invite.token,{},'DELETE');await page.locator('.message-text a[data-message-invite]').first().click();await page.locator('#toast.visible').waitFor();assert.equal(await page.locator('#join-invite').count(),0);assert.deepEqual(errors,[]);
});
