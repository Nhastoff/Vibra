import test from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {createRequire} from 'node:module';
import {mkdtempSync,rmSync} from 'node:fs';
import {homedir,tmpdir} from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const require=createRequire(import.meta.url),{createTrayController}=require('../desktop/tray.cjs');
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');

function fixture(platform,{failedTray=false,dock=false}={}){
 const app=new EventEmitter();let quits=0,hidden=0,minimized=0,shown=0,focused=0,cancelled=0,created=null;
 app.dock={isVisible:()=>dock};app.quit=()=>{quits++;app.emit('before-quit')};
 class Tray extends EventEmitter{constructor(){super();if(failedTray)throw Error('test: no tray host');created=this}setToolTip(){}setContextMenu(menu){this.menu=menu}isDestroyed(){return this.dead===true}destroy(){this.dead=true}}
 const image={resize(){return this},isEmpty:()=>false};
 const win=new EventEmitter();Object.assign(win,{isDestroyed:()=>false,isMinimized:()=>minimized>0,hide:()=>hidden++,minimize:()=>minimized++,restore:()=>minimized=0,show:()=>shown++,focus:()=>focused++});
 const controller=createTrayController({app,Tray,Menu:{buildFromTemplate:items=>items},nativeImage:{createFromPath:()=>image},icon:'test.png',platform,getWindow:()=>win,onHide:()=>cancelled++});
 controller.start();controller.attach(win);
 return{app,win,controller,get tray(){return created},close(){let prevented=false;win.emit('close',{preventDefault:()=>prevented=true});return prevented},state:()=>({quits,hidden,minimized,shown,focused,cancelled})};
}

test('tray close preserves window, click/menu restores, explicit quit bypasses close interception',()=>{
 const f=fixture('win32');assert.equal(f.close(),true);assert.deepEqual(f.state(),{quits:0,hidden:1,minimized:0,shown:0,focused:0,cancelled:1});
 f.tray.emit('click');assert.equal(f.state().shown,1);assert.equal(f.state().focused,1);
 assert.deepEqual(f.tray.menu.filter(i=>i.label).map(i=>i.label),['Открыть Vibra','Выйти из Vibra']);
 f.tray.menu[0].click();assert.equal(f.state().shown,2);
 f.tray.menu[2].click();assert.equal(f.state().quits,1);assert.equal(f.tray.isDestroyed(),true);assert.equal(f.close(),false);
});

test('Linux and unavailable tray minimize with a taskbar restore path; macOS Dock restores hidden windows',()=>{
 const linux=fixture('linux');assert.equal(linux.close(),true);assert.equal(linux.state().hidden,0);assert.equal(linux.state().minimized,1);linux.tray.menu[0].click();assert.equal(linux.state().minimized,0);
 const win=fixture('win32',{failedTray:true});assert.equal(win.close(),true);assert.equal(win.state().minimized,1);assert.equal(win.state().hidden,0);
 const mac=fixture('darwin',{failedTray:true,dock:true});assert.equal(mac.close(),true);assert.equal(mac.state().hidden,1);mac.controller.restore();assert.equal(mac.state().shown,1);
 const noDock=fixture('darwin',{failedTray:true});assert.equal(noDock.close(),true);assert.equal(noDock.state().minimized,1);
});

test('native desktop close keeps renderer and synthetic audio alive, activate restores, app.quit exits',{timeout:45000},async t=>{
 const modules=process.env.VIBRA_NODE_MODULES||path.join(homedir(),'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules');
 const {_electron:electron}=require(path.join(modules,'playwright'));
 const packaged=!!process.env.VIBRA_DESKTOP_EXECUTABLE;
 const executablePath=process.env.VIBRA_DESKTOP_EXECUTABLE||path.join(root,'node_modules/electron/dist',process.platform==='win32'?'electron.exe':process.platform==='darwin'?'Electron.app/Contents/MacOS/Electron':'electron');
 const userData=mkdtempSync(path.join(tmpdir(),'vibra-tray-'));let app;
 t.after(async()=>{await app?.close().catch(()=>{});rmSync(userData,{recursive:true,force:true})});
 const env={...process.env,VIBRA_DESKTOP_TEST:'1',VIBRA_DESKTOP_TEST_LOCAL:'1',VIBRA_USER_DATA:userData};delete env.ELECTRON_RUN_AS_NODE;
 app=await electron.launch({executablePath,args:[...(packaged?[]:[root]),'--autoplay-policy=no-user-gesture-required'],env,timeout:30000});
 const page=await app.firstWindow();await page.locator('#auth-form').waitFor();
 const native=await app.browserWindow(page),identity=await native.evaluate(win=>({id:win.id,wc:win.webContents.id,throttling:win.webContents.getBackgroundThrottling()}));assert.equal(identity.throttling,false);
 await page.evaluate(async()=>{const ctx=window.__trayAudio=new AudioContext(),oscillator=ctx.createOscillator(),gain=ctx.createGain();gain.gain.value=0;oscillator.connect(gain).connect(ctx.destination);oscillator.start();await ctx.resume();window.__trayTicks=0;setInterval(()=>window.__trayTicks++,20)});
 const before=await page.evaluate(()=>({time:__trayAudio.currentTime,ticks:__trayTicks}));
 await native.evaluate(win=>win.close());
 assert.deepEqual(await app.evaluate(({BrowserWindow},id)=>{const win=BrowserWindow.fromId(id);return{alive:!!win,visible:win?.isVisible(),minimized:win?.isMinimized(),wc:win?.webContents.id}},identity.id),{alive:true,visible:process.platform==='linux',minimized:process.platform==='linux',wc:identity.wc});
 await new Promise(resolve=>setTimeout(resolve,650));
 const after=await page.evaluate(()=>({state:__trayAudio.state,time:__trayAudio.currentTime,ticks:__trayTicks}));assert.equal(after.state,'running');assert(after.time-before.time>.4,'Audio clock must continue while closed to tray');assert(after.ticks-before.ticks>12,'Capture/signalling timers must not be background throttled');
 await app.evaluate(({app})=>app.emit('activate'));
 assert.deepEqual(await native.evaluate(win=>({visible:win.isVisible(),minimized:win.isMinimized(),wc:win.webContents.id})),{visible:true,minimized:false,wc:identity.wc});
 await page.evaluate(()=>__trayAudio.close());
 await app.close();app=null;
});
