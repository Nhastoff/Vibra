// One SSE connection and one outstanding acknowledgement per page. Explicit
// retries also recover CLOSED EventSources and half-open VPN/TCP connections.
export class ReconnectingEvents {
  constructor({request,userId,onSession=()=>{},onOpen=()=>{},onDisconnect=()=>{},onMessage=()=>{},onFatal=()=>{}}) {
    Object.assign(this,{request,userId,onSession,onOpen,onDisconnect,onMessage,onFatal});
    this.closed=false;this.connected=false;this.attempt=0;this.lastSeen=Date.now();
    this.online=()=>this.reconnect();
    this.offline=()=>this.failed();
    this.wake=()=>{if(!this.source||Date.now()-this.lastSeen>7000)this.reconnect()};
    this.visible=()=>{if(!document.hidden)this.wake()};
    window.addEventListener('online',this.online);
    window.addEventListener('offline',this.offline);
    window.addEventListener('focus',this.wake);
    document.addEventListener('visibilitychange',this.visible);
    this.watchdog=setInterval(()=>{if(this.source&&Date.now()-this.lastSeen>18000)this.failed()},3000);
    this.connect();
  }
  connect() {
    if(this.closed||this.source)return;
    if(navigator.onLine===false){this.schedule();return}
    const source=this.source=new EventSource('/api/events?heartbeat=1');
    this.lastSeen=Date.now();this.connectionId=null;
    const current=()=>!this.closed&&this.source===source;
    source.onerror=()=>{if(current())this.failed()};
    source.addEventListener('ready',event=>{
      if(!current())return;
      try{
        const session=JSON.parse(event.data);
        if(this.userId&&session.userId!==this.userId){this.close();this.onFatal(Object.assign(Error('Аккаунт изменился. Обновите страницу.'),{status:401}));return}
        this.connectionId=session.connectionId;if(!this.connectionId)throw Error('Missing event connection');
        this.onSession(session);this.acknowledge(source);
      }catch{this.failed()}
    });
    source.addEventListener('heartbeat',()=>{if(current()){this.lastSeen=Date.now();this.acknowledge(source)}});
    source.onmessage=event=>{
      if(!current())return;
      this.lastSeen=Date.now();
      try{this.onMessage(JSON.parse(event.data))}catch(error){console.warn('Event processing failed',error)}
    };
  }
  acknowledge(source) {
    if(this.pending||!this.connectionId||this.closed||source!==this.source)return;
    const controller=new AbortController();this.pending=controller;
    const timer=setTimeout(()=>controller.abort(),8000);
    this.request('/api/events/ping','POST',{connectionId:this.connectionId},{signal:controller.signal}).then(()=>{
      if(this.closed||source!==this.source)return;
      this.lastSeen=Date.now();
      if(!this.connected){this.connected=true;this.attempt=0;this.onOpen()}
    }).catch(error=>{
      if(this.closed||source!==this.source)return;
      if([400,401,403].includes(error.status)){this.close();this.onFatal(error)}else this.failed();
    }).finally(()=>{clearTimeout(timer);if(this.pending===controller)this.pending=null});
  }
  schedule() {
    if(this.closed||this.retryTimer)return;
    const delay=Math.min(10000,500*2**Math.min(this.attempt++,5));
    this.retryTimer=setTimeout(()=>{this.retryTimer=null;this.connect()},delay);
  }
  detach() {
    this.source?.close();this.source=null;this.connectionId=null;
    this.pending?.abort();this.pending=null;
  }
  failed() {
    if(this.closed)return;
    this.detach();
    this.connected=false;this.onDisconnect();this.schedule();
  }
  reconnect() {
    if(this.closed)return;
    clearTimeout(this.retryTimer);this.retryTimer=null;
    this.detach();this.connected=false;this.onDisconnect();this.connect();
  }
  close() {
    this.closed=true;this.connected=false;this.detach();
    clearTimeout(this.retryTimer);clearInterval(this.watchdog);this.retryTimer=null;
    window.removeEventListener('online',this.online);window.removeEventListener('offline',this.offline);window.removeEventListener('focus',this.wake);
    document.removeEventListener('visibilitychange',this.visible);
  }
}
