import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';

test('presence acknowledgement is session scoped and abandoned event streams expire',{timeout:35000},async t=>{
 const directory=mkdtempSync(path.join(tmpdir(),'vibra-presence-')),before=process.env.DATA_DIR;process.env.DATA_DIR=directory;
 const {server,db}=await import('../server.mjs?presence='+Date.now());await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const base='http://127.0.0.1:'+server.address().port,abort=new AbortController();let reader,draining;
 t.after(async()=>{abort.abort();await draining;server.closeAllConnections();await new Promise(resolve=>server.close(resolve));db.close();rmSync(directory,{recursive:true,force:true});if(before===undefined)delete process.env.DATA_DIR;else process.env.DATA_DIR=before});
 async function api(client,url,method='GET',body,status=200){const response=await fetch(base+url,{method,headers:{'content-type':'application/json',cookie:client.cookie||'','x-csrf':client.csrf||''},body:body?JSON.stringify(body):undefined});const result=await response.json();assert.equal(response.status,status,JSON.stringify(result));if(response.headers.has('set-cookie'))client.cookie=response.headers.get('set-cookie').split(';')[0];if(result.csrf)client.csrf=result.csrf;return result}
 const a={},b={};await api(a,'/api/auth/register','POST',{username:'presence_alice',password:'presence-password'});await api(b,'/api/auth/register','POST',{username:'presence_bob',password:'presence-password'});
 const stream=await fetch(base+'/api/events?heartbeat=1',{headers:{cookie:a.cookie},signal:abort.signal});assert.equal(stream.status,200);reader=stream.body.getReader();
 let pending='',id;
 while(!id){const chunk=await reader.read();assert(!chunk.done);pending+=new TextDecoder().decode(chunk.value);const ready=pending.match(/event: ready\ndata: (.+)\n/);if(ready)id=JSON.parse(ready[1]).connectionId}
 draining=(async()=>{try{while(!(await reader.read()).done){}}catch(error){if(!abort.signal.aborted)throw error}})();
 await api(b,'/api/events/ping','POST',{connectionId:id},409);
 await api(a,'/api/events/ping','POST',{connectionId:id});
 assert.equal((await api(b,'/api/users?q=presence_alice')).users[0].status,'online');
 // No acknowledgements: even a TCP connection that looks open must go offline.
 await new Promise(resolve=>setTimeout(resolve,20500));
 assert.equal((await api(b,'/api/users?q=presence_alice')).users[0].status,'offline');
 await api(a,'/api/events/ping','POST',{connectionId:id},409);
});
