// RNNoise runs locally on the AudioWorklet thread, before PCM downsampling.
let binary;
const contexts=new WeakMap();
function loadBinary(){if(!binary)binary=fetch('/vendor/rnnoise/rnnoise.wasm',{signal:AbortSignal.timeout(15000)}).then(async response=>{if(!response.ok)throw Error('Не удалось загрузить RNNoise');const bytes=await response.arrayBuffer();if(bytes.byteLength>1024*1024)throw Error('Некорректная модель RNNoise');return bytes}).catch(error=>{binary=null;throw error});return binary}
export async function createNoiseFilter(context,onFailure){
 if(context.sampleRate!==48000)throw Error('RNNoise требует частоту 48 кГц');
 const wasmBinary=await loadBinary();
 if(!contexts.has(context))contexts.set(context,context.audioWorklet.addModule('/vendor/rnnoise/worklet.js').catch(error=>{contexts.delete(context);throw error}));
 await contexts.get(context);
 const node=new AudioWorkletNode(context,'@sapphi-red/web-noise-suppressor/rnnoise',{channelCount:1,channelCountMode:'explicit',outputChannelCount:[1],processorOptions:{maxChannels:1,wasmBinary}});
 let disposed=false,ready=false,timer;
 const dispose=()=>{if(disposed)return;disposed=true;clearTimeout(timer);try{node.port.postMessage('destroy');node.disconnect();node.port.close()}catch{}};
 try{await new Promise((resolve,reject)=>{const failed=()=>{if(disposed)return;if(!ready)reject(Error('Не удалось запустить RNNoise'));else onFailure?.()};timer=setTimeout(()=>reject(Error('RNNoise не ответил. Выберите другой режим.')),15000);node.onprocessorerror=failed;node.port.onmessage=event=>{if(event.data?.type==='ready'){ready=true;clearTimeout(timer);resolve()}else if(event.data?.type==='error')failed()};node.port.start()});return {node,dispose}}
 catch(error){binary=null;dispose();throw error}
}
