// Video-only screen sharing. Voice moderation remains enforced by Vibra's audio relay.
export class VibraScreen {
 constructor({request,userId,onChange=()=>{},onError=()=>{}}){
  this.request=request;this.userId=userId;this.onChange=onChange;this.onError=onError;
  this.state={supported:!!navigator.mediaDevices?.getDisplayMedia&&!!window.RTCPeerConnection,viewerSupported:!!window.RTCPeerConnection,ready:false,starting:false,stopping:false,shareId:null,channelId:null,presenterId:null,participants:[],status:'idle',stream:null,actual:null,playbackBlocked:false,peers:[],error:null};
  this.peers=new Map();this.generation=0;this.eventQueue=[];this.iceServers=[];this.voiceConnected=false;this.clientId=null;this.capture=null;
  this.retiredShares=new Set();this.announcedShareId=null;this.awaitingAnnouncement=null;this.startOperation=null;
  this.pagehide=()=>this.clear();window.addEventListener('pagehide',this.pagehide);
  this.statsTimer=setInterval(()=>this.readStats(),2500);
 }
 emit(){this.state.peers=[...this.peers].map(([id,p])=>({id,status:p.pc.connectionState,stats:p.stats}));this.onChange(this.state)}
 async updateVoice(voice,clientId){
  const channelId=voice.connected?voice.channelId:null;this.voiceConnected=!!voice.connected;
  if(channelId===this.state.channelId&&clientId===this.clientId)return;
  this.clear();this.clientId=clientId;this.state.channelId=channelId;
  if(!channelId){this.emit();return}
  const generation=this.generation;
  try{const [config,state]=await Promise.all([this.request('/api/screen/config'),this.request('/api/screen/state?channelId='+encodeURIComponent(channelId))]);if(generation!==this.generation)return;this.iceServers=config.iceServers||[];this.state.ready=true;this.applyState(state);const queued=this.eventQueue;this.eventQueue=[];for(const event of queued){if(this.state.channelId!==channelId||this.clientId!==clientId)break;this.handleEvent(event)}}catch(error){if(generation===this.generation)this.fail(error)}
 }
 async start(){
  if(!this.state.supported)throw new Error('Этот браузер не поддерживает захват экрана. Откройте Vibra в актуальном настольном Chrome, Edge или Firefox.');
  if(!this.voiceConnected||!this.clientId)throw new Error('Сначала подключитесь к голосовому каналу.');
  if(this.state.presenterId&&this.state.presenterId!==this.userId)throw new Error('В этом канале уже идёт трансляция.');
  if(this.state.starting||this.state.stopping)throw new Error('Дождитесь завершения предыдущего действия с трансляцией.');
  if(this.capture)return;
  if(!this.state.ready)throw new Error('Видеосвязь ещё подключается. Повторите попытку через секунду; при ошибке переподключитесь к голосу.');
  const generation=this.generation,clientId=this.clientId,startToken=Symbol();this.startToken=startToken;
  const operation=this.startOperation={token:startToken,generation,clientId,cancelled:false};
  this.state.starting=true;this.state.status='capturing';this.state.error=null;this.emit();
  let stream;
  try{
   // Called before any await: native picker retains the button's user activation.
   stream=await navigator.mediaDevices.getDisplayMedia({video:{width:{ideal:3840,max:3840},height:{ideal:2160,max:2160},frameRate:{ideal:60,max:60}},audio:false});
   if(generation!==this.generation){stream.getTracks().forEach(t=>t.stop());return}
   stream.getAudioTracks().forEach(t=>{t.stop();stream.removeTrack(t)});
   const track=stream.getVideoTracks()[0];if(!track)throw new Error('Браузер не предоставил видеодорожку экрана.');
   try{track.contentHint='detail'}catch{}
   this.capture=stream;this.state.stream=stream;this.state.actual=this.trackQuality(track);
   track.onended=()=>this.stop();
   const result=await this.request('/api/screen/start','POST',{clientId});
   if(generation!==this.generation){stream.getTracks().forEach(t=>{t.onended=null;t.stop()});if(result.shareId){this.retireShare(result.shareId);await this.request('/api/screen/stop','POST',{clientId,shareId:result.shareId}).catch(()=>{});}return}
   this.applyState({...result,participants:result.participants||this.state.participants},{fromStart:true});
   this.state.presenterId=this.userId;this.state.status='live';this.emit();await this.reconcile();
  }catch(error){stream?.getTracks().forEach(t=>{t.onended=null;t.stop()});if(generation!==this.generation)return;if(this.capture===stream){this.capture=null;if(this.state.stream===stream){this.state.stream=null;this.state.actual=null;}}if(this.state.presenterId&&this.state.presenterId!==this.userId){this.onError(error);return;}if(error.name==='NotAllowedError'||error.name==='AbortError'){this.state.status='idle';this.state.error='Выбор экрана отменён или разрешение не выдано. На macOS проверьте доступ браузера к записи экрана в системных настройках.';this.emit();this.onError(new Error(this.state.error))}else this.fail(error)}finally{if(this.startOperation===operation)this.startOperation=null;if(this.startToken===startToken){this.state.starting=false;this.emit()}}
 }
 trackQuality(track){const s=track.getSettings();return {width:s.width||0,height:s.height||0,frameRate:s.frameRate||0,displaySurface:s.displaySurface||'',codec:null}}
 async stop(){
  if(this.state.stopping)return;
  ++this.generation;
  if(this.startOperation)this.startOperation.cancelled=true;
  const stopToken=this.stopToken=Symbol(),clientId=this.clientId,shareId=this.state.shareId,wasOwn=this.state.presenterId===this.userId||!!this.capture;
  if(wasOwn)this.retireShare(shareId);
  this.state.stopping=true;this.closePeers();this.capture?.getTracks().forEach(t=>{t.onended=null;t.stop()});this.capture=null;this.state.stream=null;this.state.actual=null;
  if(wasOwn){this.state.presenterId=null;this.state.shareId=null;}
  this.state.status='idle';this.state.error=null;this.emit();
  try{if(wasOwn&&clientId&&shareId)await this.request('/api/screen/stop','POST',{clientId,shareId})}catch(error){this.onError(error)}finally{if(this.stopToken===stopToken){this.state.stopping=false;this.emit()}}
 }
 clear(){++this.generation;if(this.startOperation)this.startOperation.cancelled=true;this.startOperation=null;this.startToken=null;this.stopToken=null;this.awaitingAnnouncement=null;this.announcedShareId=null;this.eventQueue=[];this.closePeers();this.capture?.getTracks().forEach(t=>{t.onended=null;t.stop()});this.capture=null;Object.assign(this.state,{ready:false,starting:false,stopping:false,shareId:null,channelId:null,presenterId:null,participants:[],status:'idle',stream:null,actual:null,playbackBlocked:false,error:null})}
 retireShare(id){if(!id)return;this.retiredShares.add(id);if(this.retiredShares.size>64)this.retiredShares.delete(this.retiredShares.values().next().value);if(this.awaitingAnnouncement===id)this.awaitingAnnouncement=null;}
 closePeers(){for(const p of this.peers.values()){clearTimeout(p.timeout);p.pc.onconnectionstatechange=null;p.pc.onicecandidate=null;p.pc.ontrack=null;p.pc.close()}this.peers.clear()}
 handleEvent(event){if(event.channelId!==this.state.channelId)return;if(!this.state.ready){if(event.type==='screen.state'||event.type==='screen.signal'){if(this.eventQueue.length>=256)this.eventQueue.shift();this.eventQueue.push(event)}return;}if(event.type==='screen.state')this.applyState(event);if(event.type==='screen.signal'){const generation=this.generation;this.signal(event).catch(e=>{if(generation===this.generation)this.fail(e)})}}
 applyState(data,{fromStart=false}={}){if(data.channelId!==this.state.channelId)return;const presenter=data.presenterId||null,shareId=data.shareId||null;
  if(shareId&&this.retiredShares.has(shareId))return;
  if(data.type==='screen.state'){
   // HTTP can overtake the SSE stream. A preceding stop's null announcement
   // must not stop a new capture before its own start announcement arrives.
   if(!presenter&&this.state.presenterId===this.userId&&this.awaitingAnnouncement===this.state.shareId)return;
   if(presenter===this.userId&&shareId){
    if(this.startOperation?.cancelled){this.retireShare(shareId);this.request('/api/screen/stop','POST',{clientId:this.startOperation.clientId,shareId}).catch(()=>{});return;}
    this.announcedShareId=shareId;if(this.awaitingAnnouncement===shareId)this.awaitingAnnouncement=null;
   }
  }
  if(fromStart)this.awaitingAnnouncement=this.announcedShareId===shareId?null:shareId;
  if(presenter!==this.state.presenterId||shareId!==this.state.shareId){if(this.state.shareId)this.retireShare(this.state.shareId);if(this.state.presenterId)++this.generation;this.closePeers();if(presenter!==this.userId){this.capture?.getTracks().forEach(t=>{t.onended=null;t.stop()});this.capture=null;this.state.stream=null;this.state.actual=null}this.viewerStartedAt=Date.now();this.viewerRecoveryAttempts=0;this.state.presenterId=presenter;this.state.shareId=shareId;this.state.error=null;this.state.status=presenter?(presenter===this.userId?'live':'connecting'):'idle'}
  if(data.participants)this.state.participants=data.participants;this.emit();this.reconcile().catch(e=>this.fail(e));
 }
 async reconcile(){if(this.state.presenterId!==this.userId||!this.capture)return;const ids=this.state.participants.map(p=>typeof p==='string'?p:p.id).filter(id=>id!==this.userId);
  for(const[id,p]of this.peers)if(!ids.includes(id)){clearTimeout(p.timeout);p.pc.close();this.peers.delete(id)}
  await Promise.all(ids.filter(id=>!this.peers.has(id)).map(id=>this.offer(id)));this.emit();
 }
 peer(id,sending){
  const pc=new RTCPeerConnection({iceServers:this.iceServers}),generation=this.generation;
  const p={pc,candidates:[],chain:Promise.resolve(),stats:null,timeout:null,createdAt:Date.now(),frames:0,recoveryAttempts:0,sending};this.peers.set(id,p);
  const clientId=this.clientId,shareId=this.state.shareId;const send=(type,data={})=>this.request('/api/screen/signal','POST',{clientId,shareId,to:id,type,...data});p.send=send;
  pc.onicecandidate=e=>{if(e.candidate&&generation===this.generation)send('candidate',{candidate:e.candidate.toJSON()}).catch(error=>{if(generation===this.generation&&this.peers.get(id)===p)this.fail(error)})};
  pc.ontrack=e=>{if(generation!==this.generation||this.state.presenterId!==id||e.track.kind!=='video')return;this.state.stream=e.streams[0]||new MediaStream([e.track]);this.state.actual=this.trackQuality(e.track);this.state.status='connecting';this.emit()};
  pc.onconnectionstatechange=()=>{if(generation!==this.generation)return;if(pc.connectionState==='connected'){clearTimeout(p.timeout);this.state.status=sending?'live':p.frames?'live':'connecting';this.state.error=null}else if(['failed','disconnected'].includes(pc.connectionState)){this.state.status='failed';this.state.error='Видеосоединение прервалось. Попросите ведущего остановить и снова запустить трансляцию. Между разными сетями может потребоваться TURN.'}this.emit()};
  p.timeout=setTimeout(()=>{if(generation===this.generation&&!['connected','closed'].includes(pc.connectionState)){this.state.status='failed';this.state.error='Не удалось установить видеосоединение. Для разных сетей настройте STUN/TURN на сервере. Ведущий может перезапустить трансляцию.';this.emit()}},20000);
  if(sending){const track=this.capture.getVideoTracks()[0],sender=pc.addTrack(track,this.capture);const transceiver=pc.getTransceivers().find(t=>t.sender===sender);const codecs=RTCRtpSender.getCapabilities?.('video')?.codecs||[];const priority=['video/VP8','video/H264','video/VP9','video/AV1'];if(transceiver?.setCodecPreferences&&codecs.length){try{transceiver.setCodecPreferences([...codecs].sort((a,b)=>{const ai=priority.indexOf(a.mimeType),bi=priority.indexOf(b.mimeType);return(ai<0?99:ai)-(bi<0?99:bi)}))}catch{}}p.sender=sender}
  return p;
 }
 async offer(id,{restart=false}={}){const generation=this.generation,p=restart&&this.peers.get(id)||this.peer(id,true);try{if(restart){p.pc.restartIce();p.createdAt=Date.now()}await p.pc.setLocalDescription(await p.pc.createOffer(restart?{iceRestart:true}:undefined));if(generation!==this.generation||this.peers.get(id)!==p)return;await p.send('offer',{sdp:p.pc.localDescription.sdp});try{const parameters=p.sender.getParameters();parameters.encodings=parameters.encodings?.length?parameters.encodings:[{}];parameters.encodings[0].maxBitrate=25000000;parameters.encodings[0].maxFramerate=60;parameters.degradationPreference='maintain-resolution';await p.sender.setParameters(parameters)}catch{} }catch(error){if(generation===this.generation&&this.peers.get(id)===p)this.fail(error)}}
 async signal(event){if(event.shareId!==this.state.shareId)return;const id=event.from,signal=event.signal,generation=this.generation;if(!this.state.presenterId||!signal)return;
  if(this.state.presenterId!==this.userId&&id!==this.state.presenterId)return;
  let p=this.peers.get(id);if(!p){if(signal.type==='restart'&&this.state.presenterId===this.userId&&this.capture){await this.offer(id);return}if(this.state.presenterId===this.userId||!['offer','candidate'].includes(signal.type))return;p=this.peer(id,false)}
  p.chain=p.chain.catch(()=>{}).then(async()=>{const current=()=>generation===this.generation&&this.peers.get(id)===p&&event.shareId===this.state.shareId;if(!current())return;if(signal.type==='restart'){if(this.state.presenterId===this.userId&&this.capture)await this.offer(id,{restart:true});return;}if(signal.type==='offer'){if(this.state.presenterId===this.userId)return;await p.pc.setRemoteDescription({type:'offer',sdp:signal.sdp});if(!current())return;for(const candidate of p.candidates){if(!current())return;await p.pc.addIceCandidate(candidate);}p.candidates=[];await p.pc.setLocalDescription(await p.pc.createAnswer());if(!current())return;await p.send('answer',{sdp:p.pc.localDescription.sdp})}else if(signal.type==='answer'){await p.pc.setRemoteDescription({type:'answer',sdp:signal.sdp});if(!current())return;for(const candidate of p.candidates)await p.pc.addIceCandidate(candidate);p.candidates=[]}else if(signal.type==='candidate'){if(p.pc.remoteDescription)await p.pc.addIceCandidate(signal.candidate);else p.candidates.push(signal.candidate)}});try{await p.chain}catch(error){if(generation===this.generation&&this.peers.get(id)===p)throw error}
 }
 attachVideo(video){if(!video)return;const changed=video.srcObject!==this.state.stream;if(changed){video.srcObject=this.state.stream;this.state.playbackBlocked=false}video.muted=true;if(this.state.stream&&(changed||video.paused)&&!this.state.playbackBlocked){const stream=this.state.stream;video.play().catch(()=>{if(this.state.stream===stream&&!this.state.playbackBlocked){this.state.playbackBlocked=true;this.emit()}})}}
 async playVideo(video){if(!video)return;video.muted=true;try{await video.play();this.state.playbackBlocked=false;this.emit()}catch{this.state.playbackBlocked=true;this.emit()}}
 async retryViewing(){if(this.state.presenterId===this.userId||!this.state.presenterId)return;const p=this.peers.get(this.state.presenterId);this.viewerStartedAt=Date.now();this.viewerRecoveryAttempts=(this.viewerRecoveryAttempts||0)+1;if(p){p.createdAt=Date.now();p.recoveryAttempts++}this.state.status='connecting';this.state.error=null;this.emit();if(p)await p.send('restart');else await this.request('/api/screen/signal','POST',{clientId:this.clientId,shareId:this.state.shareId,to:this.state.presenterId,type:'restart'})}
 async readStats(){if(!this.peers.size){if(this.state.presenterId&&this.state.presenterId!==this.userId&&Date.now()-this.viewerStartedAt>8000){if(!this.viewerRecoveryAttempts){try{await this.retryViewing()}catch(error){this.fail(error)}}else if(Date.now()-this.viewerStartedAt>12000){this.state.status='failed';this.state.error='Ведущий не ответил. Нажмите «Переподключить просмотр» или попросите его перезапустить трансляцию.';this.emit()}}return;}const generation=this.generation;for(const [id,p]of this.peers){try{const report=await p.pc.getStats();if(generation!==this.generation||this.peers.get(id)!==p)return;for(const r of report.values())if((r.type==='inbound-rtp'||r.type==='outbound-rtp')&&r.kind==='video'){const codec=report.get(r.codecId);p.frames=r.framesDecoded??r.framesEncoded??r.framesSent??0;p.stats={width:r.frameWidth||0,height:r.frameHeight||0,frameRate:r.framesPerSecond||0,frames:p.frames,bytes:r.bytesReceived??r.bytesSent??0,codec:codec?.mimeType?.replace('video/','')||''};if(!p.sending&&p.frames>0){this.state.status='live';this.state.error=null;this.state.actual={...this.state.actual,...p.stats}}}
 if(!p.sending&&!p.frames&&Date.now()-p.createdAt>8000){if(!p.recoveryAttempts){await this.retryViewing()}else if(Date.now()-p.createdAt>12000){this.state.status='failed';this.state.error='Соединение установлено, но видеокадры не приходят. Нажмите «Переподключить просмотр» или попросите ведущего выбрать другое окно.'}}
 }catch{}}this.emit()}
 fail(error){this.state.error=error.message||String(error);this.state.status='failed';this.emit();this.onError(error)}
 destroy(){this.clear();clearInterval(this.statsTimer);window.removeEventListener('pagehide',this.pagehide)}
}

