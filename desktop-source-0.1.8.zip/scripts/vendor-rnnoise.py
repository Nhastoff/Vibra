"""Pinned RNNoise worklet distribution; no CDN or package install at runtime."""
from pathlib import Path
import urllib.request,json,hashlib,base64,tarfile,io
root=Path(__file__).resolve().parents[1];out=root/'public/vendor/rnnoise';out.mkdir(parents=True,exist_ok=True)
url='https://registry.npmjs.org/@sapphi-red/web-noise-suppressor/0.4.1'
with urllib.request.urlopen(url,timeout=30) as response:meta=json.load(response)
with urllib.request.urlopen(meta['dist']['tarball'],timeout=40) as response:data=response.read()
assert 'sha512-'+base64.b64encode(hashlib.sha512(data).digest()).decode()==meta['dist']['integrity']
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
    worklet=archive.extractfile('package/dist/rnnoise/workletProcessor.js').read().decode()
    # Upstream has asynchronous initialization without a readiness/error signal.
    before='this.processor=p(t,{bufferSize:128,maxChannels:e.processorOptions.maxChannels}),this.destroyed&&this.destroy()})()'
    after='this.processor=p(t,{bufferSize:128,maxChannels:e.processorOptions.maxChannels}),this.destroyed?this.destroy():this.port.postMessage({type:"ready"})})().catch(()=>this.port.postMessage({type:"error"}));this.port.start()'
    assert worklet.count(before)==1
    worklet=worklet.replace(before,after).replace('//# sourceMappingURL=workletProcessor.js.map','')
    worklet += '\n// Expose the bundled WASM loader for Vibra\'s optional speech gate.\nexport { s as RNNoise };\n'
    (out/'worklet.js').write_text(worklet,encoding='utf-8')
    (out/'rnnoise.wasm').write_bytes(archive.extractfile('package/dist/rnnoise.wasm').read())
    (out/'LICENSE-MIT.txt').write_bytes(archive.extractfile('package/LICENSE').read())
for name,license_url in [('LICENSE-APACHE.txt','https://raw.githubusercontent.com/shiguredo/rnnoise-wasm/2022.2.0/LICENSE'),('LICENSE-BSD.txt','https://raw.githubusercontent.com/xiph/rnnoise/master/COPYING')]:
    with urllib.request.urlopen(license_url,timeout=30) as response:license_data=response.read()
    (out/name).write_bytes(license_data)
notice='''RNNoise noise suppression distributed with Vibra.
Worklet: @sapphi-red/web-noise-suppressor 0.4.1, MIT.
https://github.com/sapphi-red/web-noise-suppressor
Bundled WASM wrapper: @shiguredo/rnnoise-wasm 2022.2.0, Apache-2.0.
https://github.com/shiguredo/rnnoise-wasm
RNNoise: Xiph.Org, BSD-3-Clause. https://github.com/xiph/rnnoise
Local modifications: readiness and error notifications, explicit MessagePort.start;
removed sourcemap reference; exported existing WASM loader for the optional
speech gate. No RNNoise algorithm/model modification.
'''
(out/'NOTICE.txt').write_text(notice,encoding='utf-8')
record={'package':meta['name'],'version':meta['version'],'npmIntegrity':meta['dist']['integrity'],'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name!='manifest.json'}}
(out/'manifest.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps({'version':meta['version'],'integrityVerified':True,'vendoredFiles':len(record['files'])}))
