'use strict';
const q=selector=>document.querySelector(selector);
let busy=false;
function setBusy(value,label=''){busy=value;q('#remote-connect').disabled=value;q('#local-connect').disabled=value;q('#server-url').disabled=value;q('#status').textContent=label}
async function connect(input){if(busy)return;q('#error').hidden=true;setBusy(true,input.mode==='local'?'Запускаем ваше пространство…':'Подключаемся к серверу…');try{await window.vibraDesktop.connect(input)}catch(error){q('#error').textContent=(error.message||'Не удалось подключиться').replace(/^Error invoking remote method '[^']+': (?:Error: )?/,'');q('#error').hidden=false;setBusy(false)}}
q('#remote-form').addEventListener('submit',event=>{event.preventDefault();connect({mode:'remote',url:q('#server-url').value})});
q('#local-connect').addEventListener('click',()=>connect({mode:'local'}));
window.vibraDesktop.getConfig().then(config=>{q('#version').textContent='Vibra '+config.version+' · настольное приложение';q('#server-url').value=config.url||'';q('#server-url').focus()}).catch(()=>{q('#error').textContent='Не удалось прочитать настройки приложения.';q('#error').hidden=false});
