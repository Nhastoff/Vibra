import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { randomBytes, scrypt as scryptCallback, timingSafeEqual, createHash } from 'node:crypto';
import { promisify } from 'node:util';
import { mkdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createTurnCredentials } from './turn-auth.mjs';

const scrypt = promisify(scryptCallback);
const root = path.dirname(fileURLToPath(import.meta.url));
const dataDir = process.env.DATA_DIR || path.join(root, 'data');
mkdirSync(dataDir, { recursive: true });
const db = new DatabaseSync(path.join(dataDir, 'vibra.sqlite'));
db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, displayName TEXT NOT NULL, avatar TEXT DEFAULT '◈', status TEXT DEFAULT 'online', salt TEXT NOT NULL, password TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(hash TEXT PRIMARY KEY,userId TEXT NOT NULL REFERENCES users(id),csrf TEXT NOT NULL,expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS requests(id TEXT PRIMARY KEY,src TEXT NOT NULL,dst TEXT NOT NULL,UNIQUE(src,dst));
CREATE TABLE IF NOT EXISTS friends(a TEXT NOT NULL,b TEXT NOT NULL,PRIMARY KEY(a,b));
CREATE TABLE IF NOT EXISTS blocks(a TEXT NOT NULL,b TEXT NOT NULL,PRIMARY KEY(a,b));
CREATE TABLE IF NOT EXISTS dms(id TEXT PRIMARY KEY,a TEXT NOT NULL,b TEXT NOT NULL,UNIQUE(a,b));
CREATE TABLE IF NOT EXISTS servers(id TEXT PRIMARY KEY,name TEXT NOT NULL,icon TEXT NOT NULL,ownerId TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS members(serverId TEXT NOT NULL REFERENCES servers(id) ON DELETE CASCADE,userId TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'member',PRIMARY KEY(serverId,userId));
CREATE TABLE IF NOT EXISTS bans(serverId TEXT NOT NULL REFERENCES servers(id) ON DELETE CASCADE,userId TEXT NOT NULL,PRIMARY KEY(serverId,userId));
CREATE TABLE IF NOT EXISTS voice_mutes(serverId TEXT NOT NULL REFERENCES servers(id) ON DELETE CASCADE,userId TEXT NOT NULL,PRIMARY KEY(serverId,userId));
CREATE TABLE IF NOT EXISTS channels(id TEXT PRIMARY KEY,serverId TEXT NOT NULL REFERENCES servers(id) ON DELETE CASCADE,name TEXT NOT NULL,type TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS invites(token TEXT PRIMARY KEY,serverId TEXT NOT NULL REFERENCES servers(id) ON DELETE CASCADE,expiresAt INTEGER NOT NULL,revoked INTEGER DEFAULT 0,createdBy TEXT);
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT,channelId TEXT REFERENCES channels(id) ON DELETE CASCADE,dmId TEXT REFERENCES dms(id),authorId TEXT NOT NULL,content TEXT NOT NULL,createdAt INTEGER NOT NULL,editedAt INTEGER,nonce TEXT NOT NULL,UNIQUE(authorId,nonce));
CREATE TABLE IF NOT EXISTS message_images(id TEXT PRIMARY KEY,messageId INTEGER NOT NULL REFERENCES messages(id) ON DELETE CASCADE,name TEXT NOT NULL,mime TEXT NOT NULL,size INTEGER NOT NULL,data BLOB NOT NULL);
CREATE INDEX IF NOT EXISTS message_images_message ON message_images(messageId);
CREATE TABLE IF NOT EXISTS reads(userId TEXT NOT NULL,target TEXT NOT NULL,lastId INTEGER NOT NULL,PRIMARY KEY(userId,target));
CREATE TABLE IF NOT EXISTS call_invites(hash TEXT PRIMARY KEY,channelId TEXT NOT NULL REFERENCES channels(id) ON DELETE CASCADE,expiresAt INTEGER NOT NULL,revoked INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS call_access(userId TEXT NOT NULL,inviteHash TEXT NOT NULL REFERENCES call_invites(hash) ON DELETE CASCADE,expiresAt INTEGER NOT NULL,PRIMARY KEY(userId,inviteHash));
CREATE TABLE IF NOT EXISTS guests(userId TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE);
`);
if(!db.prepare('PRAGMA table_info(invites)').all().some(c=>c.name==='createdBy'))db.exec('ALTER TABLE invites ADD COLUMN createdBy TEXT');
const q = (sql, ...p) => db.prepare(sql).all(...p.map(v=>v===undefined?null:v));
const one = (sql, ...p) => db.prepare(sql).get(...p.map(v=>v===undefined?null:v));
const run = (sql, ...p) => db.prepare(sql).run(...p.map(v=>v===undefined?null:v));
const id = () => randomBytes(16).toString('hex');
const hash = x => createHash('sha256').update(x).digest('hex');
const publicUser = (u,preserve=false) => u && ({ id: u.id, username: u.username, displayName: u.displayName, avatar: u.avatar, status: preserve||[...(streams.get(u.id)||[])].some(c=>!c.res.destroyed&&!c.res.writableEnded&&one('SELECT 1 FROM sessions WHERE hash=? AND expires>?',c.sessionHash,Date.now()))?u.status:'offline' });
const user = (uid,preserve=false) => publicUser(one('SELECT * FROM users WHERE id=?', uid),preserve);
const fail = (status, message) => { const e = new Error(message); e.status = status; throw e; };
const need = (v, status = 400, text = 'Некорректные данные') => { if (!v) fail(status, text); return v; };
const str = (v, min, max, label = 'Значение') => { need(typeof v === 'string' && v.trim().length >= min && v.trim().length <= max,400,`${label}: от ${min} до ${max} символов`); return v.trim(); };
const pair = (a,b) => [a,b].sort();
const blocked = (a,b) => !!one('SELECT 1 FROM blocks WHERE (a=? AND b=?) OR (a=? AND b=?)',a,b,b,a);
const friendship = (a,b) => !!one('SELECT 1 FROM friends WHERE a=? AND b=?',...pair(a,b));
const member = (sid,uid) => need(one('SELECT * FROM members WHERE serverId=? AND userId=?',sid,uid),403,'Нет доступа к серверу');
const admin = (sid,uid) => { const m = member(sid,uid); need(m.role !== 'member',403,'Нужны права администратора'); return m; };
const owner = (sid,uid) => { const m = member(sid,uid); need(m.role === 'owner',403,'Действие доступно владельцу'); return m; };
const channelAccess = (cid,uid) => { const c = need(one('SELECT * FROM channels WHERE id=?',cid),404,'Канал не найден');if(!one('SELECT 1 FROM members WHERE serverId=? AND userId=?',c.serverId,uid))need(c.type==='voice'&&one('SELECT 1 FROM call_access a JOIN call_invites i ON i.hash=a.inviteHash WHERE a.userId=? AND i.channelId=? AND a.expiresAt>? AND i.expiresAt>? AND i.revoked=0',uid,cid,Date.now(),Date.now()),403,'Нет доступа к звонку');return c; };
const dmAccess = (did,uid,write=false) => { const d = need(one('SELECT * FROM dms WHERE id=?',did),404,'Переписка не найдена'); need(d.a === uid || d.b === uid,403,'Нет доступа к переписке'); if(write) need(friendship(d.a,d.b) && !blocked(d.a,d.b),403,'Личные сообщения доступны только друзьям без блокировки'); return d; };
const streams = new Map();
const voices = new Map();
const VOICE_ROOM_LIMIT = 10;
// Screen pixels travel directly over native WebRTC. This server authorizes signaling;
// it cannot revoke an already established malicious peer connection as an SFU could.
const shares = new Map();
const turnCredentials=createTurnCredentials(process.env);
let iceServers=[];
if(process.env.VIBRA_ICE_SERVERS_JSON){
 try {const parsed=JSON.parse(process.env.VIBRA_ICE_SERVERS_JSON);need(Array.isArray(parsed)&&parsed.length<=10);iceServers=parsed.map(s=>{need(s&&typeof s==='object');const urls=Array.isArray(s.urls)?s.urls:[s.urls];need(urls.length>0&&urls.length<=10&&urls.every(u=>typeof u==='string'&&u.length<=500&&/^(stun|stuns|turn|turns):[^\s]+$/.test(u)));need(s.username===undefined||(typeof s.username==='string'&&s.username.length<=256));need(s.credential===undefined||(typeof s.credential==='string'&&s.credential.length<=1000));return {urls,...(s.username===undefined?{}:{username:s.username}),...(s.credential===undefined?{}:{credential:s.credential})};});}catch{throw new Error('VIBRA_ICE_SERVERS_JSON: ожидается массив корректных STUN/TURN-конфигураций');}
}
const limits = new Map();
let largeMessageReaders=0;
const MAX_IMAGE_BYTES=5*1024*1024;
function rate(key,max,ms) { const now=Date.now(); let a=limits.get(key); if(!a || now>a.end) {a={n:0,end:now+ms};limits.set(key,a);} need(++a.n<=max,429,'Слишком много запросов. Попробуйте позже'); }
function event(uid,payload,sessionHash) {if(!server.listening)return; for(const c of streams.get(uid)||[]) {if(c.res.destroyed||c.res.writableEnded)continue; if(sessionHash&&sessionHash!==c.sessionHash)continue;if(!one('SELECT 1 FROM sessions WHERE hash=? AND expires>?',c.sessionHash,Date.now())) {c.res.end();continue;} const message=`data: ${JSON.stringify(payload)}\n\n`;if(c.res.writableLength+Buffer.byteLength(message)>131072) {c.res.destroy();continue;} c.res.write(message); } }
function refresh() { for(const uid of streams.keys()) event(uid,{type:'refresh'}); }
function participants(cid) { return [...voices.values()].filter(v=>v.channelId===cid).map(v=>({...user(v.userId),serverMuted:v.serverMuted})); }
function screenSnapshot(cid){return {channelId:cid,presenterId:shares.get(cid)?.presenterId||null,shareId:shares.get(cid)?.shareId||null,participants:participants(cid)};}
function screenState(cid){const payload={type:'screen.state',...screenSnapshot(cid)};for(const v of voices.values())if(v.channelId===cid)event(v.userId,payload,v.sessionHash);}
function activeVoice(uid,sessionHash,clientId){const v=need(voices.get(uid),409,'Сначала подключитесь к голосовому каналу');need(v.sessionHash===sessionHash&&(clientId===undefined||v.clientId===clientId),409,'Голосовое подключение заменено');need(v.lastPing>Date.now()-15000,409,'Голосовое подключение истекло');need(one('SELECT 1 FROM sessions WHERE hash=? AND expires>?',v.sessionHash,Date.now()),401,'Сессия отозвана');channelAccess(v.channelId,uid);return v;}
function voiceState(cid) { const c=one('SELECT * FROM channels WHERE id=?',cid); if(!c)return; const payload={type:'voice.state',channelId:cid,participants:participants(cid)}; const ids=new Set([...q('SELECT userId FROM members WHERE serverId=?',c.serverId).map(m=>m.userId),...[...voices.values()].filter(v=>v.channelId===cid).map(v=>v.userId)]);for(const uid of ids)event(uid,payload);screenState(cid); }
function removeVoice(uid) { const v=voices.get(uid); if(!v)return; voices.delete(uid);if(shares.get(v.channelId)?.presenterId===uid)shares.delete(v.channelId);event(uid,{type:'screen.state',channelId:v.channelId,presenterId:null,shareId:null,participants:[]},v.sessionHash);event(uid,{type:'voice.state',channelId:v.channelId,participants:participants(v.channelId)}); voiceState(v.channelId); }
function removeServerVoice(sid,uid) { for(const v of [...voices.values()]) if((!uid||v.userId===uid)&&one('SELECT 1 FROM channels WHERE id=? AND serverId=?',v.channelId,sid))removeVoice(v.userId); }
function moderateTarget(sid,actor,target) { admin(sid,actor); const m=member(sid,target); need(target!==actor&&m.role==='member',403,'Можно модерировать только обычных участников'); return m; }
const unread=(uid,target)=>Number(one('SELECT count(*) n FROM messages WHERE (channelId=? OR dmId=?) AND id>COALESCE((SELECT lastId FROM reads WHERE userId=? AND target=?),0) AND authorId<>?',target,target,uid,target,uid).n);
function bootstrap(uid,csrf) {
 return {me:user(uid,true),csrf,limits:{voiceRoom:VOICE_ROOM_LIMIT,imageBytes:MAX_IMAGE_BYTES},
 friends:q('SELECT a,b FROM friends WHERE a=? OR b=?',uid,uid).map(f=>user(f.a===uid?f.b:f.a)),
 requests:q('SELECT * FROM requests WHERE src=? OR dst=?',uid,uid).map(r=>({id:r.id,from:r.src,to:r.dst,fromUser:user(r.src),toUser:user(r.dst)})),
 blocks:q('SELECT b FROM blocks WHERE a=?',uid).map(b=>user(b.b)),
 servers:q('SELECT s.*,m.role FROM servers s JOIN members m ON m.serverId=s.id WHERE m.userId=?',uid),
 dms:q('SELECT * FROM dms WHERE a=? OR b=?',uid,uid).map(d=>({id:d.id,peer:user(d.a===uid?d.b:d.a),unread:unread(uid,d.id)})),
 voice:voices.has(uid)?{channelId:voices.get(uid).channelId,participants:participants(voices.get(uid).channelId)}:null};
}

function messageView(m){return {...m,author:user(m.authorId),images:q('SELECT id,name,mime,size FROM message_images WHERE messageId=?',m.id).map(i=>({...i,url:'/api/message-images/'+i.id}))};}
function imageInput(image){
 need(image&&typeof image==='object'&&typeof image.data==='string'&&/^[A-Za-z0-9+/]+={0,2}$/.test(image.data)&&image.data.length%4===0,400,'Некорректная картинка');
 const bytes=Buffer.from(image.data,'base64');need(bytes.length>0&&bytes.length<=MAX_IMAGE_BYTES,413,'Картинка: до 5 МБ');let mime,extension;
 if(bytes.length>=33&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))&&bytes.toString('ascii',12,16)==='IHDR'){const w=bytes.readUInt32BE(16),h=bytes.readUInt32BE(20);need(w>0&&h>0&&w*h<=40000000,400,'Слишком большое разрешение картинки');mime='image/png';extension='png'}
 else if(bytes.length>=12&&bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP'){mime='image/webp';extension='webp'}
 else if(bytes.length>=13&&['GIF87a','GIF89a'].includes(bytes.toString('ascii',0,6))){const w=bytes.readUInt16LE(6),h=bytes.readUInt16LE(8);need(w>0&&h>0&&w*h<=40000000,400,'Слишком большое разрешение картинки');mime='image/gif';extension='gif'}
 else if(bytes.length>=4&&bytes[0]===255&&bytes[1]===216&&bytes[2]===255&&bytes.at(-2)===255&&bytes.at(-1)===217){mime='image/jpeg';extension='jpg'}
 else fail(400,'Поддерживаются PNG, JPG, WEBP и GIF');
 const name=String(image.name||'image.'+extension).replace(/[\/\\\x00-\x1f\x7f]/g,'_').slice(0,160)||'image.'+extension;
 return {name,mime,size:bytes.length,bytes};
}
async function passwordHash(password,salt) { return (await scrypt(password,salt,64)).toString('hex'); }
function passwordInput(p) { need(typeof p==='string'&&p.length>=8&&p.length<=128,400,'Пароль: от 8 до 128 символов');return p; }
function newSession(uid,res,lifetime=7*86400000) {const token=id()+id(),csrf=id();run('INSERT INTO sessions VALUES(?,?,?,?)',hash(token),uid,csrf,Date.now()+lifetime);res.setHeader('Set-Cookie',`vibra_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${Math.floor(lifetime/1000)}${process.env.COOKIE_SECURE==='1'?'; Secure':''}`);return csrf;}
function retireGuestSession(session){
 if(!session||!one('SELECT 1 FROM guests WHERE userId=?',session.userId))return;
 run('DELETE FROM sessions WHERE hash=? AND userId=?',session.hash,session.userId);
 if(voices.get(session.userId)?.sessionHash===session.hash)removeVoice(session.userId);
 for(const stream of streams.get(session.userId)||[])if(stream.sessionHash===session.hash)stream.res.end();
}
function callInvite(token){need(typeof token==='string'&&/^[a-f0-9]{64}$/.test(token),404,'Приглашение не найдено');const invite=need(one('SELECT i.*,c.name channelName,c.serverId,s.name serverName FROM call_invites i JOIN channels c ON c.id=i.channelId JOIN servers s ON s.id=c.serverId WHERE i.hash=?',hash(token)),404,'Приглашение не найдено');need(!invite.revoked&&invite.expiresAt>Date.now(),410,'Ссылка на звонок истекла или отозвана');return invite;}
async function body(req,max=20000) {let size=0,buf=[];for await(const c of req){size+=c.length;need(size<=max,413,'Слишком большой запрос');buf.push(c);}let value;try{value=JSON.parse(Buffer.concat(buf).toString()||'{}');}catch{fail(400,'Ожидается JSON');}need(value&&typeof value==='object'&&!Array.isArray(value),400,'Ожидается JSON-объект');return value;}
const types={'.wasm':'application/wasm','.txt':'text/plain; charset=utf-8','.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.json':'application/json','.png':'image/png','.ico':'image/x-icon'};
const server=http.createServer(async(req,res)=>{
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','same-origin');res.setHeader('X-Frame-Options','DENY');res.setHeader('Permissions-Policy','microphone=(self), camera=(), display-capture=(self)');
 res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
 const send=(data,status=200)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
 try {
 const url=new URL(req.url,'http://localhost'),p=url.pathname,method=req.method;
 const shortInvite=p.match(/^\/i\/([A-Za-z0-9_-]{8}|[a-f0-9]{64})$/);
 if(shortInvite&&(method==='GET'||method==='HEAD')){res.writeHead(307,{'Location':'/?invite='+shortInvite[1],'Cache-Control':'no-store'});res.end();return;}
 if(!p.startsWith('/api/')) {need(method==='GET'||method==='HEAD',405,'Метод недоступен');let filename=decodeURIComponent(p);need(!filename.includes('\0'),400);let f=path.resolve(root,'public','.'+filename);need(f.startsWith(path.join(root,'public')+path.sep)||f===path.join(root,'public'),403);try{if(statSync(f).isDirectory())f=path.join(f,'index.html');statSync(f);}catch{f=path.join(root,'public','index.html');}const content=readFileSync(f);res.writeHead(200,{'Content-Type':types[path.extname(f)]||'application/octet-stream','Cache-Control':'no-cache'});res.end(method==='HEAD'?undefined:content);return;}
 const mutate=!['GET','HEAD'].includes(method);
 if(mutate){const origin=req.headers.origin;need(!origin||origin===`http://${req.headers.host}`||origin===`https://${req.headers.host}`,403,'Недопустимый источник запроса');need(req.headers['content-type']?.startsWith('application/json'),415,'Ожидается application/json');}
 const token=(req.headers.cookie||'').split(';').map(v=>v.trim()).find(v=>v.startsWith('vibra_session='))?.slice(14);
 let largeBody=false;
 if(p==='/api/messages'&&method==='POST'){
  const early=token&&one('SELECT * FROM sessions WHERE hash=? AND expires>?',hash(token),Date.now());need(early,401,'Сначала войдите');need(req.headers['x-csrf']===early.csrf,403,'Недействительный CSRF-токен');
  const length=Number(req.headers['content-length']||0);need(length<=Math.ceil(MAX_IMAGE_BYTES*4/3)+16000,413,'Картинки в одном сообщении: до 5 МБ');
  largeBody=length>20000||!!req.headers['transfer-encoding'];if(largeBody){need(largeMessageReaders<2,429,'Загрузка занята. Повторите через несколько секунд');largeMessageReaders++;}
 }
 let b;try{b=mutate?await body(req,p==='/api/messages'&&method==='POST'?Math.ceil(MAX_IMAGE_BYTES*4/3)+16000:20000):{}}finally{if(largeBody)largeMessageReaders--;}
 // Reading a body yields to other requests. Resolve the session afterwards so a concurrent logout wins.
 const session=token&&one('SELECT * FROM sessions WHERE hash=? AND expires>?',hash(token),Date.now());
 if(p==='/api/call/preview'&&method==='POST'){rate('call-preview:'+req.socket.remoteAddress,60,60000);const inv=callInvite(b.token);send({channel:{id:inv.channelId,name:inv.channelName},server:{name:inv.serverName},expiresAt:inv.expiresAt});return;}
 if(p==='/api/call/join'&&method==='POST'){
  rate('call-join:'+req.socket.remoteAddress,20,3600000);const inv=callInvite(b.token);let uid=session?.userId,csrf=session?.csrf;
  if(session)need(req.headers['x-csrf']===csrf,403,'Недействительный CSRF-токен');
  need(!uid||!one('SELECT 1 FROM bans WHERE serverId=? AND userId=?',inv.serverId,uid),403,'Вы заблокированы на сервере');
  if(!uid){const name=str(b.name,1,40,'Имя');need(Number(one('SELECT count(*) n FROM guests').n)<100,503,'Слишком много гостей, попробуйте позже');uid=id();run('INSERT INTO users(id,username,displayName,salt,password) VALUES(?,?,?,?,?)',uid,'guest_'+id().slice(0,18),name,id(),randomBytes(64).toString('hex'));run('INSERT INTO guests VALUES(?)',uid);csrf=newSession(uid,res,Math.min(86400000,inv.expiresAt-Date.now()));}
  run('INSERT OR REPLACE INTO call_access VALUES(?,?,?)',uid,inv.hash,Math.min(inv.expiresAt,Date.now()+86400000));send({me:{...user(uid,true),guest:!!one('SELECT 1 FROM guests WHERE userId=?',uid)},csrf,limits:{voiceRoom:VOICE_ROOM_LIMIT,imageBytes:MAX_IMAGE_BYTES},channel:{id:inv.channelId,name:inv.channelName},server:{name:inv.serverName}});return;
 }
 if(p==='/api/auth/register'||p==='/api/auth/login') {
 need(method==='POST',405);rate('auth:'+req.socket.remoteAddress,20,60000);const username=str(b.username,3,24,'Никнейм').toLowerCase();need(/^[a-z0-9_]+$/.test(username),400,'Никнейм: латиница, цифры и подчёркивание');passwordInput(b.password);
 let u=one('SELECT * FROM users WHERE username=?',username);
 if(p.endsWith('register')) {need(!u,409,'Никнейм уже занят');const displayName=str(b.displayName||b.username,1,40,'Имя');const salt=id(),password=await passwordHash(b.password,salt),uid=id();try{run('INSERT INTO users(id,username,displayName,salt,password) VALUES(?,?,?,?,?)',uid,username,displayName,salt,password);}catch{fail(409,'Никнейм уже занят');}u=one('SELECT * FROM users WHERE id=?',uid);}
 else {const actual=await passwordHash(b.password,u?.salt||'vibra-invalid-user-salt');const current=u&&one('SELECT password,salt FROM users WHERE id=?',u.id);need(u&&current?.password===u.password&&current?.salt===u.salt&&timingSafeEqual(Buffer.from(actual,'hex'),Buffer.from(u.password,'hex')),401,'Неверный никнейм или пароль');}
 const csrf=newSession(u.id,res);retireGuestSession(session);send({me:publicUser(u,true),csrf});return;
 }
 if(method==='GET'&&/^\/api\/invites\/(?:[A-Za-z0-9_-]{8}|[a-f0-9]{64})$/.test(p)) {rate('invite-preview:'+req.socket.remoteAddress,60,60000);const inv=need(one('SELECT i.*,s.name,s.icon FROM invites i JOIN servers s ON s.id=i.serverId WHERE token=?',p.split('/')[3]),404,'Приглашение не найдено');need(!inv.revoked&&inv.expiresAt>Date.now(),410,'Приглашение истекло или отозвано');send({server:{id:inv.serverId,name:inv.name,icon:inv.icon},expiresAt:inv.expiresAt});return;}
 need(session,401,'Войдите в аккаунт');const uid=session.userId;
 if(mutate)need(req.headers['x-csrf']===session.csrf,403,'Недействительный CSRF-токен');
 const guest=!!one('SELECT 1 FROM guests WHERE userId=?',uid);
 if(guest)need(['/api/bootstrap','/api/events','/api/auth/logout'].includes(p)||p.startsWith('/api/voice/')||p.startsWith('/api/screen/'),403,'Гостю доступен только звонок по приглашению');
 if(!p.startsWith('/api/voice/')&&p!=='/api/events')rate('api:'+uid,900,60000);
 if(mutate&&!p.startsWith('/api/voice/'))rate('mutation:'+uid,240,60000);
 if(p==='/api/bootstrap'&&method==='GET'){const state=bootstrap(uid,session.csrf);if(guest)state.me.guest=true;send(state);return;}
 if(p==='/api/call/invites'&&method==='POST'){const c=channelAccess(b.channelId,uid);admin(c.serverId,uid);need(c.type==='voice',400,'Выберите голосовой канал');rate('call-create:'+uid,20,60000);const hours=Number(b.hours??24);need(Number.isFinite(hours)&&hours>=1&&hours<=168,400,'Срок ссылки: 1–168 часов');const token=id()+id(),expiresAt=Date.now()+hours*3600000;run('INSERT INTO call_invites VALUES(?,?,?,0)',hash(token),c.id,expiresAt);send({token,id:hash(token),expiresAt});return;}
 if(p==='/api/call/invites'&&method==='GET'){const c=need(one('SELECT * FROM channels WHERE id=?',url.searchParams.get('channelId')),404);admin(c.serverId,uid);send({invites:q('SELECT hash id,expiresAt,revoked FROM call_invites WHERE channelId=?',c.id)});return;}
 if(p.startsWith('/api/call/invites/')&&method==='DELETE'){const inv=need(one('SELECT i.*,c.serverId FROM call_invites i JOIN channels c ON c.id=i.channelId WHERE i.hash=?',p.split('/').pop()),404);admin(inv.serverId,uid);run('UPDATE call_invites SET revoked=1 WHERE hash=?',inv.hash);for(const v of [...voices.values()]){try{channelAccess(v.channelId,v.userId)}catch{removeVoice(v.userId)}}send({ok:true});return;}
 if(p==='/api/events'&&method==='GET') {res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','X-Accel-Buffering':'no'});res.write(': connected\n\n');let set=streams.get(uid);if(!set){set=new Set();streams.set(uid,set);}if(set.size>=4){const c=set.values().next().value;c.res.end();set.delete(c);}const c={res,sessionHash:session.hash};set.add(c);if(set.size===1)for(const peer of streams.keys())if(peer!==uid)event(peer,{type:'refresh'});req.on('close',()=>{set.delete(c);if(!set.size){streams.delete(uid);for(const peer of streams.keys())if(peer!==uid)event(peer,{type:'refresh'});}});return;}
 if(p==='/api/auth/logout'&&method==='POST'){run('DELETE FROM sessions WHERE hash=?',session.hash);if(voices.get(uid)?.sessionHash===session.hash)removeVoice(uid);for(const c of streams.get(uid)||[])if(c.sessionHash===session.hash)c.res.end();res.setHeader('Set-Cookie','vibra_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');send({ok:true});return;}
 if(p==='/api/profile'&&method==='PATCH'){const u=user(uid);const name=b.displayName===undefined?u.displayName:str(b.displayName,1,40,'Имя');const avatar=b.avatar===undefined?u.avatar:str(b.avatar,1,8,'Аватар');const status=b.status??u.status;need(['online','dnd','offline'].includes(status));run('UPDATE users SET displayName=?,avatar=?,status=? WHERE id=?',name,avatar,status,uid);refresh();send({me:user(uid,true)});return;}
 if(p==='/api/password'&&method==='POST'){rate('password:'+uid,5,60000);const u=one('SELECT * FROM users WHERE id=?',uid);passwordInput(b.currentPassword);passwordInput(b.newPassword);need(timingSafeEqual(Buffer.from(await passwordHash(b.currentPassword,u.salt),'hex'),Buffer.from(u.password,'hex')),403,'Неверный текущий пароль');const salt=id(),newHash=await passwordHash(b.newPassword,salt);need(one('SELECT 1 FROM sessions WHERE hash=? AND expires>?',session.hash,Date.now()),401,'Сессия отозвана');const current=one('SELECT password,salt FROM users WHERE id=?',uid);need(current.password===u.password&&current.salt===u.salt,409,'Пароль уже изменён, повторите запрос');run('UPDATE users SET salt=?,password=? WHERE id=?',salt,newHash,uid);run('DELETE FROM sessions WHERE userId=? AND hash<>?',uid,session.hash);if(voices.has(uid)&&voices.get(uid).sessionHash!==session.hash)removeVoice(uid);for(const c of streams.get(uid)||[])if(c.sessionHash!==session.hash)c.res.end();send({ok:true});return;}
 if(p==='/api/users'&&method==='GET'){rate('search:'+uid,40,60000);const term=str(url.searchParams.get('q')||'',1,24).toLowerCase();send({users:q('SELECT * FROM users WHERE username LIKE ? ESCAPE \'!\' AND id<>? LIMIT 15','%'+term.replace(/[!%_]/g,'!$&')+'%',uid).map(u=>publicUser(u))});return;}
 if(p==='/api/friends/request'&&method==='POST'){rate('friend:'+uid,20,60000);const target=need(user(b.userId),404,'Пользователь не найден');need(target.id!==uid&&!blocked(uid,target.id),403,'Запрос недоступен');need(!friendship(uid,target.id),409,'Вы уже друзья');need(!one('SELECT 1 FROM requests WHERE (src=? AND dst=?) OR (src=? AND dst=?)',uid,target.id,target.id,uid),409,'Запрос уже существует');run('INSERT INTO requests VALUES(?,?,?)',id(),uid,target.id);refresh();send({ok:true});return;}
 let m;
 if((m=p.match(/^\/api\/friends\/([^/]+)\/(accept|reject)$/))&&method==='POST'){const r=need(one('SELECT * FROM requests WHERE id=?',m[1]),404,'Запрос не найден');need(r.dst===uid,403,'Нет доступа');if(m[2]==='accept'){need(!blocked(uid,r.src),403,'Пользователь заблокирован');run('INSERT OR IGNORE INTO friends VALUES(?,?)',...pair(uid,r.src));}run('DELETE FROM requests WHERE id=?',r.id);refresh();send({ok:true});return;}
 if((m=p.match(/^\/api\/friends\/requests\/([^/]+)$/))&&method==='DELETE'){const r=need(one('SELECT * FROM requests WHERE id=?',m[1]),404);need(r.src===uid,403);run('DELETE FROM requests WHERE id=?',r.id);refresh();send({ok:true});return;}
 if((m=p.match(/^\/api\/friends\/([^/]+)$/))&&method==='DELETE'){run('DELETE FROM friends WHERE a=? AND b=?',...pair(uid,m[1]));refresh();send({ok:true});return;}
 if(p==='/api/blocks'&&method==='POST'){need(user(b.userId)&&b.userId!==uid,400);run('INSERT OR IGNORE INTO blocks VALUES(?,?)',uid,b.userId);run('DELETE FROM friends WHERE a=? AND b=?',...pair(uid,b.userId));run('DELETE FROM requests WHERE (src=? AND dst=?) OR (src=? AND dst=?)',uid,b.userId,b.userId,uid);refresh();send({ok:true});return;}
 if((m=p.match(/^\/api\/blocks\/([^/]+)$/))&&method==='DELETE'){run('DELETE FROM blocks WHERE a=? AND b=?',uid,m[1]);refresh();send({ok:true});return;}
 if(p==='/api/dms'&&method==='POST'){need(friendship(uid,b.userId)&&!blocked(uid,b.userId),403,'Переписка доступна только друзьям');const [a,z]=pair(uid,b.userId);let d=one('SELECT * FROM dms WHERE a=? AND b=?',a,z);if(!d){d={id:id()};run('INSERT INTO dms VALUES(?,?,?)',d.id,a,z);}refresh();send({id:d.id,peer:user(b.userId)});return;}
 if(p==='/api/servers'&&method==='POST'){rate('servers:'+uid,10,60000);const sid=id(),name=str(b.name,1,60,'Название'),icon=str(b.icon||'◈',1,8,'Иконка');run('INSERT INTO servers VALUES(?,?,?,?)',sid,name,icon,uid);run('INSERT INTO members VALUES(?,?,?)',sid,uid,'owner');run('INSERT INTO channels VALUES(?,?,?,?)',id(),sid,'общий','text');run('INSERT INTO channels VALUES(?,?,?,?)',id(),sid,'Гостиная','voice');refresh();send({id:sid});return;}
 if((m=p.match(/^\/api\/servers\/([^/]+)$/))){const sid=m[1];member(sid,uid);if(method==='GET'){send({server:one('SELECT s.*,m.role FROM servers s JOIN members m ON m.serverId=s.id AND m.userId=? WHERE s.id=?',uid,sid),channels:q('SELECT * FROM channels WHERE serverId=? ORDER BY rowid',sid).map(c=>({...c,unread:c.type==='text'?unread(uid,c.id):0,...(c.type==='voice'?{participants:participants(c.id)}:{})})),members:q('SELECT u.*,m.role FROM users u JOIN members m ON m.userId=u.id WHERE m.serverId=?',sid).map(u=>({...publicUser(u),role:u.role})),invites:member(sid,uid).role==='member'?q('SELECT token,expiresAt,revoked,createdBy FROM invites WHERE serverId=? AND createdBy=?',sid,uid):q('SELECT token,expiresAt,revoked,createdBy FROM invites WHERE serverId=?',sid)});return;}if(method==='PATCH'){admin(sid,uid);run('UPDATE servers SET name=?,icon=? WHERE id=?',str(b.name,1,60,'Название'),str(b.icon||one('SELECT icon FROM servers WHERE id=?',sid).icon,1,8),sid);}else if(method==='DELETE'){owner(sid,uid);removeServerVoice(sid);run('DELETE FROM servers WHERE id=?',sid);}else fail(405);refresh();send({ok:true});return;}
 if((m=p.match(/^\/api\/servers\/([^/]+)\/leave$/))&&method==='POST'){const role=member(m[1],uid).role;need(role!=='owner',403,'Сначала передайте владение или удалите сервер');removeServerVoice(m[1],uid);run('DELETE FROM members WHERE serverId=? AND userId=?',m[1],uid);refresh();send({ok:true});return;}
 if((m=p.match(/^\/api\/servers\/([^/]+)\/transfer$/))&&method==='POST'){owner(m[1],uid);member(m[1],b.userId);need(uid!==b.userId,400);db.exec('BEGIN');try{run('UPDATE members SET role=? WHERE serverId=? AND userId=?','admin',m[1],uid);run('UPDATE members SET role=? WHERE serverId=? AND userId=?','owner',m[1],b.userId);run('UPDATE servers SET ownerId=? WHERE id=?',b.userId,m[1]);db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}refresh();send({ok:true});return;}
 if((m=p.match(/^\/api\/servers\/([^/]+)\/members\/([^/]+)$/))&&method==='PATCH'){owner(m[1],uid);need(member(m[1],m[2]).role!=='owner',403);need(['admin','member'].includes(b.role));run('UPDATE members SET role=? WHERE serverId=? AND userId=?',b.role,m[1],m[2]);refresh();send({ok:true});return;}
 if((m=p.match(/^\/api\/servers\/([^/]+)\/(kick|ban)$/))&&method==='POST'){moderateTarget(m[1],uid,b.userId);removeServerVoice(m[1],b.userId);if(m[2]==='ban')run('INSERT OR IGNORE INTO bans VALUES(?,?)',m[1],b.userId);run('DELETE FROM members WHERE serverId=? AND userId=?',m[1],b.userId);refresh();send({ok:true});return;}
 if((m=p.match(/^\/api\/servers\/([^/]+)\/bans(?:\/([^/]+))?$/))){admin(m[1],uid);if(method==='GET'){send({bans:q('SELECT userId FROM bans WHERE serverId=?',m[1]).map(x=>user(x.userId))});return;}if(method==='DELETE'&&m[2]){run('DELETE FROM bans WHERE serverId=? AND userId=?',m[1],m[2]);send({ok:true});return;}}
 if((m=p.match(/^\/api\/servers\/([^/]+)\/channels$/))&&method==='POST'){admin(m[1],uid);const cid=id(),name=str(b.name,1,40,'Название канала');need(['text','voice'].includes(b.type));need(one('SELECT count(*) n FROM channels WHERE serverId=?',m[1]).n<100,400,'Достигнут лимит каналов');run('INSERT INTO channels VALUES(?,?,?,?)',cid,m[1],name,b.type);refresh();send({id:cid,serverId:m[1],name,type:b.type});return;}
 if((m=p.match(/^\/api\/channels\/([^/]+)$/))){const c=channelAccess(m[1],uid);admin(c.serverId,uid);if(method==='PATCH')run('UPDATE channels SET name=? WHERE id=?',str(b.name,1,40),c.id);else if(method==='DELETE'){for(const v of [...voices.values()])if(v.channelId===c.id)removeVoice(v.userId);run('DELETE FROM channels WHERE id=?',c.id);}else fail(405);refresh();send({ok:true});return;}
 if((m=p.match(/^\/api\/servers\/([^/]+)\/invites$/))&&method==='POST'){member(m[1],uid);rate('invites:'+uid,20,60000);const hours=Number(b.hours??24);need(Number.isFinite(hours)&&hours>=1&&hours<=168,400,'Срок приглашения: 1–168 часов');let token;for(let attempt=0;attempt<4;attempt++){const candidate=randomBytes(6).toString('base64url');if(!one('SELECT 1 FROM invites WHERE token=?',candidate)){token=candidate;break;}}need(token,503,'Не удалось создать приглашение, повторите попытку');const expiresAt=Date.now()+hours*3600000;run('INSERT INTO invites(token,serverId,expiresAt,createdBy) VALUES(?,?,?,?)',token,m[1],expiresAt,uid);send({token,expiresAt,createdBy:uid});return;}
 if((m=p.match(/^\/api\/invites\/([^/]+)$/))&&method==='DELETE'){const inv=need(one('SELECT * FROM invites WHERE token=?',m[1]),404);const role=member(inv.serverId,uid).role;need(role!=='member'||inv.createdBy===uid,403,'Можно отозвать только своё приглашение');run('UPDATE invites SET revoked=1 WHERE token=?',m[1]);refresh();send({ok:true});return;}
 if((m=p.match(/^\/api\/invites\/([^/]+)\/join$/))&&method==='POST'){rate('join:'+uid,20,60000);const inv=need(one('SELECT * FROM invites WHERE token=?',m[1]),404,'Приглашение не найдено');need(!inv.revoked&&inv.expiresAt>Date.now(),410,'Приглашение истекло или отозвано');need(!one('SELECT 1 FROM bans WHERE serverId=? AND userId=?',inv.serverId,uid),403,'Вы заблокированы на сервере');run('INSERT OR IGNORE INTO members VALUES(?,?,?)',inv.serverId,uid,'member');refresh();send({id:inv.serverId});return;}
 if(p==='/api/messages'&&method==='GET'){rate('message-read:'+uid,240,60000);const cid=url.searchParams.get('channelId'),did=url.searchParams.get('dmId');need(!!cid!==!!did,400,'Укажите канал или переписку');if(cid)need(channelAccess(cid,uid).type==='text',400);else dmAccess(did,uid);const before=url.searchParams.get('before');need(!before||/^\d+$/.test(before),400);const rows=q(`SELECT * FROM messages WHERE ${cid?'channelId':'dmId'}=? AND id<? ORDER BY id DESC LIMIT 51`,cid||did,before?Number(before):Number.MAX_SAFE_INTEGER);const hasMore=rows.length>50;send({messages:rows.slice(0,50).reverse().map(messageView),hasMore});return;}
 if(p==='/api/messages'&&method==='POST'){
 rate('message:'+uid,60,60000);need(!!b.channelId!==!!b.dmId,400);if(b.channelId)need(channelAccess(b.channelId,uid).type==='text',400);else dmAccess(b.dmId,uid,true);
 need(b.images===undefined||Array.isArray(b.images)&&b.images.length<=4,400,'До четырёх картинок в сообщении');
 const images=(b.images||[]).map(imageInput),total=images.reduce((n,i)=>n+i.size,0);need(total<=MAX_IMAGE_BYTES,413,'Картинки в одном сообщении: до 5 МБ');
 const content=str(b.content,images.length?0:1,2000,'Сообщение'),nonce=str(b.nonce,1,100,'Идентификатор');let message=one('SELECT * FROM messages WHERE authorId=? AND nonce=?',uid,nonce);
 if(message)need(message.channelId===(b.channelId||null)&&message.dmId===(b.dmId||null),409,'Идентификатор уже использован');else{
  if(images.length){rate('images:'+uid,12,60000);need(Number(one('SELECT COALESCE(sum(size),0) n FROM message_images').n)+total<=1024*1024*1024,507,'Хранилище картинок заполнено');}
  db.exec('BEGIN IMMEDIATE');try{const r=run('INSERT INTO messages(channelId,dmId,authorId,content,createdAt,nonce) VALUES(?,?,?,?,?,?)',b.channelId||null,b.dmId||null,uid,content,Date.now(),nonce);message=one('SELECT * FROM messages WHERE id=?',Number(r.lastInsertRowid));for(const image of images)run('INSERT INTO message_images VALUES(?,?,?,?,?,?)',id(),message.id,image.name,image.mime,image.size,image.bytes);db.exec('COMMIT')}catch(error){db.exec('ROLLBACK');throw error}refresh();
 }send({message:messageView(message)});return;}
 if((m=p.match(/^\/api\/message-images\/([a-f0-9]{32})$/))&&['GET','HEAD'].includes(method)){
  const image=need(one('SELECT i.*,m.channelId,m.dmId FROM message_images i JOIN messages m ON m.id=i.messageId WHERE i.id=?',m[1]),404,'Картинка не найдена');if(image.channelId)channelAccess(image.channelId,uid);else dmAccess(image.dmId,uid);
  res.writeHead(200,{'Content-Type':image.mime,'Content-Length':image.size,'Cache-Control':'private, no-store','Content-Disposition':'inline'});res.end(method==='HEAD'?undefined:Buffer.from(image.data));return;
 }
 if((m=p.match(/^\/api\/messages\/(\d+)$/))){const msg=need(one('SELECT * FROM messages WHERE id=?',Number(m[1])),404,'Сообщение не найдено');if(msg.channelId)channelAccess(msg.channelId,uid);else dmAccess(msg.dmId,uid);if(method==='PATCH'){need(msg.authorId===uid,403,'Можно изменять только свои сообщения');run('UPDATE messages SET content=?,editedAt=? WHERE id=?',str(b.content,one('SELECT 1 FROM message_images WHERE messageId=?',msg.id)?0:1,2000,'Сообщение'),Date.now(),msg.id);}else if(method==='DELETE'){if(msg.authorId!==uid){need(msg.channelId,403,'Можно удалять только свои сообщения');const c=channelAccess(msg.channelId,uid);admin(c.serverId,uid);if(member(c.serverId,uid).role==='admin')need((one('SELECT role FROM members WHERE serverId=? AND userId=?',c.serverId,msg.authorId)?.role||'member')==='member',403,'Нельзя модерировать администратора');}run('DELETE FROM messages WHERE id=?',msg.id);}else fail(405);refresh();send({ok:true});return;}
 if(p==='/api/read'&&method==='POST'){need(!!b.channelId!==!!b.dmId);if(b.channelId)channelAccess(b.channelId,uid);else dmAccess(b.dmId,uid);need(Number.isSafeInteger(Number(b.lastId))&&Number(b.lastId)>=0);const target=b.channelId||b.dmId;const max=one('SELECT max(id) n FROM messages WHERE channelId=? OR dmId=?',target,target).n||0;run('INSERT INTO reads VALUES(?,?,?) ON CONFLICT(userId,target) DO UPDATE SET lastId=max(lastId,excluded.lastId)',uid,target,Math.min(Number(b.lastId),max));send({ok:true});return;}
 if(p==='/api/screen/config'&&method==='GET'){if(turnCredentials)activeVoice(uid,session.hash);send({screenAudio:true,iceServers:[...iceServers,...(turnCredentials?[turnCredentials(uid)]:[])]});return;}
 if(p==='/api/screen/state'&&method==='GET'){const v=activeVoice(uid,session.hash);need(v.channelId===url.searchParams.get('channelId'),403,'Нет доступа к демонстрации');send(screenSnapshot(v.channelId));return;}
 if(p==='/api/screen/start'&&method==='POST'){const v=activeVoice(uid,session.hash,str(b.clientId,8,100));rate('screen-start:'+uid,15,60000);const current=shares.get(v.channelId);need(!current||current.presenterId===uid,409,'В канале уже идёт демонстрация');const share=current||{shareId:id(),presenterId:uid,clientId:v.clientId,sessionHash:session.hash};shares.set(v.channelId,share);screenState(v.channelId);send({channelId:v.channelId,presenterId:uid,shareId:share.shareId,viewers:participants(v.channelId).filter(u=>u.id!==uid).map(u=>u.id)});return;}
 if(p==='/api/screen/stop'&&method==='POST'){const v=activeVoice(uid,session.hash,str(b.clientId,8,100));const share=shares.get(v.channelId);need(!share||share.presenterId===uid,403,'Остановить демонстрацию может её автор');need(!share||b.shareId===share.shareId,409,'Демонстрация уже заменена');shares.delete(v.channelId);screenState(v.channelId);send({ok:true});return;}
 if(p==='/api/screen/signal'&&method==='POST'){
 const v=activeVoice(uid,session.hash,str(b.clientId,8,100));rate('screen-signal:'+uid,180,60000);need(typeof b.to==='string'&&b.to!==uid,400,'Некорректный получатель');const target=need(voices.get(b.to),403,'Получатель не подключён');activeVoice(b.to,target.sessionHash);need(target.channelId===v.channelId,403,'Получатель находится в другом канале');const share=need(shares.get(v.channelId),409,'Демонстрация завершена');need(b.shareId===share.shareId,409,'Демонстрация уже заменена');need(share.presenterId===uid||share.presenterId===b.to,403,'Обмен разрешён только с автором демонстрации');activeVoice(share.presenterId,share.sessionHash,share.clientId);
 need(['offer','answer','candidate','restart'].includes(b.type),400,'Неизвестный сигнал');let signal={type:b.type};
 if(b.type==='restart'){need(share.presenterId===b.to&&share.presenterId!==uid&&b.sdp===undefined&&b.candidate===undefined,403,'Переподключение может запросить только зритель');}
 else if(b.type==='candidate'){const candidate=b.candidate;need(candidate===null||(candidate&&typeof candidate==='object'&&!Array.isArray(candidate)&&typeof candidate.candidate==='string'&&JSON.stringify(candidate).length<=1000),400,'Некорректный ICE-кандидат');signal.candidate=candidate;}
 else{need((b.type==='offer')===(share.presenterId===uid),403,'Неверное направление сигнала');need(typeof b.sdp==='string'&&b.sdp.length<=16000,400,'Некорректный SDP');const media=[];for(const line of b.sdp.split(/\r?\n/)){if(line.startsWith('m='))media.push({kind:line.split(/[ \t]/)[0].slice(2),lines:[]});if(media.length)media.at(-1).lines.push(line);}need(media.length>=1&&media.length<=2&&media.filter(m=>m.kind==='video').length===1&&media.every(m=>['video','audio'].includes(m.kind))&&media.filter(m=>m.kind==='audio').length<=1,400,'Ожидается видео и не более одной звуковой дорожки');const audio=media.find(m=>m.kind==='audio');if(audio){const directions=audio.lines.filter(line=>/^a=(?:sendonly|recvonly|sendrecv|inactive)$/.test(line));need(directions.length===1&&(b.type==='offer'?directions[0]==='a=sendonly':['a=recvonly','a=inactive'].includes(directions[0]))&&/^m=audio \d+ UDP\/TLS\/RTP\/SAVPF /i.test(audio.lines[0])&&audio.lines.some(line=>/^a=rtpmap:\d+ opus\/48000(?:\/2)?$/i.test(line)),400,'Звук трансляции передаётся только от ведущего к зрителю');}signal.sdp=b.sdp;}
 event(b.to,{type:'screen.signal',from:uid,channelId:v.channelId,shareId:share.shareId,signal},target.sessionHash);send({ok:true});return;}
 if(p==='/api/voice/join'&&method==='POST'){const c=channelAccess(b.channelId,uid);need(c.type==='voice',400,'Это не голосовой канал');const clientId=str(b.clientId,8,100);const current=voices.get(uid);const count=participants(c.id).filter(x=>x.id!==uid).length;need(count<VOICE_ROOM_LIMIT,409,`В комнате уже ${VOICE_ROOM_LIMIT} участников`);const mute=!!one('SELECT 1 FROM voice_mutes WHERE serverId=? AND userId=?',c.serverId,uid);removeVoice(uid);voices.set(uid,{userId:uid,channelId:c.id,clientId,sessionHash:session.hash,serverMuted:mute,lastPing:Date.now(),lastSequence:-1});voiceState(c.id);refresh();send({channelId:c.id,participants:participants(c.id),maxBatchFrames:4});return;}
 if(p==='/api/voice/moderate'&&method==='POST'){const v=need(voices.get(b.userId),404,'Участник не подключён');const c=channelAccess(v.channelId,uid);moderateTarget(c.serverId,uid,b.userId);need(['mute','unmute','disconnect'].includes(b.action));if(b.action==='disconnect')removeVoice(b.userId);else{v.serverMuted=b.action==='mute';if(v.serverMuted)run('INSERT OR IGNORE INTO voice_mutes VALUES(?,?)',c.serverId,b.userId);else run('DELETE FROM voice_mutes WHERE serverId=? AND userId=?',c.serverId,b.userId);voiceState(c.id);}refresh();send({ok:true});return;}
 if(p.startsWith('/api/voice/')&&method==='POST'){
  const v=need(voices.get(uid),409,'Нет подключения к голосу');
  need(v.clientId===b.clientId&&v.sessionHash===session.hash,409,'Подключение заменено другой вкладкой');channelAccess(v.channelId,uid);
  if(p==='/api/voice/leave'){removeVoice(uid);refresh();send({ok:true});return;}
  if(p==='/api/voice/ping'){v.lastPing=Date.now();send({ok:true});return;}
  if(p==='/api/voice/frame'){
   const batch=b.frames===undefined?[b]:b.frames;
   need(Array.isArray(batch)&&batch.length>0&&batch.length<=4,400,'Размер пачки аудио');
   if(b.frames!==undefined)need(b.pcm===undefined&&b.sequence===undefined,400,'Неоднозначная пачка аудио');
   let sequence=v.lastSequence;
   // Validate the whole batch before publishing any audio or advancing sequence.
   const frames=batch.map(frame=>{
    need(frame&&typeof frame==='object'&&!Array.isArray(frame),400,'Некорректный аудиокадр');
    need(typeof frame.pcm==='string'&&/^[A-Za-z0-9+/]*={0,2}$/.test(frame.pcm)&&frame.pcm.length<=8536,400,'Некорректный аудиокадр');
    const data=Buffer.from(frame.pcm,'base64');
    need(data.length>0&&data.length<=6400&&data.length%2===0&&(b.frames===undefined||data.length===3200),400,'Размер аудиокадра');
    need(Number.isSafeInteger(frame.sequence)&&frame.sequence>sequence,400,'Неверная последовательность');
    sequence=frame.sequence;return{pcm:frame.pcm,sequence};
   });
   // Count audio frames, not requests: batches cannot multiply the rate limit.
   for(const frame of frames)rate('frame:'+uid,24,1000);
   v.lastSequence=sequence;v.lastPing=Date.now();
   if(!v.serverMuted)for(const peer of [...voices.values()])if(peer.channelId===v.channelId&&peer.userId!==uid){
    try{channelAccess(peer.channelId,peer.userId);for(const frame of frames)event(peer.userId,{type:'voice.frame',userId:uid,channelId:v.channelId,...frame});}catch{removeVoice(peer.userId);}
   }
   send({ok:true});return;
  }
 }
 fail(404,'Маршрут не найден');
 }catch(e){if(!res.headersSent)send({error:e.status?e.message:'Внутренняя ошибка сервера'},e.status||500);else res.end();}
});
const sweep=setInterval(()=>{const now=Date.now();for(const v of [...voices.values()]){try{channelAccess(v.channelId,v.userId)}catch{removeVoice(v.userId)}}for(const v of [...voices.values()])if(v.lastPing<now-15000||!one('SELECT 1 FROM sessions WHERE hash=? AND expires>?',v.sessionHash,now))removeVoice(v.userId);for(const [k,a]of limits)if(a.end<now)limits.delete(k);for(const [uid,set]of streams)for(const c of set){if(!one('SELECT 1 FROM sessions WHERE hash=? AND expires>?',c.sessionHash,now))c.res.end();else if(c.res.writableLength>131072)c.res.destroy();else c.res.write(': heartbeat\n\n');}run('DELETE FROM sessions WHERE expires<?',now);for(const g of q('SELECT userId FROM guests WHERE userId NOT IN (SELECT userId FROM sessions WHERE expires>?)',now)){run('DELETE FROM call_access WHERE userId=?',g.userId);run('DELETE FROM users WHERE id=?',g.userId)}run('DELETE FROM call_access WHERE expiresAt<?',now);},5000);
sweep.unref();
server.on('close',()=>clearInterval(sweep));
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))server.listen(Number(process.env.PORT||3000),process.env.HOST||'127.0.0.1',()=>console.log(`Vibra: http://${process.env.HOST||'127.0.0.1'}:${server.address().port}`));
export {server,db};










