'use strict';
// This installed loader remains unchanged during application-code updates.
const {app}=require('electron');const fs=require('node:fs');const path=require('node:path');
app.setName('Vibra');if(process.env.VIBRA_DESKTOP_TEST==='1'&&process.env.VIBRA_USER_DATA)app.setPath('userData',path.resolve(process.env.VIBRA_USER_DATA));
if(!app.requestSingleInstanceLock()){app.quit();return;}
const {UpdateStore}=require('./update-core.cjs');const {createUpdater}=require('./updater.cjs');
const baseRoot=path.resolve(__dirname,'..'),publicKey=fs.readFileSync(path.join(__dirname,'update-public-key.pem'),'utf8');
const store=new UpdateStore({userData:app.getPath('userData'),baseRoot,baseVersion:app.getVersion(),electron:process.versions.electron,publicKey});
const selected=store.load();const updater=createUpdater({app,store});
globalThis[Symbol.for('vibra.updateRuntime')]=updater;
try{require(path.join(selected.root,'desktop','main.cjs'))}catch(error){if(selected.root===baseRoot)throw error;try{fs.renameSync(store.pointer,store.pointer+'.failed-'+Date.now())}catch{}app.relaunch();app.exit(1)}
