import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {mkdtempSync,rmSync,mkdirSync} from 'node:fs';
import {tmpdir,homedir} from 'node:os';
import path from 'node:path';
import {detectDesktopSystem,desktopDownloadChoice,desktopPackages} from '../public/desktop-download.js';

test('desktop platform detection handles hints, Safari ambiguity, mobile and unsupported Linux ARM',()=>{
 assert.equal(detectDesktopSystem({platform:'Win32',userAgent:'Windows NT 10.0; Win64; x64'}).os,'windows');
 assert.equal(desktopDownloadChoice({os:'windows'}).url,desktopPackages.windows.url);
 assert.equal(detectDesktopSystem({userAgentData:{platform:'macOS'},userAgent:'Windows NT 10.0'}).os,'mac');
 assert.deepEqual(detectDesktopSystem({platform:'MacIntel',userAgent:'Macintosh; Intel Mac OS X',maxTouchPoints:0}),{os:'mac',architecture:'unknown'});
 assert.equal(desktopDownloadChoice({os:'mac',architecture:'unknown'}).choose,true);
 assert.equal(desktopDownloadChoice(detectDesktopSystem({platform:'MacIntel'},{architecture:'arm',bitness:'64'})).url,desktopPackages.macArm.url);
 assert.equal(desktopDownloadChoice(detectDesktopSystem({platform:'MacIntel'},{architecture:'x86',bitness:'64'})).url,desktopPackages.macIntel.url);
 assert.equal(detectDesktopSystem({platform:'MacIntel',maxTouchPoints:5}).os,'mobile');
 assert.equal(detectDesktopSystem({platform:'Linux armv8l',userAgent:'Mozilla Android Mobile'}).os,'mobile');
 assert.equal(detectDesktopSystem({userAgentData:{platform:'Android',mobile:true}}).os,'mobile');
 assert.equal(desktopDownloadChoice(detectDesktopSystem({platform:'Linux aarch64'})).choose,true);
 assert.equal(desktopDownloadChoice(detectDesktopSystem({platform:'Linux x86_64'})).url,desktopPackages.linux.url);
 assert.equal(desktopDownloadChoice(detectDesktopSystem({})).choose,true);
 for(const pack of Object.values(desktopPackages)){const url=new URL(pack.url);assert.equal(url.origin,'https://github.com');assert(url.pathname.startsWith('/Nhastoff/Vibra/releases/download/'));assert.equal(url.search,'');assert.equal(url.hash,'')}
});

test('download offer is available before/after login, community invite and named guest; platform choice and desktop hiding work',{timeout:45000},async t=>{
 const directory=mkdtempSync(path.join(tmpdir(),'vibra-download-')),before=process.env.DATA_DIR;process.env.DATA_DIR=directory;
 const {server,db}=await import('../server.mjs?download='+Date.now());await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const base='http://127.0.0.1:'+server.address().port;let browser;
 t.after(async()=>{await browser?.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));db.close();rmSync(directory,{recursive:true,force:true});if(before===undefined)delete process.env.DATA_DIR;else process.env.DATA_DIR=before});
 const modules=process.env.VIBRA_NODE_MODULES||path.join(homedir(),'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules'),{chromium}=createRequire(import.meta.url)(path.join(modules,'playwright'));
 browser=await chromium.launch({executablePath:process.env.VIBRA_EDGE||'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true,args:['--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream','--autoplay-policy=no-user-gesture-required']});
 const errors=[];
 async function profile(platform,architecture,options={}){
  const context=await browser.newContext({viewport:{width:1440,height:1000},...options});
  await context.addInitScript(({platform,architecture})=>Object.defineProperty(navigator,'userAgentData',{configurable:true,value:{platform,mobile:false,getHighEntropyValues:async()=>({architecture,bitness:'64'})}}),{platform,architecture});
  return context;
 }
 const owner=await profile('Windows','x86'),page=await owner.newPage();page.on('pageerror',e=>errors.push(e.message));await page.goto(base);
 const main=()=>page.locator('[data-desktop-download] .desktop-download-main');
 await main().filter({hasText:'Скачать для Windows'}).waitFor();assert.equal(await main().getAttribute('href'),desktopPackages.windows.url);assert.equal(await main().getAttribute('referrerpolicy'),'no-referrer');
 assert.equal(await page.locator('[data-desktop-download]').count(),1);mkdirSync('test-output',{recursive:true});await page.screenshot({path:'test-output/download-auth.png'});await page.locator('[data-desktop-download]').screenshot({path:'test-output/download-offer.png'});
 async function api(context,url,method='GET',body){const response=await context.request.fetch(base+url,{method,headers:{'content-type':'application/json','x-csrf':context.csrf||''},data:body});const value=await response.json();assert.equal(response.status(),200,JSON.stringify(value));if(value.csrf)context.csrf=value.csrf;return value}
 await api(owner,'/api/auth/register','POST',{username:'download_owner',password:'download-test-password'});await page.reload();await page.locator('.shell').waitFor();await main().filter({hasText:'Скачать для Windows'}).waitFor();
 assert.equal(await page.locator('.sidebar [data-desktop-download]').count(),1);await page.screenshot({path:'test-output/download-signed-in.png'});
 const sid=(await api(owner,'/api/servers','POST',{name:'Download invitation'})).id,room=(await api(owner,`/api/servers/${sid}`)).channels.find(c=>c.type==='voice').id;
 const invitation=await api(owner,`/api/servers/${sid}/invites`,'POST',{hours:1}),call=await api(owner,'/api/call/invites','POST',{channelId:room,hours:1});
 const guest=await profile('Windows','x86'),invitePage=await guest.newPage();await invitePage.goto(base+'/i/'+invitation.token);await invitePage.locator('[data-desktop-download] .desktop-download-main').filter({hasText:'Windows'}).waitFor();assert(new URL(invitePage.url()).searchParams.get('invite'));
 const guestPage=await guest.newPage();guestPage.on('pageerror',e=>errors.push(e.message));await guestPage.goto(base+'/call.html#'+call.token);await guestPage.locator('[data-desktop-download] .desktop-download-main').filter({hasText:'Windows'}).waitFor();
 await guestPage.locator('[name=name]').fill('Гость со скачиванием');await guestPage.locator('[type=submit]').click();await guestPage.waitForFunction(()=>document.querySelector('#call-status')?.textContent==='Вы в звонке');await guestPage.locator('[data-desktop-download] .desktop-download-main').filter({hasText:'Windows'}).waitFor();
 assert.equal(await guestPage.locator('[data-desktop-download]').count(),1);await guestPage.screenshot({path:'test-output/download-guest.png'});
 const mac=await profile('macOS',''),macPage=await mac.newPage();await macPage.goto(base);await macPage.locator('.desktop-download-main').filter({hasText:'macOS'}).click();assert.equal(await macPage.locator('.desktop-download-options').getAttribute('open'),'');assert.equal(await macPage.locator('[data-package=macArm]').getAttribute('href'),desktopPackages.macArm.url);assert.equal(await macPage.locator('[data-package=macIntel]').getAttribute('href'),desktopPackages.macIntel.url);
 const mobile=await profile('Android','arm',{viewport:{width:390,height:844},userAgent:'Mozilla/5.0 (Linux; Android 14) Mobile'}),mobilePage=await mobile.newPage();await mobilePage.goto(base);await mobilePage.locator('.desktop-download-main').filter({hasText:'на компьютер'}).waitFor();assert(await mobilePage.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 const desktop=await profile('Windows','x86');await desktop.addInitScript(()=>{window.vibraCapture={capabilities:async()=>({})}});const desktopPage=await desktop.newPage();await desktopPage.goto(base);await desktopPage.locator('#auth-form').waitFor();assert.equal(await desktopPage.locator('[data-desktop-download]').count(),0);
 assert.deepEqual(errors,[]);
});
