import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir,homedir} from 'node:os';
import path from 'node:path';

test('browser automatically restores voice, presence and named guest after repeated network outages',{timeout:60000},async t=>{
 const directory=mkdtempSync(path.join(tmpdir(),'vibra-reconnect-')),before=process.env.DATA_DIR;process.env.DATA_DIR=directory;
 const {server,db}=await import('../server.mjs?reconnect='+Date.now());await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const base='http://127.0.0.1:'+server.address().port;let browser;
 t.after(async()=>{await browser?.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));db.close();rmSync(directory,{recursive:true,force:true});if(before===undefined)delete process.env.DATA_DIR;else process.env.DATA_DIR=before});
 const modules=process.env.VIBRA_NODE_MODULES||path.join(homedir(),'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules');
 const {chromium}=createRequire(import.meta.url)(path.join(modules,'playwright'));
 browser=await chromium.launch({executablePath:process.env.VIBRA_EDGE||'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true,args:['--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream','--autoplay-policy=no-user-gesture-required','--disable-background-timer-throttling','--disable-renderer-backgrounding']});
 const a=await browser.newContext({viewport:{width:1440,height:900}}),b=await browser.newContext({viewport:{width:1440,height:900}});
 async function api(context,url,method='GET',body){const response=await context.request.fetch(base+url,{method,headers:{'content-type':'application/json','x-csrf':context.csrf||''},data:body});const result=await response.json();assert.equal(response.status(),200,JSON.stringify(result));if(result.csrf)context.csrf=result.csrf;return result}
 const alice=(await api(a,'/api/auth/register','POST',{username:'reconnect_alice',password:'reconnect-password'})).me;
 const bob=(await api(b,'/api/auth/register','POST',{username:'reconnect_bob',password:'reconnect-password'})).me;
 const sid=(await api(a,'/api/servers','POST',{name:'Reconnect test'})).id;
 const invitation=await api(a,`/api/servers/${sid}/invites`,'POST',{hours:1});await api(b,`/api/invites/${invitation.token}/join`,'POST');
 const room=(await api(a,`/api/servers/${sid}`)).channels.find(c=>c.type==='voice').id;
 const pa=await a.newPage(),pb=await b.newPage(),errors=[];
 for(const page of [pa,pb])page.on('pageerror',error=>errors.push(error.message));
 let joins=0,eventOpens=0;
 pb.on('request',request=>{if(request.url().endsWith('/api/voice/join'))joins++;if(request.url().includes('/api/events?'))eventOpens++});
 for(const page of [pa,pb]){await page.goto(base);await page.locator('.shell').waitFor();await page.locator(`[data-action=server][data-id="${sid}"]`).click();await page.waitForFunction(()=>!document.querySelector('#connection .connection'))}
 const own=()=>pb.locator(`.members [data-id="${bob.id}"] .status-dot`);
 await own().and(pb.locator('.status-dot.online')).waitFor();
 await pb.locator(`[data-action=channel][data-id="${room}"]`).click();await pb.locator('#voice-bar .is-connected').waitFor();assert.equal(joins,1);
 await pb.locator('.profile-bar [data-action=mute]').click();
 async function outage(){
  const previousJoins=joins;
  await b.setOffline(true);await pb.locator('#connection .connection').waitFor();
  assert.match(await pb.locator('.profile-bar').textContent(),/Нет соединения/);
  assert.equal(await pb.locator('#voice-bar .is-connected').count(),0);
  await b.setOffline(false);
  await pb.locator('#voice-bar .is-connected').waitFor();
  await pb.waitForFunction(()=>!document.querySelector('#connection .connection'));
  await own().and(pb.locator('.status-dot.online')).waitFor();
  await pa.locator(`.members [data-id="${bob.id}"] .status-dot.online`).waitFor();
  assert.equal((await api(b,'/api/bootstrap')).voice.channelId,room);
  assert.equal(joins,previousJoins+1,'one automatic voice join per outage');
  assert.equal(await pb.locator('.profile-bar [data-action=mute]').getAttribute('aria-pressed'),'true');
 }
 await outage();await outage();
 // A terminal EventSource failure must recover even without an online event.
 const count=eventOpens,priorJoins=joins;
 const disconnected=pb.waitForSelector('#connection .connection');
 // A synthetic offline event resets only this page's stream; Chromium stays online.
 await pb.evaluate(()=>window.dispatchEvent(new Event('offline')));await disconnected;
 await pb.locator('#voice-bar .is-connected').waitFor();assert(eventOpens>count);assert.equal(joins,priorJoins+1);
 // A manual leave while offline cancels recovery; reconnect must not re-open the mic.
 await b.setOffline(true);await pb.locator('#connection .connection').waitFor();await pb.locator('#voice-bar [data-action=voice-leave]').click();const stopped=joins;
 await b.setOffline(false);await pb.waitForFunction(()=>!document.querySelector('#connection .connection'));assert.equal(joins,stopped);assert.equal(await pb.locator('#voice-bar [data-action=voice-leave]').count(),0);
 const link=await api(a,'/api/call/invites','POST',{channelId:room,hours:1});
 const guest=await browser.newContext(),pg=await guest.newPage();pg.on('pageerror',e=>errors.push(e.message));
 await pg.goto(base+'/call.html#'+link.token);await pg.locator('[name=name]').fill('Гость после обрыва');await pg.locator('[type=submit]').click();await pg.waitForFunction(()=>document.querySelector('#call-status')?.textContent==='Вы в звонке');
 const guestId=(await api(guest,'/api/bootstrap')).me.id;
 await guest.setOffline(true);await pg.waitForFunction(()=>document.querySelector('#call-status')?.textContent==='Переподключаемся…');
 await guest.setOffline(false);await pg.waitForFunction(()=>document.querySelector('#call-status')?.textContent==='Вы в звонке');
 assert.equal((await api(guest,'/api/bootstrap')).me.id,guestId,'guest session survives without another call/join');
 assert.equal(db.prepare('SELECT count(*) n FROM guests').get().n,1);
 assert.deepEqual(errors,[]);
 t.diagnostic(JSON.stringify({automaticBrowserJoins:joins,eventsReopened:eventOpens,manualLeaveCancelsRecovery:true,guestIdentityPreserved:true,physicalNetwork:'Chromium offline mode; physical VPN not modified'}));
});
