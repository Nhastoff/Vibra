import { RNNoise } from './vendor/rnnoise/worklet.js';
import { SpeechGate } from './speech-gate.js';

class VibraSpeechNoise extends AudioWorkletProcessor {
  constructor(options) {
    super();
    this.input = new Float32Array(480);
    this.output = new Float32Array(480);
    this.index = 0;
    this.read = 480;
    this.gate = new SpeechGate();
    this.destroyed = false;
    this.port.onmessage = event => { if (event.data === 'destroy') this.destroy(); };
    RNNoise.loadBinary(options.processorOptions.wasmBinary).then(module => {
      if (this.destroyed) return;
      this.denoiser = module.createDenoiseState();
      this.port.postMessage({type: 'ready'});
    }).catch(() => this.port.postMessage({type: 'error'}));
  }
  process(inputs, outputs) {
    if (this.destroyed) return false;
    const input = inputs[0]?.[0], output = outputs[0]?.[0];
    if (!input || !output || !this.denoiser) return true;
    for (let i = 0; i < input.length; i++) {
      this.input[this.index++] = input[i] * 32767;
      if (this.index === 480) {
        const probability = this.denoiser.processFrame(this.input);
        for (let j = 0; j < 480; j++) this.input[j] /= 32767;
        this.gate.process(this.input, probability);
        this.output.set(this.input);
        this.read = this.index = 0;
      }
      output[i] = this.read < 480 ? this.output[this.read++] : 0;
    }
    return true;
  }
  destroy() { this.destroyed = true; this.denoiser?.destroy(); this.denoiser = null; }
}
registerProcessor('vibra-rnnoise-speech', VibraSpeechNoise);
