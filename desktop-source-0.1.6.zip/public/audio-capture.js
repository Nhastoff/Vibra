// Mono, 16 kHz PCM16 in bounded 100 ms frames. Nothing is recorded or persisted.
class VibraCapture extends AudioWorkletProcessor {
  constructor() {
    super();
    this.frame = new Int16Array(1600);
    this.index = 0;
    this.sum = 0;
    this.weight = 0;
    this.step = sampleRate / 16000;
    this.energy = 0;
  }
  process(inputs) {
    const channels = inputs[0];
    if (!channels?.length) return true;
    for (let i = 0; i < channels[0].length; i++) {
      let value = 0;
      for (const channel of channels) value += channel[i] || 0;
      value /= channels.length;
      let remaining = 1;
      while (remaining > 0.000001) {
        const used = Math.min(remaining, this.step - this.weight);
        this.sum += value * used;
        this.weight += used;
        remaining -= used;
        if (this.weight >= this.step - 0.000001) {
          const sample = Math.max(-1, Math.min(1, this.sum / this.step));
          this.frame[this.index++] = Math.round(sample * (sample < 0 ? 32768 : 32767));
          this.energy += sample * sample;
          this.sum = this.weight = 0;
          if (this.index === this.frame.length) {
            this.port.postMessage({ pcm: this.frame.buffer, rms: Math.sqrt(this.energy / 1600) }, [this.frame.buffer]);
            this.frame = new Int16Array(1600);
            this.index = this.energy = 0;
          }
        }
      }
    }
    return true;
  }
}
registerProcessor('vibra-capture', VibraCapture);
