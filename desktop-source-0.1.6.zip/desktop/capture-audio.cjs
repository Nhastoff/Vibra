'use strict';
const os=require('node:os');

// Audited against Electron 44.9.0 DisplayMediaDeviceChosen and Chromium's WASAPI
// process-loopback device. Fail closed after a runtime/platform change: ordinary
// loopback can include call audio. Never replace this ID with loopbackWithMute.
function captureAudioCapabilities({platform=process.platform,electron=process.versions.electron,release=os.release()}={}){
 const base={desktop:true,systemAudio:false,excludesOwnAudio:false,reason:null};
 if(electron!=='44.9.0')return{...base,reason:'Звук трансляции отключён: эта версия приложения ещё не проверена на исключение звука Vibra.'};
 if(platform!=='win32')return{...base,reason:'На этой системе пока доступна трансляция без звука: исключение голоса Vibra не подтверждено.'};
 const parts=String(release).split('.').map(Number);
 if(parts.length<3||!parts.every(Number.isFinite)||parts[0]<10||parts[2]<20348)return{...base,reason:'На этой версии Windows доступна трансляция без звука. Для исключения голоса Vibra нужна Windows сборки 20348 или новее.'};
 return{...base,systemAudio:true,excludesOwnAudio:true};
}
function captureStreams(source,{requested=false,enabled=false,capabilities=captureAudioCapabilities()}={}){
 return{video:source,...(requested===true&&enabled===true&&capabilities.systemAudio===true&&capabilities.excludesOwnAudio===true?{audio:'loopbackWithoutChrome'}:{})};
}
module.exports={captureAudioCapabilities,captureStreams};
